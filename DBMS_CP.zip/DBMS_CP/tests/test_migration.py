import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import unittest
import datetime
from migration.field_mapping import mysql_product_to_mongodb_doc, mongodb_doc_to_mysql_product
from migration.validation import MigrationValidator
from database.mongodb_connection import MongoDBDatabase

class TestMigration(unittest.TestCase):
    def test_field_mapping_conversions(self):
        mysql_row = {
            "product_id": 101,
            "product_name": "Apex Gaming Laptop",
            "price": 1299.99,
            "status": "active",
            "created_at": datetime.datetime(2026, 1, 15, 10, 30, 0)
        }
        mongo_doc = mysql_product_to_mongodb_doc(mysql_row, category_name="Laptops & Computers")

        self.assertEqual(mongo_doc["product_id"], 101)
        self.assertEqual(mongo_doc["category"], "Laptops & Computers")
        self.assertEqual(mongo_doc["price"], 1299.99)
        self.assertIn("attributes", mongo_doc)
        self.assertIn("variants", mongo_doc)

        # Convert back
        restored = mongodb_doc_to_mysql_product(mongo_doc)
        self.assertEqual(restored["product_id"], 101)
        self.assertEqual(restored["category_name"], "Laptops & Computers")
        self.assertEqual(restored["price"], 1299.99)

    def test_reconciliation_structure(self):
        mongo = MongoDBDatabase()
        validator = MigrationValidator(mongo_db=mongo)
        res = validator.reconcile_catalog(sample_size=10)
        self.assertIn("is_reconciled", res)
        self.assertIn("mongo_catalog_count", res)
        self.assertIn("sample_field_mismatches", res)

if __name__ == "__main__":
    unittest.main()
