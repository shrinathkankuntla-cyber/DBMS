import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import unittest
from database.mongodb_connection import MongoDBDatabase

class TestSchema(unittest.TestCase):
    def test_mysql_schema_file_exists(self):
        schema_path = Path(__file__).resolve().parent.parent / "database" / "mysql_schema.sql"
        self.assertTrue(schema_path.exists(), "mysql_schema.sql does not exist")
        with open(schema_path, "r", encoding="utf-8") as f:
            content = f.read()
        for tbl in ["customers", "categories", "products", "inventory", "orders", "order_items", "cart_items", "experiments"]:
            self.assertIn(f"CREATE TABLE IF NOT EXISTS {tbl}", content)

    def test_mongodb_collection_and_indexes(self):
        mongo = MongoDBDatabase()
        ok, msg = mongo.init_collection()
        self.assertTrue(ok)
        indexes = mongo.list_indexes("product_catalog")
        # Check identity index exists
        self.assertTrue(any("product_id" in str(idx.get("key")) for idx in indexes.values()))

if __name__ == "__main__":
    unittest.main()
