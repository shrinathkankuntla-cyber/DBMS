import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import unittest
from transactions.order_transactions import OrderTransactionManager
from database.mysql_connection import MySQLDatabase

class TestTransactions(unittest.TestCase):
    def setUp(self):
        self.mysql = MySQLDatabase()
        self.tx_mgr = OrderTransactionManager(self.mysql)

    def test_transaction_structure_and_error_handling(self):
        # Empty item order must fail cleanly without throwing unhandled exceptions
        res = self.tx_mgr.place_order_transactional(customer_id=1, items=[])
        self.assertFalse(res["success"])
        self.assertIn("error", res)

        # Non-existent customer must fail cleanly
        res2 = self.tx_mgr.place_order_transactional(customer_id=-999, items=[{"product_id": 1, "quantity": 1}])
        self.assertFalse(res2["success"])

if __name__ == "__main__":
    unittest.main()
