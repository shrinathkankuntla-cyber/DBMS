import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import unittest
from database.mongodb_connection import MongoDBDatabase
from workloads.product_search import ProductSearchWorkload
from workloads.workload_generator import WorkloadGenerator

class TestWorkloads(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mongo = MongoDBDatabase()
        cls.mongo.init_collection()

    def test_mongo_product_search(self):
        search = ProductSearchWorkload(mongo_db=self.mongo)
        res = search.search_mongodb(category="Laptops & Computers", limit=10)
        self.assertIsInstance(res, dict)
        self.assertTrue(res["success"])
        self.assertIn("duration_ms", res)
        self.assertGreaterEqual(res["duration_ms"], 0.0)

    def test_mongo_workload_generator(self):
        gen = WorkloadGenerator(mongo_db=self.mongo, seed=42)
        res = gen.execute_workload(
            database_target="MongoDB",
            total_operations=10,
            read_ratio=0.8,
            warmup_operations=2
        )
        self.assertEqual(res["database"], "MongoDB")
        self.assertEqual(res["total_operations"], 10)
        self.assertIn("total_duration_ms", res)
        self.assertIn("throughput_qps", res)
        self.assertIn("read_latency_stats", res)
        self.assertIn("write_latency_stats", res)
        print("\nMongoDB Workload Run Result:", res["total_duration_ms"], "ms, QPS:", res["throughput_qps"])

if __name__ == "__main__":
    unittest.main()
