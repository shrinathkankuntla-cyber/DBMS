import sys
import unittest
from unittest.mock import MagicMock, patch
import datetime

# Mock streamlit before importing ui.overview to test execution in headless python
mock_st = MagicMock()
mock_st.columns.side_effect = lambda n: [MagicMock() for _ in range(n if isinstance(n, int) else len(n))]
mock_st.selectbox.side_effect = lambda label, options, **kwargs: options[0] if options else None
sys.modules['streamlit'] = mock_st

from utils.helpers import format_timestamp

class TestOverviewTimestamp(unittest.TestCase):
    def test_datetime_formatting(self):
        dt = datetime.datetime(2026, 11, 4, 23, 15, 30)
        res = format_timestamp(dt)
        self.assertEqual(res, "2026-11-04 23:15:30")

    def test_none_formatting(self):
        res = format_timestamp(None)
        self.assertEqual(res, "N/A")

    def test_iso_formatting(self):
        res = format_timestamp("2026-11-04T23:15:30.456789")
        self.assertEqual(res, "2026-11-04 23:15:30")

    @patch('database.mysql_connection.MySQLDatabase')
    @patch('database.mongodb_connection.MongoDBDatabase')
    @patch('optimizer.benchmark_engine.BenchmarkEngine.list_experiments')
    def test_render_overview_with_datetime(self, mock_list_exp, mock_mongo, mock_mysql):
        mock_mysql.return_value.test_connection.return_value = (True, "Connected")
        mock_mongo.return_value.test_connection.return_value = (True, "Connected")
        mock_list_exp.return_value = [{
            "experiment_id": "EXP-TEST1234",
            "created_at": datetime.datetime(2026, 11, 4, 23, 10, 0),
            "database_type": "MySQL",
            "config_type": "Composite",
            "workload_name": "Read-Heavy",
            "operation_count": 100,
            "total_duration_ms": 120.5,
            "classification": "Recommended",
            "read_improvement_pct": 45.2,
            "write_penalty_pct": 3.1
        }]
        from ui.overview import render_overview
        # Execute render_overview - should not raise TypeError
        try:
            render_overview()
            print("render_overview with datetime object succeeded!")
        except Exception as e:
            self.fail(f"render_overview failed with error: {e}")

    @patch('database.mysql_connection.MySQLDatabase')
    @patch('database.mongodb_connection.MongoDBDatabase')
    @patch('optimizer.benchmark_engine.BenchmarkEngine.list_experiments')
    def test_render_overview_with_none(self, mock_list_exp, mock_mongo, mock_mysql):
        mock_mysql.return_value.test_connection.return_value = (False, "Disconnected")
        mock_mongo.return_value.test_connection.return_value = (False, "Disconnected")
        mock_list_exp.return_value = []
        from ui.overview import render_overview
        try:
            render_overview()
            print("render_overview with empty experiments (None timestamp) succeeded!")
        except Exception as e:
            self.fail(f"render_overview failed with error: {e}")

if __name__ == '__main__':
    unittest.main()
