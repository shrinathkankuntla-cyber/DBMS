import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import unittest
from database.mongodb_connection import MongoDBDatabase
from optimizer.index_manager import IndexManager
from optimizer.benchmark_engine import BenchmarkEngine

class TestBenchmark(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mongo = MongoDBDatabase()
        cls.mongo.init_collection()
        cls.index_mgr = IndexManager(mongo_db=cls.mongo)
        cls.bench = BenchmarkEngine(mongo_db=cls.mongo, seed=42)

    def test_apply_and_reset_mongo_indexes(self):
        # Apply Single-Field config
        res = self.index_mgr.apply_configuration("MongoDB", "Single-Field")
        self.assertTrue(res["success"], f"Failed to apply: {res}")
        indexes = self.mongo.list_indexes("product_catalog")
        self.assertIn("idx_cat", indexes)

        # Reset to baseline
        res_base = self.index_mgr.apply_configuration("MongoDB", "Baseline")
        self.assertTrue(res_base["success"])
        indexes_after = self.mongo.list_indexes("product_catalog")
        self.assertNotIn("idx_cat", indexes_after)
        # Identity index must still be present!
        self.assertTrue(any("product_id" in str(idx.get("key")) for idx in indexes_after.values()))

    def test_run_mongo_benchmark(self):
        res = self.bench.run_configuration_benchmark(
            database_type="MongoDB",
            workload_mix_name="Read-heavy (95% Read / 5% Write)",
            read_ratio=0.95,
            candidate_config_name="Single-Field",
            operation_count=15,
            warmup_count=2,
            user_priority="Prioritize reads"
        )
        self.assertIn("experiment_id", res)
        self.assertIn("baseline", res)
        self.assertIn("candidate", res)
        self.assertIn("recommendation", res)
        print("\nBenchmark Finished. Experiment ID:", res["experiment_id"], "Rec:", res["recommendation"]["classification"])

if __name__ == "__main__":
    unittest.main()
