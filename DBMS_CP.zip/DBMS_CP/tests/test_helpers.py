"""
Unit Tests for Utility Helper Functions, including datetime formatting.
"""

import unittest
import datetime
from utils.helpers import format_timestamp, format_duration, format_bytes

class TestHelpers(unittest.TestCase):
    def test_format_timestamp_with_datetime(self):
        """Verifies that Python datetime objects are formatted with strftime()."""
        dt = datetime.datetime(2026, 11, 4, 22, 20, 53)
        formatted = format_timestamp(dt)
        self.assertEqual(formatted, "2026-11-04 22:20:53")

    def test_format_timestamp_with_date(self):
        """Verifies that date objects format cleanly."""
        d = datetime.date(2026, 11, 4)
        formatted = format_timestamp(d)
        self.assertEqual(formatted, "2026-11-04 00:00:00")

    def test_format_timestamp_with_none(self):
        """Verifies graceful handling when benchmark timestamp is None."""
        self.assertEqual(format_timestamp(None), "N/A")

    def test_format_timestamp_with_empty_or_na(self):
        """Verifies graceful handling of empty or 'N/A' strings."""
        self.assertEqual(format_timestamp(""), "N/A")
        self.assertEqual(format_timestamp("   "), "N/A")
        self.assertEqual(format_timestamp("N/A"), "N/A")

    def test_format_timestamp_with_iso_strings(self):
        """Verifies that ISO-8601 strings from JSON fallbacks are parsed and formatted with strftime()."""
        iso_str = "2026-11-04T22:20:53.123456"
        self.assertEqual(format_timestamp(iso_str), "2026-11-04 22:20:53")

        iso_no_micro = "2026-11-04T22:20:53"
        self.assertEqual(format_timestamp(iso_no_micro), "2026-11-04 22:20:53")

        sql_str = "2026-11-04 22:20:53"
        self.assertEqual(format_timestamp(sql_str), "2026-11-04 22:20:53")

    def test_format_duration(self):
        self.assertEqual(format_duration(None), "N/A")
        self.assertEqual(format_duration(0.5), "500.0 µs")
        self.assertEqual(format_duration(150.25), "150.25 ms")
        self.assertEqual(format_duration(2500.0), "2.50 s")

    def test_format_bytes(self):
        self.assertEqual(format_bytes(None), "N/A")
        self.assertEqual(format_bytes(1024), "1.00 KB")
        self.assertEqual(format_bytes(1048576), "1.00 MB")

if __name__ == "__main__":
    unittest.main()
