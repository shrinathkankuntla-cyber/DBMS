import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import unittest
from optimizer.cost_model import CostModel
from optimizer.recommendation_engine import RecommendationEngine

class TestRecommendations(unittest.TestCase):
    def setUp(self):
        self.cost_model = CostModel()
        self.recommender = RecommendationEngine()

    def test_cost_model_calculations(self):
        baseline = {
            "total_operations": 50,
            "read_latency_stats": {"median_ms": 10.0, "mean_ms": 10.5},
            "write_latency_stats": {"median_ms": 5.0, "mean_ms": 5.2},
            "total_duration_ms": 1000.0,
            "index_storage_bytes": 1024
        }
        candidate = {
            "total_operations": 50,
            "read_latency_stats": {"median_ms": 4.0, "mean_ms": 4.2}, # 60% faster
            "write_latency_stats": {"median_ms": 5.5, "mean_ms": 5.7}, # 10% penalty
            "total_duration_ms": 600.0,
            "index_storage_bytes": 2048
        }

        tradeoffs = self.cost_model.calculate_tradeoffs(baseline, candidate, "Balance reads and writes")

        # Read improvement: (10.0 - 4.0)/10.0 * 100 = 60.0%
        self.assertAlmostEqual(tradeoffs["read"]["improvement_pct"], 60.0, places=1)
        # Write penalty: (5.5 - 5.0)/5.0 * 100 = 10.0%
        self.assertAlmostEqual(tradeoffs["write"]["penalty_pct"], 10.0, places=1)
        # Storage delta: 2048 - 1024 = 1024
        self.assertEqual(tradeoffs["storage"]["delta_bytes"], 1024)
        # Net utility should be positive
        self.assertGreater(tradeoffs["net_utility"], 0.0)

    def test_recommendation_classification(self):
        baseline = {
            "total_operations": 50,
            "read_latency_stats": {"median_ms": 20.0},
            "write_latency_stats": {"median_ms": 5.0},
            "total_duration_ms": 1500.0,
            "index_storage_bytes": 1000
        }
        candidate_good = {
            "total_operations": 50,
            "read_latency_stats": {"median_ms": 5.0}, # 75% faster
            "write_latency_stats": {"median_ms": 5.2}, # 4% penalty
            "total_duration_ms": 700.0,
            "index_storage_bytes": 1200
        }

        rec = self.recommender.generate_recommendation(
            index_name="idx_test",
            database="MongoDB",
            workload_name="Read-heavy",
            baseline_metrics=baseline,
            candidate_metrics=candidate_good,
            user_priority="Prioritize reads"
        )
        self.assertEqual(rec["classification"], "Recommended")
        self.assertIn("read_change_pct", rec["measurements"])

if __name__ == "__main__":
    unittest.main()
