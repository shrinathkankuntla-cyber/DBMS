import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import unittest
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase

class TestConnections(unittest.TestCase):
    def test_mongodb_connection(self):
        mongo = MongoDBDatabase()
        success, msg = mongo.test_connection()
        print("\nMongoDB Test Result:", success, msg)
        self.assertTrue(success, f"MongoDB connection failed: {msg}")

    def test_mongodb_init_collection(self):
        mongo = MongoDBDatabase()
        success, msg = mongo.init_collection()
        print("\nMongoDB Init Result:", success, msg)
        self.assertTrue(success, f"MongoDB init failed: {msg}")
        
        # Check identity index exists
        indexes = mongo.list_indexes("product_catalog")
        has_id_idx = any("product_id" in str(idx.get("key", [])) for idx in indexes.values())
        self.assertTrue(has_id_idx, "Identity index missing on product_catalog")

    def test_mysql_connection_structure(self):
        mysql_db = MySQLDatabase()
        success, msg = mysql_db.test_connection()
        print("\nMySQL Test Result:", success, msg)
        self.assertIsInstance(success, bool)
        self.assertIsInstance(msg, str)

if __name__ == "__main__":
    unittest.main()
