"""
Unit Tests for Olist Brazilian E-Commerce Pipeline & Cart Workload
Tests all 9 file requirements, sample generation, ingestion, MongoDB transformation,
inventory generation, simulated cart transactions, and benchmark isolation.
"""

import unittest
from pathlib import Path
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from data_pipeline.sample_generator import OlistSampleDataGenerator
from data_pipeline.olist_ingestor import OlistIngestor, EXPECTED_FILES
from data_pipeline.benchmark_isolation import BenchmarkDataIsolator
from workloads.cart_workload import CartWorkloadManager

class TestOlistPipeline(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mysql = MySQLDatabase()
        cls.mongo = MongoDBDatabase()
        
        # Test connections
        m_ok, _ = cls.mysql.test_connection()
        mg_ok, _ = cls.mongo.test_connection()
        cls.databases_available = m_ok and mg_ok

        if cls.databases_available:
            cls.mysql.init_schema()
            cls.mongo.init_collection()

    def test_sample_generator_and_file_scan(self):
        """Validates that all 9 expected Olist CSV files are generated and scanned."""
        gen = OlistSampleDataGenerator()
        counts = gen.generate_all_samples(num_customers=50, num_products=30, num_sellers=10, num_orders=40)
        
        self.assertEqual(len(counts), 9)
        for f in EXPECTED_FILES:
            self.assertIn(f, counts)
            self.assertGreater(counts[f], 0)

        ingestor = OlistIngestor(mysql_db=self.mysql, mongo_db=self.mongo)
        file_status = ingestor.scan_raw_files()
        for f in EXPECTED_FILES:
            self.assertTrue(file_status[f]["exists"], f"File {f} should exist in data/raw")
            self.assertGreater(file_status[f]["size_bytes"], 0)

    def test_ingestion_and_relational_mapping(self):
        """Tests ingestion of Olist dataset into MySQL and MongoDB."""
        if not self.databases_available:
            self.skipTest("Databases not available.")

        ingestor = OlistIngestor(mysql_db=self.mysql, mongo_db=self.mongo, inventory_seed=42)
        report = ingestor.run_ingestion_pipeline(max_rows_per_file=50)

        self.assertTrue(report["success"], f"Ingestion failed: {report.get('error')}")
        self.assertGreater(report["total_records_inserted"], 0)

        # Check MySQL counts
        counts = self.mysql.get_table_counts()
        self.assertGreater(counts.get("customers", 0), 0)
        self.assertGreater(counts.get("products", 0), 0)
        self.assertGreater(counts.get("inventory", 0), 0)
        self.assertGreater(counts.get("orders", 0), 0)
        self.assertGreater(counts.get("order_items", 0), 0)

        # Check inventory coverage (every product must have an inventory record)
        with self.mysql.get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
            SELECT COUNT(*) as orphans
            FROM products p
            LEFT JOIN inventory i ON p.product_id = i.product_id
            WHERE i.product_id IS NULL
            """)
            row = cursor.fetchone()
            self.assertEqual(row["orphans"], 0, "All products must have inventory records")
            cursor.close()

        # Check MongoDB transformation
        coll = self.mongo.get_collection("product_catalog")
        doc_count = coll.count_documents({"data_origin": "imported"})
        self.assertGreater(doc_count, 0)

        sample_doc = coll.find_one({"data_origin": "imported"})
        self.assertIsNotNone(sample_doc)
        self.assertIn("product_id", sample_doc)
        self.assertIn("attributes", sample_doc)
        self.assertIn("category", sample_doc)

    def test_cart_workload_and_checkout(self):
        """Validates simulated cart activity and ACID checkout."""
        if not self.databases_available:
            self.skipTest("Databases not available.")

        cart_mgr = CartWorkloadManager(self.mysql)

        # Fetch a valid customer and product
        with self.mysql.get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT customer_id FROM customers LIMIT 1")
            c_id = cursor.fetchone()["customer_id"]
            cursor.execute("SELECT product_id FROM products LIMIT 1")
            p_id = cursor.fetchone()["product_id"]
            cursor.close()

        # Add to cart
        add_res = cart_mgr.add_to_cart(c_id, p_id, quantity=2)
        self.assertTrue(add_res["success"], f"Add to cart failed: {add_res.get('error')}")

        # Verify cart items
        items = cart_mgr.get_cart_items(c_id)
        self.assertGreaterEqual(len(items), 1)

        # Checkout cart
        chk_res = cart_mgr.checkout_cart(c_id)
        self.assertTrue(chk_res["success"], f"Checkout failed: {chk_res.get('error')}")
        self.assertIn("order_id", chk_res)

        # Verify cart is empty after checkout
        items_after = cart_mgr.get_cart_items(c_id)
        self.assertEqual(len(items_after), 0)

    def test_benchmark_isolation_and_reset(self):
        """Validates that benchmark mutations can be reset without touching imported historical data."""
        if not self.databases_available:
            self.skipTest("Databases not available.")

        isolator = BenchmarkDataIsolator(self.mysql, self.mongo)
        b_before = isolator.get_data_breakdown()

        # Execute reset
        ok, msg, del_counts = isolator.reset_benchmark_data()
        self.assertTrue(ok, f"Reset failed: {msg}")

        b_after = isolator.get_data_breakdown()
        # Verify imported historical records are strictly preserved
        self.assertEqual(
            b_before["mysql"]["customers"]["imported"],
            b_after["mysql"]["customers"]["imported"]
        )
        self.assertEqual(
            b_before["mysql"]["products"]["imported"],
            b_after["mysql"]["products"]["imported"]
        )
        self.assertEqual(
            b_before["mongodb"]["product_catalog"]["imported"],
            b_after["mongodb"]["product_catalog"]["imported"]
        )
        # Benchmark cart items should now be 0
        self.assertEqual(b_after["mysql"]["cart_items"]["benchmark"], 0)

if __name__ == "__main__":
    unittest.main()
