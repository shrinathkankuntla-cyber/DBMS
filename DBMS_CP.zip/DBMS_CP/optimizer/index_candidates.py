from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple

@dataclass
class IndexDefinition:
    name: str
    target: str # table for MySQL, collection for MongoDB
    database: str # "MySQL" or "MongoDB"
    fields: Any # list of columns for MySQL, list of tuples for MongoDB e.g. [("category", 1)]
    is_compound: bool
    description: str

# MySQL Candidates
MYSQL_CANDIDATE_INDEXES: Dict[str, IndexDefinition] = {
    "idx_products_category_id": IndexDefinition(
        name="idx_products_category_id",
        target="products",
        database="MySQL",
        fields=["category_id"],
        is_compound=False,
        description="Single-column index on products(category_id) to accelerate category filtering."
    ),
    "idx_products_price": IndexDefinition(
        name="idx_products_price",
        target="products",
        database="MySQL",
        fields=["price"],
        is_compound=False,
        description="Single-column index on products(price) to speed up range and sort queries."
    ),
    "idx_orders_customer_id": IndexDefinition(
        name="idx_orders_customer_id",
        target="orders",
        database="MySQL",
        fields=["customer_id"],
        is_compound=False,
        description="Index on orders(customer_id) for customer purchase history queries."
    ),
    "idx_orders_order_date": IndexDefinition(
        name="idx_orders_order_date",
        target="orders",
        database="MySQL",
        fields=["order_date"],
        is_compound=False,
        description="Index on orders(order_date) for sales reporting and date range filters."
    ),
    "idx_order_items_product_id": IndexDefinition(
        name="idx_order_items_product_id",
        target="order_items",
        database="MySQL",
        fields=["product_id"],
        is_compound=False,
        description="Index on order_items(product_id) for top-selling and product velocity reports."
    ),
    "idx_orders_status_date": IndexDefinition(
        name="idx_orders_status_date",
        target="orders",
        database="MySQL",
        fields=["order_status", "order_date"],
        is_compound=True,
        description="Compound index on orders(order_status, order_date) to accelerate sales aggregations."
    ),
    "idx_products_cat_price": IndexDefinition(
        name="idx_products_cat_price",
        target="products",
        database="MySQL",
        fields=["category_id", "price"],
        is_compound=True,
        description="Compound index on products(category_id, price) for combined filter and sort."
    )
}

# MongoDB Candidates
MONGO_CANDIDATE_INDEXES: Dict[str, IndexDefinition] = {
    "idx_cat": IndexDefinition(
        name="idx_cat",
        target="product_catalog",
        database="MongoDB",
        fields=[("category", 1)],
        is_compound=False,
        description="Single-field index on category field."
    ),
    "idx_price": IndexDefinition(
        name="idx_price",
        target="product_catalog",
        database="MongoDB",
        fields=[("price", 1)],
        is_compound=False,
        description="Single-field index on price for range filtering and price sorting."
    ),
    "idx_brand": IndexDefinition(
        name="idx_brand",
        target="product_catalog",
        database="MongoDB",
        fields=[("brand", 1)],
        is_compound=False,
        description="Single-field index on brand name."
    ),
    "idx_status": IndexDefinition(
        name="idx_status",
        target="product_catalog",
        database="MongoDB",
        fields=[("status", 1)],
        is_compound=False,
        description="Single-field index on product status."
    ),
    "idx_cat_price": IndexDefinition(
        name="idx_cat_price",
        target="product_catalog",
        database="MongoDB",
        fields=[("category", 1), ("price", 1)],
        is_compound=True,
        description="Compound index on category and price to eliminate in-memory sort."
    ),
    "idx_cat_brand_price": IndexDefinition(
        name="idx_cat_brand_price",
        target="product_catalog",
        database="MongoDB",
        fields=[("category", 1), ("brand", 1), ("price", 1)],
        is_compound=True,
        description="Compound index covering category, brand, and price queries."
    )
}

# Four canonical experiment configurations required by Section 6:
# 1. Baseline configuration
# 2. Single-field index configuration
# 3. Compound index configuration
# 4. Selected combined index configuration

EXPERIMENT_CONFIGURATIONS = {
    "MySQL": {
        "Baseline": [],
        "Single-Field": ["idx_products_category_id", "idx_products_price", "idx_orders_order_date"],
        "Compound": ["idx_orders_status_date", "idx_products_cat_price"],
        "Combined": ["idx_products_category_id", "idx_products_cat_price", "idx_orders_status_date", "idx_order_items_product_id"]
    },
    "MongoDB": {
        "Baseline": [],
        "Single-Field": ["idx_cat", "idx_price", "idx_brand"],
        "Compound": ["idx_cat_price", "idx_cat_brand_price"],
        "Combined": ["idx_cat", "idx_cat_price", "idx_cat_brand_price"]
    }
}
