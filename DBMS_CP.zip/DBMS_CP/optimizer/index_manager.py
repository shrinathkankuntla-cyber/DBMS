import time
from typing import Optional, Dict, Any, List, Tuple
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from optimizer.index_candidates import (
    MYSQL_CANDIDATE_INDEXES,
    MONGO_CANDIDATE_INDEXES,
    EXPERIMENT_CONFIGURATIONS,
    IndexDefinition
)
from utils.helpers import Timer
from utils.logger import get_logger

logger = get_logger("index_manager")

# Strictly protected indexes that must NEVER be dropped
PROTECTED_INDEX_NAMES = {
    "PRIMARY",
    "email",
    "category_name",
    "fk_products_category",
    "fk_inventory_product",
    "fk_orders_customer",
    "fk_order_items_order",
    "fk_order_items_product",
    "fk_cart_customer",
    "fk_cart_product",
    "uq_cart_customer_product",
    "_id_",
    "idx_identity_product_id",
    "product_id_1"
}

class IndexManager:
    """
    Safely creates, drops, and measures index sizes for candidate workload-specific
    indexes on MySQL and MongoDB.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None, mongo_db: Optional[MongoDBDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()
        self.mongo = mongo_db or MongoDBDatabase()

    # --- MySQL Operations ---

    def list_mysql_indexes(self, table_name: str) -> List[Dict[str, Any]]:
        """Lists indexes on a given table."""
        return self.mysql.get_index_statistics(table_name)

    def get_mysql_index_sizes(self) -> Dict[str, int]:
        """
        Retrieves actual storage size in bytes for table indexes from information_schema.
        """
        sql = """
            SELECT table_name, index_length, data_length
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
        """
        success, rows, _ = self.mysql.execute_query(sql, fetch=True)
        sizes = {}
        if success and rows:
            for r in rows:
                sizes[r["table_name"]] = {
                    "index_bytes": int(r.get("index_length") or 0),
                    "data_bytes": int(r.get("data_length") or 0)
                }
        return sizes

    def create_mysql_index(self, index_name: str) -> Dict[str, Any]:
        """Creates a candidate index on MySQL."""
        candidate = MYSQL_CANDIDATE_INDEXES.get(index_name)
        if not candidate:
            return {"success": False, "error": f"Unknown MySQL index '{index_name}'", "creation_time_ms": 0.0}

        fields_sql = ", ".join(f"`{col}`" for col in candidate.fields)
        sql = f"CREATE INDEX `{candidate.name}` ON `{candidate.target}` ({fields_sql})"

        with Timer() as timer:
            success, _, err = self.mysql.execute_query(sql, fetch=False)

        if not success:
            # Check if duplicate key name error (1061)
            if "Duplicate key name" in str(err):
                return {"success": True, "note": "Index already exists", "creation_time_ms": 0.0}
            return {"success": False, "error": str(err), "creation_time_ms": timer.elapsed_ms}

        return {"success": True, "index_name": index_name, "creation_time_ms": timer.elapsed_ms, "error": None}

    def drop_mysql_index(self, index_name: str) -> Dict[str, Any]:
        """Safely drops a candidate index on MySQL. Rejects protected indexes."""
        if index_name in PROTECTED_INDEX_NAMES:
            return {"success": False, "error": f"Index '{index_name}' is protected and cannot be dropped."}

        candidate = MYSQL_CANDIDATE_INDEXES.get(index_name)
        if not candidate:
            return {"success": False, "error": f"Unknown candidate index '{index_name}'"}

        sql = f"DROP INDEX `{candidate.name}` ON `{candidate.target}`"
        with Timer() as timer:
            success, _, err = self.mysql.execute_query(sql, fetch=False)

        if not success and "check that column/key exists" in str(err).lower():
            return {"success": True, "note": "Index does not exist", "duration_ms": 0.0}

        return {"success": success, "index_name": index_name, "duration_ms": timer.elapsed_ms, "error": err}

    def reset_mysql_to_baseline(self) -> Dict[str, Any]:
        """Drops all candidate indexes on MySQL, restoring baseline."""
        results = {}
        for idx_name in MYSQL_CANDIDATE_INDEXES:
            res = self.drop_mysql_index(idx_name)
            results[idx_name] = res.get("success", False)
        return results

    # --- MongoDB Operations ---

    def list_mongo_indexes(self, collection_name: str = "product_catalog") -> Dict[str, Any]:
        """Returns existing MongoDB index specifications."""
        return self.mongo.list_indexes(collection_name)

    def get_mongo_index_sizes(self, collection_name: str = "product_catalog") -> Dict[str, Any]:
        """Returns index storage stats from MongoDB collstats."""
        stats = self.mongo.get_collection_stats(collection_name)
        return {
            "total_index_size_bytes": stats.get("total_index_size_bytes", 0),
            "index_sizes": stats.get("index_sizes", {}),
            "count": stats.get("count", 0)
        }

    def create_mongo_index(self, index_name: str) -> Dict[str, Any]:
        """Creates a candidate index on MongoDB."""
        candidate = MONGO_CANDIDATE_INDEXES.get(index_name)
        if not candidate:
            return {"success": False, "error": f"Unknown MongoDB candidate index '{index_name}'", "creation_time_ms": 0.0}

        coll = self.mongo.get_collection(candidate.target)
        with Timer() as timer:
            try:
                coll.create_index(candidate.fields, name=candidate.name)
                return {"success": True, "index_name": index_name, "creation_time_ms": timer.elapsed_ms, "error": None}
            except Exception as e:
                return {"success": False, "error": str(e), "creation_time_ms": timer.elapsed_ms}

    def drop_mongo_index(self, index_name: str) -> Dict[str, Any]:
        """Safely drops a candidate index on MongoDB. Rejects protected indexes."""
        if index_name in PROTECTED_INDEX_NAMES:
            return {"success": False, "error": f"Index '{index_name}' is protected and cannot be dropped."}

        candidate = MONGO_CANDIDATE_INDEXES.get(index_name)
        if not candidate:
            return {"success": False, "error": f"Unknown MongoDB candidate '{index_name}'"}

        coll = self.mongo.get_collection(candidate.target)
        with Timer() as timer:
            try:
                coll.drop_index(candidate.name)
                return {"success": True, "index_name": index_name, "duration_ms": timer.elapsed_ms, "error": None}
            except Exception as e:
                # If index doesn't exist, treat as success
                if "index not found" in str(e).lower():
                    return {"success": True, "note": "Index not found", "duration_ms": timer.elapsed_ms, "error": None}
                return {"success": False, "error": str(e), "duration_ms": timer.elapsed_ms}

    def reset_mongo_to_baseline(self) -> Dict[str, Any]:
        """Drops all candidate indexes on MongoDB, preserving mandatory identity index."""
        results = {}
        for idx_name in MONGO_CANDIDATE_INDEXES:
            res = self.drop_mongo_index(idx_name)
            results[idx_name] = res.get("success", False)
        return results

    # --- Configuration Application ---

    def apply_configuration(self, database_type: str, config_name: str) -> Dict[str, Any]:
        """
        Applies one of the four required experiment configurations:
        Baseline, Single-Field, Compound, Combined.
        First resets to baseline, then creates the designated candidate indexes.
        """
        db_type = "MySQL" if database_type.upper() == "MYSQL" else "MongoDB"
        configs = EXPERIMENT_CONFIGURATIONS.get(db_type, {})
        target_indexes = configs.get(config_name)

        if target_indexes is None:
            return {"success": False, "error": f"Unknown configuration '{config_name}' for {db_type}"}

        # 1. Reset to baseline
        if db_type == "MySQL":
            self.reset_mysql_to_baseline()
        else:
            self.reset_mongo_to_baseline()

        # 2. If baseline, we are done
        if not target_indexes:
            return {
                "success": True,
                "database": db_type,
                "configuration": config_name,
                "indexes_applied": [],
                "created_count": 0
            }

        # 3. Create requested candidate indexes
        created = []
        errors = []
        for idx_name in target_indexes:
            if db_type == "MySQL":
                res = self.create_mysql_index(idx_name)
            else:
                res = self.create_mongo_index(idx_name)

            if res.get("success"):
                created.append(idx_name)
            else:
                errors.append(f"{idx_name}: {res.get('error')}")

        return {
            "success": len(errors) == 0,
            "database": db_type,
            "configuration": config_name,
            "indexes_applied": created,
            "errors": errors if errors else None
        }
