from typing import Dict, Any, List, Optional
from optimizer.cost_model import CostModel

class RecommendationEngine:
    """
    Synthesizes measured benchmark metrics, storage statistics, and user priority goals
    into transparent, evidence-based indexing recommendations.
    """
    def __init__(self):
        self.cost_model = CostModel()

    def generate_recommendation(
        self,
        index_name: str,
        database: str,
        workload_name: str,
        baseline_metrics: Dict[str, Any],
        candidate_metrics: Dict[str, Any],
        user_priority: str = "Balance reads and writes"
    ) -> Dict[str, Any]:
        """
        Classifies an indexing configuration and produces a comprehensive audit report.
        """
        tradeoffs = self.cost_model.calculate_tradeoffs(baseline_metrics, candidate_metrics, user_priority)

        read_imp = tradeoffs["read"]["improvement_pct"]
        write_pen = tradeoffs["write"]["penalty_pct"]
        total_imp = tradeoffs["total_duration"]["improvement_pct"]
        net_util = tradeoffs["net_utility"]
        storage_growth = tradeoffs["storage"]["growth_pct"]

        # Check evidence sufficiency
        base_ops = baseline_metrics.get("total_operations", 0)
        cand_ops = candidate_metrics.get("total_operations", 0)
        if base_ops < 15 or cand_ops < 15:
            classification = "Insufficient evidence"
            confidence = "Low (Sample size < 15 operations; run more repetitions)"
            explanation = (
                f"Evaluation sample size ({cand_ops} ops) is too small to establish statistical significance. "
                "Baseline and candidate variations may reflect transient system jitter rather than index utility."
            )
        elif net_util > 15.0 and read_imp > 10.0:
            classification = "Recommended"
            confidence = "High"
            explanation = (
                f"Candidate configuration yields significant read latency reduction ({read_imp:+.1f}%) "
                f"with an acceptable write penalty ({write_pen:+.1f}%), delivering a positive net utility score of {net_util:+.1f} "
                f"under '{user_priority}' priority."
            )
        elif read_imp > 15.0 and write_pen > 20.0:
            classification = "Conditionally useful"
            confidence = "High"
            explanation = (
                f"Strong read acceleration ({read_imp:+.1f}%), but accompanied by non-trivial write overhead ({write_pen:+.1f}%). "
                f"Highly suitable for read-heavy catalogue browsing, but potentially detrimental if write volumes surge."
            )
        elif abs(net_util) <= 8.0 and abs(read_imp) < 10.0:
            classification = "Neutral"
            confidence = "Moderate"
            explanation = (
                f"Marginal difference observed (Read change: {read_imp:+.1f}%, Total duration change: {total_imp:+.1f}%). "
                f"The index consumes {tradeoffs['storage']['delta_bytes']} additional bytes with negligible latency impact."
            )
        else:
            classification = "Not recommended"
            confidence = "High"
            reasons = []
            if write_pen > 25.0:
                reasons.append(f"excessive write penalty ({write_pen:+.1f}%)")
            if read_imp <= 0.0:
                reasons.append(f"zero read improvement ({read_imp:+.1f}%)")
            if storage_growth > 50.0:
                reasons.append(f"significant index storage growth ({storage_growth:+.1f}%)")
            reason_str = ", ".join(reasons) if reasons else "negative net workload utility"
            explanation = (
                f"Configuration is suboptimal under '{user_priority}' priority due to {reason_str}. "
                f"Net utility score: {net_util:+.1f}."
            )

        return {
            "index_name": index_name,
            "database": database,
            "workload": workload_name,
            "user_priority": user_priority,
            "classification": classification,
            "confidence": confidence,
            "explanation": explanation,
            "tradeoffs": tradeoffs,
            "measurements": {
                "baseline_read_ms": tradeoffs["read"]["baseline_median_ms"],
                "candidate_read_ms": tradeoffs["read"]["candidate_median_ms"],
                "read_change_pct": read_imp,
                "baseline_write_ms": tradeoffs["write"]["baseline_median_ms"],
                "candidate_write_ms": tradeoffs["write"]["candidate_median_ms"],
                "write_change_pct": write_pen,
                "baseline_total_ms": tradeoffs["total_duration"]["baseline_ms"],
                "candidate_total_ms": tradeoffs["total_duration"]["candidate_ms"],
                "total_change_pct": total_imp,
                "storage_delta_bytes": tradeoffs["storage"]["delta_bytes"],
                "net_utility_score": net_util
            }
        }
