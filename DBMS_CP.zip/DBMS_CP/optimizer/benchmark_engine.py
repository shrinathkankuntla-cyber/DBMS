import uuid
import json
import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List, Callable
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from workloads.workload_generator import WorkloadGenerator
from optimizer.index_manager import IndexManager
from optimizer.explain_analyzer import ExplainAnalyzer
from optimizer.recommendation_engine import RecommendationEngine
from utils.logger import get_logger

logger = get_logger("benchmark_engine")

LOCAL_EXP_DIR = Path(__file__).resolve().parent.parent / "data" / "experiments"
LOCAL_EXP_DIR.mkdir(parents=True, exist_ok=True)

class BenchmarkEngine:
    """
    Orchestrates end-to-end benchmark trials comparing baseline and candidate
    indexing configurations under controlled e-commerce workloads.
    """
    def __init__(
        self,
        mysql_db: Optional[MySQLDatabase] = None,
        mongo_db: Optional[MongoDBDatabase] = None,
        seed: int = 42
    ):
        self.mysql = mysql_db or MySQLDatabase()
        self.mongo = mongo_db or MongoDBDatabase()
        self.seed = seed
        self.index_mgr = IndexManager(self.mysql, self.mongo)
        self.explain_analyzer = ExplainAnalyzer(self.mysql, self.mongo)
        self.recommender = RecommendationEngine()

    def run_configuration_benchmark(
        self,
        database_type: str, # "MySQL" or "MongoDB"
        workload_mix_name: str, # e.g. "Read-heavy (95% Read / 5% Write)"
        read_ratio: float,
        candidate_config_name: str, # "Single-Field", "Compound", "Combined"
        operation_count: int = 50,
        warmup_count: int = 10,
        user_priority: str = "Balance reads and writes",
        progress_callback: Optional[Callable[[str, float], None]] = None
    ) -> Dict[str, Any]:
        """
        Executes a comprehensive comparison:
        1. Reset and benchmark Baseline configuration.
        2. Apply Candidate configuration and benchmark.
        3. Capture EXPLAIN plans outside timed workload.
        4. Compute mathematical trade-offs and recommendations.
        5. Persist results in MySQL and local storage.
        """
        experiment_id = f"EXP-{uuid.uuid4().hex[:12].upper()}"
        generator = WorkloadGenerator(self.mysql, self.mongo, seed=self.seed)

        # Step 1: Baseline Evaluation
        if progress_callback:
            progress_callback("Applying Baseline indexing configuration...", 0.10)
        self.index_mgr.apply_configuration(database_type, "Baseline")

        base_storage = self._get_storage_bytes(database_type)

        if progress_callback:
            progress_callback("Executing Baseline workload...", 0.25)
        base_res = generator.execute_workload(
            database_target=database_type,
            total_operations=operation_count,
            read_ratio=read_ratio,
            warmup_operations=warmup_count
        )
        base_res["index_storage_bytes"] = base_storage

        # Step 2: Candidate Evaluation
        if progress_callback:
            progress_callback(f"Applying '{candidate_config_name}' indexing configuration...", 0.50)
        apply_res = self.index_mgr.apply_configuration(database_type, candidate_config_name)

        cand_storage = self._get_storage_bytes(database_type)

        if progress_callback:
            progress_callback(f"Executing '{candidate_config_name}' candidate workload...", 0.65)
        cand_res = generator.execute_workload(
            database_target=database_type,
            total_operations=operation_count,
            read_ratio=read_ratio,
            warmup_operations=warmup_count
        )
        cand_res["index_storage_bytes"] = cand_storage

        # Step 3: Capture Query Plans (Outside timed workload)
        if progress_callback:
            progress_callback("Inspecting execution plans (EXPLAIN / executionStats)...", 0.85)
        explain_sample = self._sample_explain_plan(database_type)

        # Step 4: Generate Recommendation
        if progress_callback:
            progress_callback("Calculating trade-offs and synthesizing recommendations...", 0.95)
        rec = self.recommender.generate_recommendation(
            index_name=candidate_config_name,
            database=database_type,
            workload_name=workload_mix_name,
            baseline_metrics=base_res,
            candidate_metrics=cand_res,
            user_priority=user_priority
        )

        benchmark_result = {
            "experiment_id": experiment_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "database": database_type,
            "workload_name": workload_mix_name,
            "candidate_configuration": candidate_config_name,
            "indexes_applied": apply_res.get("indexes_applied", []),
            "operation_count": operation_count,
            "read_ratio": read_ratio,
            "write_ratio": round(1.0 - read_ratio, 2),
            "baseline": base_res,
            "candidate": cand_res,
            "explain_plan": explain_sample,
            "recommendation": rec
        }

        # Step 5: Persist Experiment Record
        self._persist_experiment(benchmark_result)

        if progress_callback:
            progress_callback("Benchmark complete!", 1.0)

        return benchmark_result

    def _get_storage_bytes(self, database_type: str) -> int:
        try:
            if database_type.upper() == "MYSQL":
                sizes = self.index_mgr.get_mysql_index_sizes()
                return sum(v["index_bytes"] for v in sizes.values())
            else:
                stats = self.index_mgr.get_mongo_index_sizes()
                return stats.get("total_index_size_bytes", 0)
        except Exception as e:
            logger.warning(f"Failed to measure index storage: {e}")
            return 0

    def _sample_explain_plan(self, database_type: str) -> Dict[str, Any]:
        """Runs a representative explain plan for the target database."""
        try:
            if database_type.upper() == "MYSQL":
                sample_sql = "SELECT p.* FROM products p WHERE p.category_id = 5 AND p.price BETWEEN 50 AND 300 ORDER BY p.price ASC LIMIT 25"
                return self.explain_analyzer.explain_mysql_query(sample_sql)
            else:
                return self.explain_analyzer.explain_mongo_query(
                    collection_name="product_catalog",
                    filter_doc={"category": "Laptops & Computers", "price": {"$gte": 50.0, "$lte": 500.0}},
                    sort_doc=[("price", 1)],
                    limit=25
                )
        except Exception as e:
            return {"error": str(e)}

    def _persist_experiment(self, result: Dict[str, Any]):
        """Persists experiment into MySQL experiments table and local JSON file."""
        exp_id = result["experiment_id"]
        rec = result["recommendation"]
        tradeoffs = rec["tradeoffs"]

        # 1. MySQL Persistence
        try:
            insert_exp_sql = """
                INSERT INTO experiments (
                    experiment_id, created_at, database_type, workload_name,
                    config_type, read_ratio, write_ratio, operation_count,
                    total_duration_ms, notes
                ) VALUES (%s, NOW(), %s, %s, %s, %s, %s, %s, %s, %s)
            """
            success, _, err = self.mysql.execute_query(insert_exp_sql, (
                exp_id,
                result["database"],
                result["workload_name"],
                result["candidate_configuration"],
                result["read_ratio"],
                result["write_ratio"],
                result["operation_count"],
                result["candidate"]["total_duration_ms"],
                f"Priority: {rec['user_priority']} | Class: {rec['classification']}"
            ), fetch=False)

            if success:
                # Insert metrics
                metrics = [
                    (exp_id, "baseline_median_read_ms", tradeoffs["read"]["baseline_median_ms"], "ms"),
                    (exp_id, "candidate_median_read_ms", tradeoffs["read"]["candidate_median_ms"], "ms"),
                    (exp_id, "read_improvement_pct", tradeoffs["read"]["improvement_pct"], "%"),
                    (exp_id, "baseline_median_write_ms", tradeoffs["write"]["baseline_median_ms"], "ms"),
                    (exp_id, "candidate_median_write_ms", tradeoffs["write"]["candidate_median_ms"], "ms"),
                    (exp_id, "write_penalty_pct", tradeoffs["write"]["penalty_pct"], "%"),
                    (exp_id, "net_utility_score", tradeoffs["net_utility"], "score")
                ]
                for m in metrics:
                    self.mysql.execute_query(
                        "INSERT INTO experiment_metrics (experiment_id, metric_name, metric_value, unit) VALUES (%s, %s, %s, %s)",
                        m, fetch=False
                    )

                # Insert recommendation
                self.mysql.execute_query(
                    """
                    INSERT INTO experiment_recommendations (
                        experiment_id, index_name, classification, read_improvement_pct,
                        write_penalty_pct, storage_impact_bytes, reasoning
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        exp_id,
                        result["candidate_configuration"],
                        rec["classification"],
                        tradeoffs["read"]["improvement_pct"],
                        tradeoffs["write"]["penalty_pct"],
                        tradeoffs["storage"]["delta_bytes"],
                        rec["explanation"]
                    ),
                    fetch=False
                )
        except Exception as e:
            logger.warning(f"Could not persist experiment to MySQL (fallback to file): {e}")

        # 2. Local File Persistence
        try:
            file_path = LOCAL_EXP_DIR / f"{exp_id}.json"
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to persist experiment to file: {e}")

    @staticmethod
    def list_experiments(mysql_db: Optional[MySQLDatabase] = None) -> List[Dict[str, Any]]:
        """
        Retrieves historical experiment logs from MySQL or local JSON store.
        """
        mysql_db = mysql_db or MySQLDatabase()
        sql = """
            SELECT e.experiment_id, e.created_at, e.database_type, e.workload_name,
                   e.config_type, e.operation_count, e.total_duration_ms,
                   r.classification, r.read_improvement_pct, r.write_penalty_pct
            FROM experiments e
            LEFT JOIN experiment_recommendations r ON e.experiment_id = r.experiment_id
            ORDER BY e.created_at DESC
        """
        success, rows, _ = mysql_db.execute_query(sql, fetch=True)
        if success and rows:
            return rows

        # Fallback to local files
        experiments = []
        for file in sorted(LOCAL_EXP_DIR.glob("*.json"), reverse=True):
            try:
                with open(file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    rec = data.get("recommendation", {})
                    tradeoffs = rec.get("tradeoffs", {})
                    experiments.append({
                        "experiment_id": data.get("experiment_id"),
                        "created_at": data.get("timestamp"),
                        "database_type": data.get("database"),
                        "workload_name": data.get("workload_name"),
                        "config_type": data.get("candidate_configuration"),
                        "operation_count": data.get("operation_count"),
                        "total_duration_ms": data.get("candidate", {}).get("total_duration_ms"),
                        "classification": rec.get("classification"),
                        "read_improvement_pct": tradeoffs.get("read", {}).get("improvement_pct"),
                        "write_penalty_pct": tradeoffs.get("write", {}).get("penalty_pct")
                    })
            except Exception:
                pass
        return experiments
