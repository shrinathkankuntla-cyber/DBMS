from typing import Dict, Any

class CostModel:
    """
    Evaluates transparent cost-performance trade-offs between baseline and
    candidate indexing configurations using deterministic mathematical formulas.
    """
    PRIORITY_WEIGHTS = {
        "Prioritize reads": {"w_read": 0.80, "w_write": 0.15, "w_storage": 0.05},
        "Balance reads and writes": {"w_read": 0.50, "w_write": 0.40, "w_storage": 0.10},
        "Prioritize writes": {"w_read": 0.20, "w_write": 0.70, "w_storage": 0.10},
        "Minimize storage": {"w_read": 0.30, "w_write": 0.20, "w_storage": 0.50}
    }

    @staticmethod
    def calculate_tradeoffs(
        baseline_metrics: Dict[str, Any],
        candidate_metrics: Dict[str, Any],
        priority: str = "Balance reads and writes"
    ) -> Dict[str, Any]:
        """
        Computes explicit percentage changes and weighted utility score.
        """
        # 1. Read Latency (Median or Mean)
        base_read = baseline_metrics.get("read_latency_stats", {}).get("median_ms") or \
                    baseline_metrics.get("read_latency_stats", {}).get("mean_ms", 0.0)
        cand_read = candidate_metrics.get("read_latency_stats", {}).get("median_ms") or \
                    candidate_metrics.get("read_latency_stats", {}).get("mean_ms", 0.0)

        # Read Improvement %: positive means faster (reduced latency)
        if base_read > 0:
            read_improvement_pct = ((base_read - cand_read) / base_read) * 100.0
        else:
            read_improvement_pct = 0.0

        # 2. Write Latency
        base_write = baseline_metrics.get("write_latency_stats", {}).get("median_ms") or \
                     baseline_metrics.get("write_latency_stats", {}).get("mean_ms", 0.0)
        cand_write = candidate_metrics.get("write_latency_stats", {}).get("median_ms") or \
                     candidate_metrics.get("write_latency_stats", {}).get("mean_ms", 0.0)

        # Write Penalty %: positive means slower (higher write latency)
        if base_write > 0:
            write_penalty_pct = ((cand_write - base_write) / base_write) * 100.0
        else:
            write_penalty_pct = 0.0

        # 3. Total Workload Duration
        base_total = baseline_metrics.get("total_duration_ms", 0.0)
        cand_total = candidate_metrics.get("total_duration_ms", 0.0)
        if base_total > 0:
            total_duration_change_pct = ((base_total - cand_total) / base_total) * 100.0
        else:
            total_duration_change_pct = 0.0

        # 4. Storage Impact
        base_storage = baseline_metrics.get("index_storage_bytes", 0)
        cand_storage = candidate_metrics.get("index_storage_bytes", 0)
        storage_delta_bytes = cand_storage - base_storage
        storage_growth_pct = ((storage_delta_bytes / base_storage) * 100.0) if base_storage > 0 else 0.0

        # 5. Weighted Utility Score (-100 to +100 scale)
        weights = CostModel.PRIORITY_WEIGHTS.get(priority, CostModel.PRIORITY_WEIGHTS["Balance reads and writes"])
        w_read = weights["w_read"]
        w_write = weights["w_write"]
        w_storage = weights["w_storage"]

        # Utility calculation:
        # read_improvement_pct is positive if beneficial
        # write_penalty_pct is subtracted (harmful)
        # storage_growth is bounded and subtracted
        clamped_read = max(-100.0, min(100.0, read_improvement_pct))
        clamped_write_pen = max(-100.0, min(100.0, write_penalty_pct))
        clamped_storage_pen = min(100.0, max(0.0, storage_growth_pct * 0.1))

        net_utility = (clamped_read * w_read) - (clamped_write_pen * w_write) - (clamped_storage_pen * w_storage)

        return {
            "priority": priority,
            "weights": weights,
            "read": {
                "baseline_median_ms": round(base_read, 4),
                "candidate_median_ms": round(cand_read, 4),
                "improvement_pct": round(read_improvement_pct, 2)
            },
            "write": {
                "baseline_median_ms": round(base_write, 4),
                "candidate_median_ms": round(cand_write, 4),
                "penalty_pct": round(write_penalty_pct, 2)
            },
            "total_duration": {
                "baseline_ms": round(base_total, 2),
                "candidate_ms": round(cand_total, 2),
                "improvement_pct": round(total_duration_change_pct, 2)
            },
            "storage": {
                "baseline_bytes": base_storage,
                "candidate_bytes": cand_storage,
                "delta_bytes": storage_delta_bytes,
                "growth_pct": round(storage_growth_pct, 2)
            },
            "net_utility": round(net_utility, 2)
        }
