from typing import Optional, Dict, Any, List
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from utils.logger import get_logger

logger = get_logger("explain_analyzer")

class ExplainAnalyzer:
    """
    Executes and parses real database execution plans (EXPLAIN / EXPLAIN ANALYZE)
    for MySQL and MongoDB without guessing or fabrication.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None, mongo_db: Optional[MongoDBDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()
        self.mongo = mongo_db or MongoDBDatabase()

    def explain_mysql_query(self, query: str, params: Optional[tuple] = None) -> Dict[str, Any]:
        """
        Executes EXPLAIN and EXPLAIN ANALYZE on a MySQL query.
        Returns plan nodes, scan types, rows examined, and index usage.
        """
        explain_sql = f"EXPLAIN {query}"
        success, rows, err = self.mysql.execute_query(explain_sql, params, fetch=True)

        if not success:
            return {"success": False, "error": err, "plan": None}

        # Try EXPLAIN ANALYZE if supported (MySQL 8.0.18+)
        analyze_output = None
        try:
            analyze_sql = f"EXPLAIN ANALYZE {query}"
            analyze_success, analyze_rows, _ = self.mysql.execute_query(analyze_sql, params, fetch=True)
            if analyze_success and analyze_rows:
                # First column contains the tree representation
                analyze_output = list(analyze_rows[0].values())[0] if analyze_rows[0] else None
        except Exception:
            analyze_output = "EXPLAIN ANALYZE not supported or failed on this query syntax."

        # Analyze plan rows
        is_table_scan = False
        indexes_used = []
        total_rows_examined = 0

        for r in rows:
            scan_type = r.get("type", "")
            key_used = r.get("key")
            rows_est = r.get("rows", 0)

            if scan_type.upper() == "ALL":
                is_table_scan = True
            if key_used:
                indexes_used.append(key_used)
            if rows_est:
                try:
                    total_rows_examined += int(rows_est)
                except (ValueError, TypeError):
                    pass

        return {
            "success": True,
            "database": "MySQL",
            "explain_rows": rows,
            "explain_analyze_raw": analyze_output,
            "summary": {
                "is_table_scan": is_table_scan,
                "indexes_used": list(set(indexes_used)) if indexes_used else ["None (FULL TABLE SCAN)"],
                "total_rows_examined": total_rows_examined,
                "scan_types": [r.get("type") for r in rows]
            }
        }

    def explain_mongo_query(
        self,
        collection_name: str = "product_catalog",
        filter_doc: Optional[Dict[str, Any]] = None,
        sort_doc: Optional[List[tuple]] = None,
        limit: int = 50
    ) -> Dict[str, Any]:
        """
        Executes explain('executionStats') on MongoDB collection.
        Parses winning plan stages, indexes used, and documents examined.
        """
        try:
            coll = self.mongo.get_collection(collection_name)
            cursor = coll.find(filter_doc or {})
            if sort_doc:
                cursor = cursor.sort(sort_doc)
            if limit:
                cursor = cursor.limit(limit)

            raw_plan = cursor.explain("executionStats")

            # Extract executionStats
            exec_stats = raw_plan.get("executionStats", {})
            query_planner = raw_plan.get("queryPlanner", {})
            winning_plan = query_planner.get("winningPlan", {})

            # Traverse plan stages
            stages = []
            indexes_used = []
            curr = winning_plan
            while curr:
                stage_name = curr.get("stage", "")
                if stage_name:
                    stages.append(stage_name)
                if "indexName" in curr:
                    indexes_used.append(curr["indexName"])
                if "inputStage" in curr:
                    curr = curr["inputStage"]
                elif "inputStages" in curr and curr["inputStages"]:
                    curr = curr["inputStages"][0]
                else:
                    break

            is_collscan = "COLLSCAN" in stages

            return {
                "success": True,
                "database": "MongoDB",
                "stages": stages,
                "is_collection_scan": is_collscan,
                "indexes_used": list(set(indexes_used)) if indexes_used else ["None (COLLSCAN)"],
                "docs_examined": exec_stats.get("totalDocsExamined", 0),
                "keys_examined": exec_stats.get("totalKeysExamined", 0),
                "n_returned": exec_stats.get("nReturned", 0),
                "execution_time_ms": exec_stats.get("executionTimeMillis", 0),
                "raw_explain": raw_plan
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
