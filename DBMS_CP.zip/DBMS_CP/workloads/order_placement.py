from typing import Optional, Dict, Any, List
from database.mysql_connection import MySQLDatabase
from utils.helpers import Timer
from utils.logger import get_logger

logger = get_logger("order_placement")

class OrderPlacementWorkload:
    """
    Executes ACID-compliant order placement transactions on MySQL with stock validation.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()

    def place_order(
        self,
        customer_id: int,
        items: List[Dict[str, Any]], # [{"product_id": int, "quantity": int}]
        simulate_failure_step: Optional[str] = None # e.g. "before_inventory", "before_commit"
    ) -> Dict[str, Any]:
        """
        Executes complete transactional order placement.
        Ensures atomic inventory deduction and rollback upon any invariant failure.
        """
        if not items:
            return {"success": False, "error": "Order must contain at least one item.", "duration_ms": 0.0}

        conn = self.mysql.get_raw_connection(include_db=True)
        cursor = conn.cursor(dictionary=True)
        with Timer() as timer:
            try:
                # 1. Validate customer
                cursor.execute("SELECT customer_id, full_name FROM customers WHERE customer_id = %s", (customer_id,))
                cust = cursor.fetchone()
                if not cust:
                    conn.rollback()
                    return {
                        "success": False,
                        "error": f"Customer ID {customer_id} not found.",
                        "duration_ms": timer.elapsed_ms,
                        "order_id": None
                    }

                # 2. Validate product availability and stock with FOR UPDATE locking
                order_total = 0.0
                validated_items = []
                for item in items:
                    prod_id = item["product_id"]
                    req_qty = item["quantity"]

                    if req_qty <= 0:
                        conn.rollback()
                        return {
                            "success": False,
                            "error": f"Invalid quantity {req_qty} for product {prod_id}.",
                            "duration_ms": timer.elapsed_ms,
                            "order_id": None
                        }

                    cursor.execute(
                        "SELECT p.product_id, p.product_name, p.price, p.status, i.stock_quantity "
                        "FROM products p "
                        "JOIN inventory i ON p.product_id = i.product_id "
                        "WHERE p.product_id = %s FOR UPDATE",
                        (prod_id,)
                    )
                    prod = cursor.fetchone()
                    if not prod:
                        conn.rollback()
                        return {
                            "success": False,
                            "error": f"Product ID {prod_id} not found or has no inventory record.",
                            "duration_ms": timer.elapsed_ms,
                            "order_id": None
                        }

                    if prod["status"] != "active":
                        conn.rollback()
                        return {
                            "success": False,
                            "error": f"Product '{prod['product_name']}' is not active ({prod['status']}).",
                            "duration_ms": timer.elapsed_ms,
                            "order_id": None
                        }

                    if prod["stock_quantity"] < req_qty:
                        conn.rollback()
                        return {
                            "success": False,
                            "error": f"Insufficient stock for '{prod['product_name']}': requested {req_qty}, available {prod['stock_quantity']}.",
                            "duration_ms": timer.elapsed_ms,
                            "order_id": None
                        }

                    unit_price = float(prod["price"])
                    subtotal = round(unit_price * req_qty, 2)
                    order_total += subtotal
                    validated_items.append({
                        "product_id": prod_id,
                        "quantity": req_qty,
                        "unit_price": unit_price,
                        "subtotal": subtotal,
                        "new_stock": prod["stock_quantity"] - req_qty
                    })

                # Injected failure check
                if simulate_failure_step == "before_order_insert":
                    raise RuntimeError("Simulated crash before order insertion.")

                # 3. Create order record
                cursor.execute(
                    "INSERT INTO orders (customer_id, order_date, order_status, total_amount) "
                    "VALUES (%s, NOW(), 'completed', %s)",
                    (customer_id, round(order_total, 2))
                )
                order_id = cursor.lastrowid

                if simulate_failure_step == "before_items_insert":
                    raise RuntimeError("Simulated crash after order creation before items insert.")

                # 4. Insert order items & update inventory
                for v in validated_items:
                    cursor.execute(
                        "INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal) "
                        "VALUES (%s, %s, %s, %s, %s)",
                        (order_id, v["product_id"], v["quantity"], v["unit_price"], v["subtotal"])
                    )

                    if simulate_failure_step == "before_inventory":
                        raise RuntimeError("Simulated crash during inventory update.")

                    cursor.execute(
                        "UPDATE inventory SET stock_quantity = %s, updated_at = NOW() WHERE product_id = %s",
                        (v["new_stock"], v["product_id"])
                    )

                if simulate_failure_step == "before_commit":
                    raise RuntimeError("Simulated crash immediately prior to commit.")

                # 5. Commit transaction
                conn.commit()

                return {
                    "success": True,
                    "order_id": order_id,
                    "customer_id": customer_id,
                    "total_amount": round(order_total, 2),
                    "items_count": len(validated_items),
                    "duration_ms": timer.elapsed_ms,
                    "error": None
                }

            except Exception as e:
                conn.rollback()
                logger.warning(f"Order placement failed, transaction rolled back: {e}")
                return {
                    "success": False,
                    "order_id": None,
                    "customer_id": customer_id,
                    "error": str(e),
                    "duration_ms": timer.elapsed_ms
                }
            finally:
                cursor.close()
                conn.close()
