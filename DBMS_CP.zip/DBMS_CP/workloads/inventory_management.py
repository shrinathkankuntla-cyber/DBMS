from typing import Optional, Dict, Any, List
from database.mysql_connection import MySQLDatabase
from utils.helpers import Timer
from utils.logger import get_logger

logger = get_logger("inventory_management")

class InventoryManagementWorkload:
    """
    Executes inventory level checks, restocks, stock adjustments, and deficit alerts.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()

    def check_stock(self, product_id: int) -> Dict[str, Any]:
        """Queries the current real-time stock quantity for a single product."""
        sql = """
            SELECT p.product_id, p.product_name, p.status, i.stock_quantity, i.updated_at
            FROM inventory i
            JOIN products p ON i.product_id = p.product_id
            WHERE i.product_id = %s
        """
        with Timer() as timer:
            success, rows, err = self.mysql.execute_query(sql, (product_id,), fetch=True)
        return {
            "operation": "check_stock",
            "success": success,
            "data": rows[0] if rows else None,
            "duration_ms": timer.elapsed_ms,
            "error": err if not success else None
        }

    def update_stock(self, product_id: int, quantity_delta: int) -> Dict[str, Any]:
        """
        Safely applies a delta to stock (positive for restock, negative for deduction).
        Enforces non-negative stock constraint via transaction.
        """
        conn = self.mysql.get_raw_connection(include_db=True)
        cursor = conn.cursor(dictionary=True)
        with Timer() as timer:
            try:
                # Lock row
                cursor.execute(
                    "SELECT product_id, stock_quantity FROM inventory WHERE product_id = %s FOR UPDATE",
                    (product_id,)
                )
                row = cursor.fetchone()
                if not row:
                    conn.rollback()
                    return {"success": False, "error": f"Inventory record for product {product_id} not found.", "duration_ms": timer.elapsed_ms}

                current_stock = row["stock_quantity"]
                new_stock = current_stock + quantity_delta
                if new_stock < 0:
                    conn.rollback()
                    return {
                        "success": False,
                        "error": f"Cannot reduce stock by {-quantity_delta}: current stock is {current_stock}.",
                        "duration_ms": timer.elapsed_ms
                    }

                cursor.execute(
                    "UPDATE inventory SET stock_quantity = %s, updated_at = NOW() WHERE product_id = %s",
                    (new_stock, product_id)
                )
                conn.commit()
                return {
                    "success": True,
                    "product_id": product_id,
                    "previous_stock": current_stock,
                    "new_stock": new_stock,
                    "delta": quantity_delta,
                    "duration_ms": timer.elapsed_ms,
                    "error": None
                }
            except Exception as e:
                conn.rollback()
                return {"success": False, "error": str(e), "duration_ms": timer.elapsed_ms}
            finally:
                cursor.close()
                conn.close()

    def get_low_stock_products(self, threshold: int = 15, limit: int = 50) -> Dict[str, Any]:
        """Identifies active products where stock is at or below the warning threshold."""
        sql = """
            SELECT p.product_id, p.product_name, c.category_name, i.stock_quantity, i.updated_at
            FROM inventory i
            JOIN products p ON i.product_id = p.product_id
            JOIN categories c ON p.category_id = c.category_id
            WHERE i.stock_quantity <= %s AND i.stock_quantity > 0 AND p.status = 'active'
            ORDER BY i.stock_quantity ASC
            LIMIT %s
        """
        with Timer() as timer:
            success, rows, err = self.mysql.execute_query(sql, (threshold, limit), fetch=True)
        return {
            "operation": "get_low_stock_products",
            "success": success,
            "data": rows or [],
            "count": len(rows) if rows else 0,
            "duration_ms": timer.elapsed_ms,
            "error": err if not success else None
        }

    def get_out_of_stock_products(self, limit: int = 50) -> Dict[str, Any]:
        """Identifies products that are completely depleted (stock_quantity = 0)."""
        sql = """
            SELECT p.product_id, p.product_name, c.category_name, i.stock_quantity, i.updated_at
            FROM inventory i
            JOIN products p ON i.product_id = p.product_id
            JOIN categories c ON p.category_id = c.category_id
            WHERE i.stock_quantity = 0
            ORDER BY p.product_id ASC
            LIMIT %s
        """
        with Timer() as timer:
            success, rows, err = self.mysql.execute_query(sql, (limit,), fetch=True)
        return {
            "operation": "get_out_of_stock_products",
            "success": success,
            "data": rows or [],
            "count": len(rows) if rows else 0,
            "duration_ms": timer.elapsed_ms,
            "error": err if not success else None
        }
