from typing import Optional, Dict, Any, List
from database.mysql_connection import MySQLDatabase
from utils.helpers import Timer
from utils.logger import get_logger

logger = get_logger("cart_updates")

class CartUpdatesWorkload:
    """
    Manages persistent cart operations (add, update quantity, remove, inspect)
    with inventory stock validation in MySQL.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()

    def add_or_update_cart(self, customer_id: int, product_id: int, quantity: int) -> Dict[str, Any]:
        """
        Adds a product to customer's cart or updates quantity if already present.
        Validates stock availability.
        """
        if quantity <= 0:
            return {"success": False, "error": "Quantity must be strictly positive.", "duration_ms": 0.0}

        conn = self.mysql.get_raw_connection(include_db=True)
        cursor = conn.cursor(dictionary=True)
        with Timer() as timer:
            try:
                # Check inventory stock
                cursor.execute(
                    "SELECT p.product_id, p.product_name, p.status, i.stock_quantity "
                    "FROM products p JOIN inventory i ON p.product_id = i.product_id "
                    "WHERE p.product_id = %s",
                    (product_id,)
                )
                prod = cursor.fetchone()
                if not prod:
                    conn.rollback()
                    return {"success": False, "error": f"Product ID {product_id} not found.", "duration_ms": timer.elapsed_ms}

                if prod["status"] != "active":
                    conn.rollback()
                    return {"success": False, "error": f"Product '{prod['product_name']}' is inactive.", "duration_ms": timer.elapsed_ms}

                if prod["stock_quantity"] < quantity:
                    conn.rollback()
                    return {
                        "success": False,
                        "error": f"Insufficient stock for '{prod['product_name']}': requested {quantity}, available {prod['stock_quantity']}.",
                        "duration_ms": timer.elapsed_ms
                    }

                # Upsert into cart_items
                cursor.execute(
                    "INSERT INTO cart_items (customer_id, product_id, quantity, updated_at) "
                    "VALUES (%s, %s, %s, NOW()) "
                    "ON DUPLICATE KEY UPDATE quantity = %s, updated_at = NOW()",
                    (customer_id, product_id, quantity, quantity)
                )
                conn.commit()

                return {
                    "success": True,
                    "customer_id": customer_id,
                    "product_id": product_id,
                    "quantity": quantity,
                    "duration_ms": timer.elapsed_ms,
                    "error": None
                }
            except Exception as e:
                conn.rollback()
                return {"success": False, "error": str(e), "duration_ms": timer.elapsed_ms}
            finally:
                cursor.close()
                conn.close()

    def remove_from_cart(self, customer_id: int, product_id: int) -> Dict[str, Any]:
        """Removes a product from customer's cart."""
        conn = self.mysql.get_raw_connection(include_db=True)
        cursor = conn.cursor()
        with Timer() as timer:
            try:
                cursor.execute(
                    "DELETE FROM cart_items WHERE customer_id = %s AND product_id = %s",
                    (customer_id, product_id)
                )
                deleted = cursor.rowcount
                conn.commit()
                return {
                    "success": True,
                    "deleted_count": deleted,
                    "duration_ms": timer.elapsed_ms,
                    "error": None
                }
            except Exception as e:
                conn.rollback()
                return {"success": False, "error": str(e), "duration_ms": timer.elapsed_ms}
            finally:
                cursor.close()
                conn.close()

    def get_cart(self, customer_id: int) -> Dict[str, Any]:
        """Fetches active cart items with current product price and stock status."""
        sql = """
            SELECT c.cart_item_id, c.customer_id, c.product_id, p.product_name,
                   p.price, c.quantity, (p.price * c.quantity) AS item_total,
                   i.stock_quantity, (i.stock_quantity >= c.quantity) AS in_stock
            FROM cart_items c
            JOIN products p ON c.product_id = p.product_id
            JOIN inventory i ON p.product_id = i.product_id
            WHERE c.customer_id = %s
            ORDER BY c.updated_at DESC
        """
        with Timer() as timer:
            success, rows, err = self.mysql.execute_query(sql, (customer_id,), fetch=True)
        return {
            "success": success,
            "items": rows or [],
            "duration_ms": timer.elapsed_ms,
            "error": err if not success else None
        }
