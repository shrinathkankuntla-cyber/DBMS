import random
import psutil
from typing import Optional, Dict, Any, List, Callable
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from workloads.product_search import ProductSearchWorkload
from workloads.order_placement import OrderPlacementWorkload
from workloads.cart_updates import CartUpdatesWorkload
from workloads.sales_reporting import SalesReportingWorkload
from workloads.inventory_management import InventoryManagementWorkload
from utils.helpers import Timer, calculate_latency_stats
from utils.logger import get_logger

logger = get_logger("workload_generator")

WORKLOAD_MIX_PRESETS = {
    "Read-heavy (95% Read / 5% Write)": (0.95, 0.05),
    "Balanced (50% Read / 50% Write)": (0.50, 0.50),
    "Write-heavy (10% Read / 90% Write)": (0.10, 0.90)
}

class WorkloadGenerator:
    """
    Executes repeatable, parameter-controlled e-commerce workloads against
    MySQL and MongoDB with accurate latency measurement and resource observation.
    """
    def __init__(
        self,
        mysql_db: Optional[MySQLDatabase] = None,
        mongo_db: Optional[MongoDBDatabase] = None,
        seed: int = 42
    ):
        self.mysql = mysql_db or MySQLDatabase()
        self.mongo = mongo_db or MongoDBDatabase()
        self.seed = seed
        self.search_wl = ProductSearchWorkload(self.mysql, self.mongo)
        self.order_wl = OrderPlacementWorkload(self.mysql)
        self.cart_wl = CartUpdatesWorkload(self.mysql)
        self.sales_wl = SalesReportingWorkload(self.mysql)
        self.inv_wl = InventoryManagementWorkload(self.mysql)

    def execute_workload(
        self,
        database_target: str = "MySQL", # "MySQL" or "MongoDB"
        total_operations: int = 100,
        read_ratio: float = 0.8,
        warmup_operations: int = 10,
        progress_callback: Optional[Callable[[int, int, str], None]] = None
    ) -> Dict[str, Any]:
        """
        Executes a deterministic series of operations matching the specified read/write ratio.
        Collects individual operation latencies, summary stats, and system utilization metrics.
        """
        rng = random.Random(self.seed)
        
        # 1. Warm-up Phase (not included in metrics)
        if warmup_operations > 0:
            if progress_callback:
                progress_callback(0, total_operations, "Running warm-up operations...")
            self._run_warmup(database_target, warmup_operations, rng)

        # Baseline system resource observation
        cpu_start = psutil.cpu_percent(interval=None)
        mem_start = psutil.virtual_memory().percent

        all_latencies_ms = []
        read_latencies_ms = []
        write_latencies_ms = []
        operation_counts = {"reads": 0, "writes": 0, "errors": 0}

        # 2. Timed Workload Execution
        with Timer() as total_timer:
            for i in range(1, total_operations + 1):
                is_read = rng.random() < read_ratio

                if progress_callback and (i % 10 == 0 or i == total_operations):
                    op_type = "READ" if is_read else "WRITE"
                    progress_callback(i, total_operations, f"Op {i}/{total_operations} ({op_type})")

                if database_target.upper() == "MYSQL":
                    if is_read:
                        op_res = self._dispatch_mysql_read(rng)
                    else:
                        op_res = self._dispatch_mysql_write(rng)
                else: # MongoDB
                    if is_read:
                        op_res = self._dispatch_mongo_read(rng)
                    else:
                        op_res = self._dispatch_mongo_write(rng)

                lat = op_res["duration_ms"]
                all_latencies_ms.append(lat)

                if is_read:
                    read_latencies_ms.append(lat)
                    operation_counts["reads"] += 1
                else:
                    write_latencies_ms.append(lat)
                    operation_counts["writes"] += 1

                if not op_res.get("success", False):
                    operation_counts["errors"] += 1

        cpu_end = psutil.cpu_percent(interval=None)
        mem_end = psutil.virtual_memory().percent

        # Summary statistics
        total_stats = calculate_latency_stats(all_latencies_ms)
        read_stats = calculate_latency_stats(read_latencies_ms)
        write_stats = calculate_latency_stats(write_latencies_ms)

        throughput_qps = round(total_operations / (total_timer.elapsed_sec or 0.001), 2)

        return {
            "database": database_target,
            "seed": self.seed,
            "total_operations": total_operations,
            "warmup_operations": warmup_operations,
            "read_ratio": read_ratio,
            "write_ratio": round(1.0 - read_ratio, 2),
            "total_duration_ms": round(total_timer.elapsed_ms, 2),
            "throughput_qps": throughput_qps,
            "operation_counts": operation_counts,
            "total_latency_stats": total_stats,
            "read_latency_stats": read_stats,
            "write_latency_stats": write_stats,
            "system_metrics": {
                "cpu_start_pct": cpu_start,
                "cpu_end_pct": cpu_end,
                "memory_start_pct": mem_start,
                "memory_end_pct": mem_end,
                "metric_note": "System-wide CPU/Memory snapshot (psutil); not query-isolated."
            }
        }

    def _run_warmup(self, target: str, count: int, rng: random.Random):
        for _ in range(count):
            if target.upper() == "MYSQL":
                self._dispatch_mysql_read(rng)
            else:
                self._dispatch_mongo_read(rng)

    def _dispatch_mysql_read(self, rng: random.Random) -> Dict[str, Any]:
        action = rng.choice(["search_cat", "search_price", "sales_cat", "low_stock"])
        if action == "search_cat":
            cat_id = rng.randint(1, 20)
            return self.search_wl.search_mysql(category_id=cat_id, limit=25)
        elif action == "search_price":
            min_p = rng.uniform(20.0, 200.0)
            max_p = min_p + rng.uniform(50.0, 500.0)
            return self.search_wl.search_mysql(min_price=min_p, max_price=max_p, limit=25)
        elif action == "sales_cat":
            return self.sales_wl.revenue_by_category(limit=10)
        else:
            return self.inv_wl.get_low_stock_products(threshold=25, limit=25)

    def _dispatch_mysql_write(self, rng: random.Random) -> Dict[str, Any]:
        action = rng.choice(["order", "cart", "restock"])
        if action == "order":
            cust_id = rng.randint(1, 1000)
            p_id = rng.randint(1, 2000)
            return self.order_wl.place_order(customer_id=cust_id, items=[{"product_id": p_id, "quantity": 1}])
        elif action == "cart":
            cust_id = rng.randint(1, 1000)
            p_id = rng.randint(1, 2000)
            qty = rng.randint(1, 5)
            return self.cart_wl.add_or_update_cart(customer_id=cust_id, product_id=p_id, quantity=qty)
        else:
            p_id = rng.randint(1, 2000)
            delta = rng.randint(5, 50)
            return self.inv_wl.update_stock(product_id=p_id, quantity_delta=delta)

    def _dispatch_mongo_read(self, rng: random.Random) -> Dict[str, Any]:
        action = rng.choice(["search_brand", "search_cat_price", "search_attr"])
        brands = ["ApexTech", "NexusPro", "Vanguard", "EchoWave", "Lumina"]
        categories = ["Smartphones & Tablets", "Laptops & Computers", "Footwear & Shoes", "Audio & Headphones"]
        
        if action == "search_brand":
            b = rng.choice(brands)
            return self.search_wl.search_mongodb(brand=b, limit=25)
        elif action == "search_cat_price":
            c = rng.choice(categories)
            min_p = rng.uniform(20.0, 200.0)
            return self.search_wl.search_mongodb(category=c, min_price=min_p, max_price=min_p + 300, limit=25)
        else:
            color = rng.choice(["Black", "Silver", "Space Gray", "White"])
            return self.search_wl.search_mongodb(attributes={"color": color}, limit=25)

    def _dispatch_mongo_write(self, rng: random.Random) -> Dict[str, Any]:
        """Performs a catalog update on MongoDB (e.g. updating price or rating)."""
        coll = self.mongo.get_collection("product_catalog")
        prod_id = rng.randint(1, 2000)
        new_rating = round(rng.uniform(3.0, 5.0), 1)
        with Timer() as timer:
            try:
                res = coll.update_one(
                    {"product_id": prod_id},
                    {"$set": {"attributes.rating": new_rating}}
                )
                return {
                    "operation": "mongo_update",
                    "success": True,
                    "matched": res.matched_count,
                    "modified": res.modified_count,
                    "duration_ms": timer.elapsed_ms
                }
            except Exception as e:
                return {
                    "operation": "mongo_update",
                    "success": False,
                    "error": str(e),
                    "duration_ms": timer.elapsed_ms
                }
