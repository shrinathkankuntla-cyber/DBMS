from typing import Optional, Dict, Any, List, Tuple
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from utils.helpers import Timer
from utils.logger import get_logger

logger = get_logger("product_search")

class ProductSearchWorkload:
    """
    Executes product search queries with filtering and sorting against MySQL and MongoDB.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None, mongo_db: Optional[MongoDBDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()
        self.mongo = mongo_db or MongoDBDatabase()

    def search_mysql(
        self,
        query_text: Optional[str] = None,
        category_id: Optional[int] = None,
        min_price: Optional[float] = None,
        max_price: Optional[float] = None,
        status: Optional[str] = "active",
        sort_by: str = "price",
        sort_dir: str = "ASC",
        limit: int = 50
    ) -> Dict[str, Any]:
        """
        Executes parameterized product search on MySQL.
        """
        conditions = ["1=1"]
        params = []

        if query_text:
            conditions.append("p.product_name LIKE %s")
            params.append(f"%{query_text}%")
        if category_id is not None:
            conditions.append("p.category_id = %s")
            params.append(category_id)
        if min_price is not None:
            conditions.append("p.price >= %s")
            params.append(min_price)
        if max_price is not None:
            conditions.append("p.price <= %s")
            params.append(max_price)
        if status:
            conditions.append("p.status = %s")
            params.append(status)

        sort_col = "p.price" if sort_by == "price" else "p.created_at"
        direction = "DESC" if sort_dir.upper() == "DESC" else "ASC"

        sql = f"""
            SELECT p.product_id, p.product_name, c.category_name, p.price, p.status, p.created_at, i.stock_quantity
            FROM products p
            JOIN categories c ON p.category_id = c.category_id
            LEFT JOIN inventory i ON p.product_id = i.product_id
            WHERE {' AND '.join(conditions)}
            ORDER BY {sort_col} {direction}
            LIMIT %s
        """
        params.append(limit)

        with Timer() as timer:
            success, rows, err = self.mysql.execute_query(sql, tuple(params), fetch=True)

        return {
            "database": "MySQL",
            "operation": "product_search",
            "success": success,
            "duration_ms": timer.elapsed_ms,
            "count": len(rows) if rows else 0,
            "results": rows or [],
            "error": err if not success else None,
            "sql": sql,
            "params": params
        }

    def search_mongodb(
        self,
        query_text: Optional[str] = None,
        category: Optional[str] = None,
        brand: Optional[str] = None,
        min_price: Optional[float] = None,
        max_price: Optional[float] = None,
        attributes: Optional[Dict[str, Any]] = None,
        sort_by: str = "price",
        sort_dir: int = 1, # 1 for ASC, -1 for DESC
        limit: int = 50
    ) -> Dict[str, Any]:
        """
        Executes product search with attribute filtering on MongoDB.
        """
        filter_doc = {}

        if query_text:
            filter_doc["product_name"] = {"$regex": query_text, "$options": "i"}
        if category:
            filter_doc["category"] = category
        if brand:
            filter_doc["brand"] = brand
        if min_price is not None or max_price is not None:
            price_cond = {}
            if min_price is not None:
                price_cond["$gte"] = float(min_price)
            if max_price is not None:
                price_cond["$lte"] = float(max_price)
            filter_doc["price"] = price_cond

        if attributes:
            for k, v in attributes.items():
                filter_doc[f"attributes.{k}"] = v

        sort_field = "price" if sort_by == "price" else "created_at"

        try:
            coll = self.mongo.get_collection("product_catalog")
            with Timer() as timer:
                cursor = coll.find(filter_doc).sort(sort_field, sort_dir).limit(limit)
                docs = list(cursor)

            # Convert ObjectId for JSON serialization
            for d in docs:
                if "_id" in d:
                    d["_id"] = str(d["_id"])

            return {
                "database": "MongoDB",
                "operation": "product_search",
                "success": True,
                "duration_ms": timer.elapsed_ms,
                "count": len(docs),
                "results": docs,
                "error": None,
                "filter": filter_doc
            }
        except Exception as e:
            return {
                "database": "MongoDB",
                "operation": "product_search",
                "success": False,
                "duration_ms": 0.0,
                "count": 0,
                "results": [],
                "error": str(e),
                "filter": filter_doc
            }
