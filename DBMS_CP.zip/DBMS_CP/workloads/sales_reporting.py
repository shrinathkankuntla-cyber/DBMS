from typing import Optional, Dict, Any, List
from database.mysql_connection import MySQLDatabase
from utils.helpers import Timer
from utils.logger import get_logger

logger = get_logger("sales_reporting")

class SalesReportingWorkload:
    """
    Executes analytical queries and aggregation reporting on sales, revenue, and product velocity.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()

    def get_total_sales_and_aov(self) -> Dict[str, Any]:
        """Calculates total revenue, total completed orders, and Average Order Value (AOV)."""
        sql = """
            SELECT 
                COUNT(*) AS total_orders,
                COALESCE(SUM(total_amount), 0.0) AS total_revenue,
                COALESCE(AVG(total_amount), 0.0) AS average_order_value,
                MIN(total_amount) AS min_order_amount,
                MAX(total_amount) AS max_order_amount
            FROM orders
            WHERE order_status IN ('completed', 'shipped')
        """
        with Timer() as timer:
            success, rows, err = self.mysql.execute_query(sql, fetch=True)
        row = rows[0] if rows else {}
        return {
            "operation": "total_sales_and_aov",
            "success": success,
            "data": row,
            "duration_ms": timer.elapsed_ms,
            "error": err if not success else None
        }

    def revenue_by_category(self, limit: int = 20) -> Dict[str, Any]:
        """Calculates aggregated sales revenue and volume grouped by category."""
        sql = """
            SELECT 
                c.category_id,
                c.category_name,
                COUNT(DISTINCT oi.order_id) AS orders_count,
                SUM(oi.quantity) AS units_sold,
                COALESCE(SUM(oi.subtotal), 0.0) AS total_revenue
            FROM categories c
            JOIN products p ON c.category_id = p.category_id
            JOIN order_items oi ON p.product_id = oi.product_id
            JOIN orders o ON oi.order_id = o.order_id
            WHERE o.order_status IN ('completed', 'shipped')
            GROUP BY c.category_id, c.category_name
            ORDER BY total_revenue DESC
            LIMIT %s
        """
        with Timer() as timer:
            success, rows, err = self.mysql.execute_query(sql, (limit,), fetch=True)
        return {
            "operation": "revenue_by_category",
            "success": success,
            "data": rows or [],
            "count": len(rows) if rows else 0,
            "duration_ms": timer.elapsed_ms,
            "error": err if not success else None
        }

    def revenue_by_product(self, limit: int = 50) -> Dict[str, Any]:
        """Aggregates revenue and items sold per product."""
        sql = """
            SELECT 
                p.product_id,
                p.product_name,
                c.category_name,
                p.price,
                SUM(oi.quantity) AS total_units_sold,
                SUM(oi.subtotal) AS gross_revenue
            FROM products p
            JOIN categories c ON p.category_id = c.category_id
            JOIN order_items oi ON p.product_id = oi.product_id
            JOIN orders o ON oi.order_id = o.order_id
            WHERE o.order_status IN ('completed', 'shipped')
            GROUP BY p.product_id, p.product_name, c.category_name, p.price
            ORDER BY gross_revenue DESC
            LIMIT %s
        """
        with Timer() as timer:
            success, rows, err = self.mysql.execute_query(sql, (limit,), fetch=True)
        return {
            "operation": "revenue_by_product",
            "success": success,
            "data": rows or [],
            "count": len(rows) if rows else 0,
            "duration_ms": timer.elapsed_ms,
            "error": err if not success else None
        }

    def orders_by_date(self, days_back: int = 30) -> Dict[str, Any]:
        """Aggregates daily order frequency and revenue over a recent timeframe."""
        sql = """
            SELECT 
                DATE(order_date) AS order_day,
                COUNT(*) AS orders_count,
                SUM(total_amount) AS daily_revenue
            FROM orders
            WHERE order_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
            GROUP BY DATE(order_date)
            ORDER BY order_day ASC
        """
        with Timer() as timer:
            success, rows, err = self.mysql.execute_query(sql, (days_back,), fetch=True)
        return {
            "operation": "orders_by_date",
            "success": success,
            "data": rows or [],
            "count": len(rows) if rows else 0,
            "duration_ms": timer.elapsed_ms,
            "error": err if not success else None
        }

    def top_selling_products(self, limit: int = 10) -> Dict[str, Any]:
        """Returns the top products ranked by total unit volume sold."""
        sql = """
            SELECT 
                p.product_id,
                p.product_name,
                SUM(oi.quantity) AS total_volume_sold,
                SUM(oi.subtotal) AS total_sales_value
            FROM order_items oi
            JOIN products p ON oi.product_id = p.product_id
            JOIN orders o ON oi.order_id = o.order_id
            WHERE o.order_status IN ('completed', 'shipped')
            GROUP BY p.product_id, p.product_name
            ORDER BY total_volume_sold DESC
            LIMIT %s
        """
        with Timer() as timer:
            success, rows, err = self.mysql.execute_query(sql, (limit,), fetch=True)
        return {
            "operation": "top_selling_products",
            "success": success,
            "data": rows or [],
            "count": len(rows) if rows else 0,
            "duration_ms": timer.elapsed_ms,
            "error": err if not success else None
        }
