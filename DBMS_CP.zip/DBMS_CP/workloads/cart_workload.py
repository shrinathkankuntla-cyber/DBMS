"""
Simulated Cart Workload Module
Provides realistic e-commerce cart activity (add, update, remove, stock validation, checkout)
to complement the historical Olist dataset which does not contain cart events.
All generated transactions and cart records are flagged with data_origin='benchmark'.
"""

import random
from typing import Dict, Any, List, Optional, Tuple
from database.mysql_connection import MySQLDatabase
from utils.logger import get_logger
from utils.helpers import Timer

logger = get_logger("cart_workload")

class CartWorkloadManager:
    """
    Executes and measures simulated cart operations against MySQL InnoDB.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()

    def add_to_cart(self, customer_id: int, product_id: int, quantity: int = 1) -> Dict[str, Any]:
        """
        Adds a product to the customer's cart, validating stock availability.
        """
        with Timer() as timer:
            try:
                with self.mysql.get_connection() as conn:
                    cursor = conn.cursor(dictionary=True)

                    # Validate stock
                    cursor.execute(
                        "SELECT stock_quantity FROM inventory WHERE product_id = %s",
                        (product_id,)
                    )
                    inv_row = cursor.fetchone()
                    if not inv_row:
                        return {"success": False, "error": f"Product {product_id} has no inventory record."}

                    available_stock = inv_row["stock_quantity"]
                    if available_stock < quantity:
                        return {
                            "success": False,
                            "error": f"Insufficient stock: requested {quantity}, available {available_stock}."
                        }

                    # Upsert into cart_items
                    upsert_sql = """
                    INSERT INTO cart_items (customer_id, product_id, quantity, data_origin)
                    VALUES (%s, %s, %s, 'benchmark')
                    ON DUPLICATE KEY UPDATE
                        quantity = quantity + VALUES(quantity),
                        data_origin = 'benchmark';
                    """
                    cursor.execute(upsert_sql, (customer_id, product_id, quantity))
                    conn.commit()
                    cursor.close()

                return {
                    "success": True,
                    "action": "ADD_TO_CART",
                    "customer_id": customer_id,
                    "product_id": product_id,
                    "quantity": quantity,
                    "latency_ms": timer.elapsed_ms
                }
            except Exception as e:
                logger.error(f"Error in add_to_cart: {e}")
                return {"success": False, "error": str(e), "latency_ms": timer.elapsed_ms}

    def update_cart_quantity(self, cart_item_id: int, new_quantity: int) -> Dict[str, Any]:
        """
        Changes item quantity or removes it if new_quantity <= 0.
        """
        with Timer() as timer:
            try:
                with self.mysql.get_connection() as conn:
                    cursor = conn.cursor(dictionary=True)

                    if new_quantity <= 0:
                        cursor.execute("DELETE FROM cart_items WHERE cart_item_id = %s", (cart_item_id,))
                        action = "REMOVE_FROM_CART"
                    else:
                        # Check stock
                        cursor.execute("""
                        SELECT i.stock_quantity 
                        FROM cart_items c
                        JOIN inventory i ON c.product_id = i.product_id
                        WHERE c.cart_item_id = %s
                        """, (cart_item_id,))
                        row = cursor.fetchone()
                        if row and row["stock_quantity"] < new_quantity:
                            return {
                                "success": False,
                                "error": f"Insufficient stock for update: available {row['stock_quantity']}"
                            }

                        cursor.execute(
                            "UPDATE cart_items SET quantity = %s WHERE cart_item_id = %s",
                            (new_quantity, cart_item_id)
                        )
                        action = "UPDATE_QUANTITY"

                    conn.commit()
                    cursor.close()

                return {"success": True, "action": action, "cart_item_id": cart_item_id, "latency_ms": timer.elapsed_ms}
            except Exception as e:
                return {"success": False, "error": str(e), "latency_ms": timer.elapsed_ms}

    def remove_from_cart(self, cart_item_id: int) -> Dict[str, Any]:
        """Removes an item from the cart."""
        return self.update_cart_quantity(cart_item_id, new_quantity=0)

    def get_cart_items(self, customer_id: int) -> List[Dict[str, Any]]:
        """Retrieves active cart contents for a customer."""
        try:
            with self.mysql.get_connection() as conn:
                cursor = conn.cursor(dictionary=True)
                query = """
                SELECT c.cart_item_id, c.customer_id, c.product_id, c.quantity,
                       p.product_name, p.price, (c.quantity * p.price) as subtotal,
                       i.stock_quantity
                FROM cart_items c
                JOIN products p ON c.product_id = p.product_id
                JOIN inventory i ON c.product_id = i.product_id
                WHERE c.customer_id = %s
                ORDER BY c.cart_item_id DESC;
                """
                cursor.execute(query, (customer_id,))
                items = cursor.fetchall()
                cursor.close()
                return items
        except Exception as e:
            logger.error(f"Error fetching cart items: {e}")
            return []

    def checkout_cart(self, customer_id: int) -> Dict[str, Any]:
        """
        Atomically converts active cart items into a benchmark order,
        deducts inventory, and clears cart items within a strict transaction.
        """
        with Timer() as timer:
            conn = None
            try:
                conn = self.mysql.get_raw_connection(include_db=True)
                conn.autocommit = False
                cursor = conn.cursor(dictionary=True)

                # 1. Fetch current cart
                cursor.execute(
                    "SELECT cart_item_id, product_id, quantity FROM cart_items WHERE customer_id = %s",
                    (customer_id,)
                )
                items = cursor.fetchall()
                if not items:
                    conn.rollback()
                    return {"success": False, "error": "Cart is empty."}

                total_amount = 0.0
                order_lines = []

                # 2. Lock inventory rows & validate stock
                for it in items:
                    pid = it["product_id"]
                    qty = it["quantity"]

                    cursor.execute(
                        "SELECT p.price, i.stock_quantity FROM products p JOIN inventory i ON p.product_id = i.product_id WHERE p.product_id = %s FOR UPDATE",
                        (pid,)
                    )
                    p_info = cursor.fetchone()
                    if not p_info:
                        conn.rollback()
                        return {"success": False, "error": f"Product {pid} not found in catalog."}

                    if p_info["stock_quantity"] < qty:
                        conn.rollback()
                        return {
                            "success": False,
                            "error": f"Product {pid} stock deficit: available {p_info['stock_quantity']}, needed {qty}."
                        }

                    line_subtotal = float(p_info["price"]) * qty
                    total_amount += line_subtotal
                    order_lines.append({
                        "product_id": pid,
                        "quantity": qty,
                        "unit_price": float(p_info["price"]),
                        "subtotal": line_subtotal
                    })

                # 3. Create benchmark order
                cursor.execute(
                    """
                    INSERT INTO orders (customer_id, order_status, total_amount, data_origin)
                    VALUES (%s, 'processing', %s, 'benchmark')
                    """,
                    (customer_id, total_amount)
                )
                new_order_id = cursor.lastrowid

                # 4. Insert order items & deduct inventory
                for line in order_lines:
                    cursor.execute(
                        """
                        INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal, data_origin)
                        VALUES (%s, %s, %s, %s, %s, 'benchmark')
                        """,
                        (new_order_id, line["product_id"], line["quantity"], line["unit_price"], line["subtotal"])
                    )

                    cursor.execute(
                        "UPDATE inventory SET stock_quantity = stock_quantity - %s WHERE product_id = %s",
                        (line["quantity"], line["product_id"])
                    )

                # 5. Clear cart
                cursor.execute("DELETE FROM cart_items WHERE customer_id = %s", (customer_id,))

                conn.commit()
                cursor.close()
                conn.close()

                return {
                    "success": True,
                    "order_id": new_order_id,
                    "items_count": len(order_lines),
                    "total_amount": total_amount,
                    "latency_ms": timer.elapsed_ms
                }

            except Exception as e:
                if conn:
                    conn.rollback()
                    conn.close()
                logger.error(f"Cart checkout transaction failed: {e}")
                return {"success": False, "error": str(e), "latency_ms": timer.elapsed_ms}

    def simulate_random_cart_workload(self, num_operations: int = 50) -> Dict[str, Any]:
        """
        Executes a stochastic mix of cart operations (Add 60%, Update 20%, Remove 10%, Checkout 10%).
        """
        # Fetch candidate customers and products
        try:
            with self.mysql.get_connection() as conn:
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT customer_id FROM customers LIMIT 200")
                cust_rows = cursor.fetchall()
                cursor.execute("SELECT product_id FROM products LIMIT 200")
                prod_rows = cursor.fetchall()
                cursor.close()
        except Exception:
            return {"success": False, "error": "Database unavailable."}

        if not cust_rows or not prod_rows:
            return {"success": False, "error": "No customers or products available to simulate cart."}

        cust_ids = [r["customer_id"] for r in cust_rows]
        prod_ids = [r["product_id"] for r in prod_rows]

        op_stats = {"add": 0, "update": 0, "remove": 0, "checkout": 0, "errors": 0}
        latencies = []

        for _ in range(num_operations):
            r = random.random()
            c_id = random.choice(cust_ids)
            p_id = random.choice(prod_ids)

            if r < 0.60:
                # Add to cart
                res = self.add_to_cart(c_id, p_id, quantity=random.randint(1, 3))
                op_stats["add"] += 1
            elif r < 0.80:
                # Update quantity on existing cart
                items = self.get_cart_items(c_id)
                if items:
                    target_item = random.choice(items)
                    res = self.update_cart_quantity(target_item["cart_item_id"], random.randint(1, 4))
                else:
                    res = self.add_to_cart(c_id, p_id, 1)
                op_stats["update"] += 1
            elif r < 0.90:
                # Remove from cart
                items = self.get_cart_items(c_id)
                if items:
                    target_item = random.choice(items)
                    res = self.remove_from_cart(target_item["cart_item_id"])
                else:
                    res = {"success": True, "latency_ms": 1.0}
                op_stats["remove"] += 1
            else:
                # Checkout
                res = self.checkout_cart(c_id)
                op_stats["checkout"] += 1

            if res.get("success"):
                latencies.append(res.get("latency_ms", 0.0))
            else:
                op_stats["errors"] += 1

        avg_lat = sum(latencies) / len(latencies) if latencies else 0.0
        return {
            "success": True,
            "total_operations": num_operations,
            "breakdown": op_stats,
            "average_latency_ms": avg_lat,
            "total_latency_recorded": len(latencies)
        }
