import logging
import sys
import re

class CredentialFilter(logging.Filter):
    """
    Sanitizes log messages to prevent sensitive strings like passwords, 
    connection strings, or authorization headers from appearing in logs.
    """
    SENSITIVE_PATTERNS = [
        re.compile(r'password["\']?\s*[:=]\s*["\']?([^"\'\s,]+)', re.IGNORECASE),
        re.compile(r'pwd["\']?\s*[:=]\s*["\']?([^"\'\s,]+)', re.IGNORECASE),
        re.compile(r'mongodb(\+srv)?://([^:]+):([^@]+)@', re.IGNORECASE),
    ]

    def filter(self, record):
        if isinstance(record.msg, str):
            sanitized = record.msg
            for pattern in self.SENSITIVE_PATTERNS:
                if 'mongodb' in pattern.pattern:
                    sanitized = pattern.sub(r'mongodb\1://\2:***@', sanitized)
                else:
                    sanitized = pattern.sub(r'password=***', sanitized)
            record.msg = sanitized
        return True

def get_logger(name: str = "ecommerce_optimizer") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter(
            fmt="%(asctime)s [%(levelname)s] [%(name)s]: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(formatter)
        handler.addFilter(CredentialFilter())
        logger.addHandler(handler)
        logger.propagate = False
    return logger
