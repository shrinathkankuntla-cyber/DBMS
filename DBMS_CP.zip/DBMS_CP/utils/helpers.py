import time
import datetime
import numpy as np
from typing import List, Dict, Any

class Timer:
    """High-precision execution timer using time.perf_counter_ns()."""
    def __init__(self):
        self.start_ns = 0
        self.end_ns = 0
        self.elapsed_ns = 0

    def __enter__(self):
        self.start_ns = time.perf_counter_ns()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.end_ns = time.perf_counter_ns()
        self.elapsed_ns = self.end_ns - self.start_ns

    @property
    def elapsed_ms(self) -> float:
        return self.elapsed_ns / 1_000_000.0

    @property
    def elapsed_sec(self) -> float:
        return self.elapsed_ns / 1_000_000_000.0


def calculate_latency_stats(latencies_ms: List[float]) -> Dict[str, Any]:
    """
    Computes statistical summaries for latency distribution.
    Only computes median and p95 when sample count > 0.
    """
    if not latencies_ms:
        return {
            "count": 0,
            "min_ms": 0.0,
            "median_ms": 0.0,
            "p95_ms": 0.0,
            "max_ms": 0.0,
            "mean_ms": 0.0,
            "total_ms": 0.0
        }

    arr = np.array(latencies_ms, dtype=np.float64)
    count = len(arr)
    min_val = float(np.min(arr))
    max_val = float(np.max(arr))
    mean_val = float(np.mean(arr))
    total_val = float(np.sum(arr))
    median_val = float(np.median(arr)) if count >= 1 else 0.0
    p95_val = float(np.percentile(arr, 95)) if count >= 2 else max_val

    return {
        "count": count,
        "min_ms": round(min_val, 4),
        "median_ms": round(median_val, 4),
        "p95_ms": round(p95_val, 4),
        "max_ms": round(max_val, 4),
        "mean_ms": round(mean_val, 4),
        "total_ms": round(total_val, 4)
    }


def format_bytes(size_bytes: int) -> str:
    """Format bytes into human-readable string."""
    if size_bytes is None or size_bytes < 0:
        return "N/A"
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    val = float(size_bytes)
    for u in units:
        if val < 1024.0 or u == 'TB':
            return f"{val:.2f} {u}"
        val /= 1024.0
    return f"{size_bytes} B"


def format_duration(ms: float) -> str:
    """Format duration in milliseconds to appropriate time unit."""
    if ms is None:
        return "N/A"
    if ms < 1.0:
        return f"{ms * 1000:.1f} µs"
    elif ms < 1000.0:
        return f"{ms:.2f} ms"
    else:
        return f"{ms / 1000.0:.2f} s"


def format_timestamp(ts: Any) -> str:
    """
    Format a datetime object, ISO string, or None into a clean, human-readable string using strftime().
    Returns 'N/A' if ts is None, empty, or unparseable.
    """
    if ts is None:
        return "N/A"
    if isinstance(ts, (datetime.datetime, datetime.date)):
        return ts.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(ts, str):
        cleaned = ts.strip()
        if not cleaned or cleaned.upper() == "N/A":
            return "N/A"
        for fmt in ("%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                dt = datetime.datetime.strptime(cleaned[:26], fmt)
                return dt.strftime("%Y-%m-%d %H:%M:%S")
            except (ValueError, TypeError):
                continue
        return cleaned[:19]
    return str(ts)
