import re
from typing import Dict, Any, Tuple

FORBIDDEN_SQL_PATTERNS = [
    re.compile(r'\bDROP\s+DATABASE\b', re.IGNORECASE),
    re.compile(r'\bSHUTDOWN\b', re.IGNORECASE),
    re.compile(r'\bGRANT\b', re.IGNORECASE),
    re.compile(r'\bREVOKE\b', re.IGNORECASE),
    re.compile(r'\bCREATE\s+USER\b', re.IGNORECASE),
    re.compile(r'\bDROP\s+USER\b', re.IGNORECASE),
]

READ_SQL_KEYWORDS = {'SELECT', 'SHOW', 'DESCRIBE', 'EXPLAIN'}
WRITE_SQL_KEYWORDS = {'INSERT', 'UPDATE', 'DELETE', 'REPLACE', 'CREATE', 'ALTER', 'DROP', 'TRUNCATE'}

def classify_sql(query: str) -> str:
    """Classify SQL statement into READ, WRITE, or UNKNOWN."""
    clean = query.strip().upper()
    # Strip comments
    clean = re.sub(r'--.*$', '', clean, flags=re.MULTILINE)
    clean = re.sub(r'/\*.*?\*/', '', clean, flags=re.DOTALL).strip()
    
    first_word = clean.split()[0] if clean.split() else ""
    if first_word in READ_SQL_KEYWORDS:
        return "READ"
    elif first_word in WRITE_SQL_KEYWORDS:
        return "WRITE"
    return "UNKNOWN"

def validate_sql_safety(query: str) -> Tuple[bool, str]:
    """Validates that SQL doesn't contain catastrophic management commands."""
    for pattern in FORBIDDEN_SQL_PATTERNS:
        if pattern.search(query):
            return False, f"Prohibited SQL command detected: {pattern.pattern}"
    return True, "Valid"

def validate_positive_number(val: Any, field_name: str, allow_zero: bool = True) -> Tuple[bool, str]:
    try:
        num = float(val)
        if allow_zero and num < 0:
            return False, f"{field_name} must be non-negative (>= 0)."
        elif not allow_zero and num <= 0:
            return False, f"{field_name} must be strictly positive (> 0)."
        return True, ""
    except (ValueError, TypeError):
        return False, f"{field_name} must be a valid number."
