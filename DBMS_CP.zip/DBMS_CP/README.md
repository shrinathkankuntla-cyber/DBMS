# Workload-Aware Database Query and Index Cost Optimizer for E-Commerce Systems

An empirical performance engineering platform and optimization system that benchmarks how different e-commerce workloads (product search, order placement, shopping cart updates, sales reporting, and inventory management) affect database performance and recommends indexing configurations for **MySQL (InnoDB)** and **MongoDB**.

---

## 1. Project Overview & Research Motivation

Database indexing is not a one-sided optimization where adding indexes always makes a system faster. In high-throughput e-commerce systems, an index that accelerates read queries introduces maintenance overhead on every `INSERT`, `UPDATE`, and `DELETE`, consumes additional disk and buffer pool memory, and can degrade overall system throughput under write-heavy workloads.

This project delivers an **empirical, workload-aware index cost optimizer**:
- Connects to real local instances of **MySQL** and **MongoDB**.
- Executes actual e-commerce transactions and queries under parameter-controlled workloads.
- Measures nanosecond-precision operation latencies, write overhead, index storage footprints, and system resource snapshots.
- Analyzes actual execution plans (`EXPLAIN / EXPLAIN ANALYZE` in MySQL, `executionStats` in MongoDB).
- Computes multi-criteria mathematical trade-offs to classify indexing configurations into:
  - **Recommended**
  - **Conditionally Useful**
  - **Neutral**
  - **Not Recommended**
  - **Insufficient Evidence**

---

## 2. System Architecture

```
                                  +------------------------------------+
                                  | Streamlit Performance UI (Dark UX) |
                                  +-----------------+------------------+
                                                    |
               +------------------------------------+-----------------------------------+
               |                                    |                                   |
+--------------v---------------+    +---------------v----------------+    +-------------v---------------+
|     Workload Simulator       |    |        Index Laboratory        |    |      Analytics & History    |
| (Read/Write Mix Dispatcher)  |    |  (Baseline vs Candidate Trials)|    | (Plotly Latency & Storage)  |
+--------------+---------------+    +---------------+----------------+    +-------------+---------------+
               |                                    |                                   |
               +------------------------------------+-----------------------------------+
                                                    |
                                    +---------------v----------------+
                                    |     Optimization Engine        |
                                    | - Index Manager & Safety Guard |
                                    | - Plan Analyzer (EXPLAIN)      |
                                    | - Mathematical Cost Model      |
                                    | - Recommendation Generator     |
                                    +---------------+----------------+
                                                    |
                     +------------------------------+-------------------------------+
                     |                                                              |
      +--------------v---------------+                              +---------------v----------------+
      |  MySQL Relational Engine     |                              |   MongoDB Document Engine      |
      | - Customers, Orders, Items   |   <== Sync & Reconcile ==>   | - Flexible Product Catalog     |
      | - Real-time Inventory Stocks |                              | - Nested Attributes & Variants |
      | - ACID Transactions (InnoDB) |                              | - Identity Index: product_id   |
      +------------------------------+                              +--------------------------------+
```

---

## 3. Database Schemas

### A. MySQL Relational Schema (`ecommerce_optimizer`)
- **`customers`**: `customer_id` (PK), `full_name`, `email` (UNIQUE), `created_at`
- **`categories`**: `category_id` (PK), `category_name` (UNIQUE)
- **`products`**: `product_id` (PK), `product_name`, `category_id` (FK), `price` (`CHECK >= 0`), `status`, `created_at`
- **`inventory`**: `product_id` (PK, FK), `stock_quantity` (`CHECK >= 0`), `updated_at`
- **`orders`**: `order_id` (PK), `customer_id` (FK), `order_date`, `order_status`, `total_amount` (`CHECK >= 0`)
- **`order_items`**: `order_item_id` (PK), `order_id` (FK), `product_id` (FK), `quantity` (`CHECK > 0`), `unit_price`, `subtotal`
- **`cart_items`**: `cart_item_id` (PK), `customer_id` (FK), `product_id` (FK), `quantity` (`CHECK > 0`), `updated_at`, `UNIQUE(customer_id, product_id)`
- **`experiments`**, **`experiment_metrics`**, **`experiment_recommendations`**: Persistent benchmark metadata and audit logs.

### B. MongoDB Document Schema (`product_catalog` collection)
```json
{
  "product_id": 101,
  "product_name": "Apex Gaming Laptop 9000",
  "category": "Laptops & Computers",
  "price": 1299.99,
  "brand": "ApexTech",
  "status": "active",
  "created_at": "2026-01-15T10:30:00Z",
  "attributes": {
    "color": "Midnight Blue",
    "material": "Aluminum",
    "weight_kg": 2.1,
    "rating": 4.8,
    "warranty_months": 24
  },
  "variants": [
    {
      "sku": "SKU-101-VAR-1",
      "size": "Standard",
      "color": "Midnight Blue",
      "additional_price": 0.0
    }
  ]
}
```
*Mandatory Identity Index*: `{"product_id": 1}` (`unique=True`). Protected from deletion.

---

## 4. Five E-Commerce Workloads

1. **Product Search**:
   - Multi-field substring search, category filtering, price bounds (`BETWEEN` / `$gte, $lte`), brand filtering, multi-attribute criteria (`attributes.color`), sorting by price or creation date.
2. **Order Placement**:
   - Customer existence validation, stock availability check with row-level locks (`SELECT ... FOR UPDATE`), atomic order header & item insertions, inventory decrement, transaction commit or rollback.
3. **Shopping Cart Updates**:
   - Persistent item insertions, quantity increment/decrement, item removals, stock verification against MySQL `cart_items`.
4. **Sales Reporting**:
   - Aggregated multi-table joins (`orders`, `order_items`, `products`, `categories`), daily revenue trajectories, top-selling product velocity, and Average Order Value (AOV).
5. **Inventory Management**:
   - Real-time stock lookups, restock adjustments, threshold-based low-stock warnings, and zero-stock depletion queries.

---

## 5. Candidate Indexing Configurations

The system evaluates four canonical configurations per database:
1. **Baseline**: Core primary keys, foreign keys, and identity indexes only.
2. **Single-Field Configuration**:
   - MySQL: `idx_products_category_id`, `idx_products_price`, `idx_orders_order_date`
   - MongoDB: `idx_cat`, `idx_price`, `idx_brand`
3. **Compound Configuration**:
   - MySQL: `idx_orders_status_date` on `(order_status, order_date)`, `idx_products_cat_price` on `(category_id, price)`
   - MongoDB: `idx_cat_price` on `(category, price)`, `idx_cat_brand_price` on `(category, brand, price)`
4. **Combined Configuration**:
   - Selected combination of single and compound workload indexes.

---

## 6. Recommendation Methodology & Mathematical Cost Model

For any candidate index, the optimizer computes exact empirical percentage trade-offs against baseline:

$$\text{Read Latency Improvement (\%)} = \frac{\text{BaselineReadMedian} - \text{CandidateReadMedian}}{\text{BaselineReadMedian}} \times 100$$

$$\text{Write Latency Penalty (\%)} = \frac{\text{CandidateWriteMedian} - \text{BaselineWriteMedian}}{\text{BaselineWriteMedian}} \times 100$$

$$\text{Total Duration Improvement (\%)} = \frac{\text{BaselineTotalMs} - \text{CandidateTotalMs}}{\text{BaselineTotalMs}} \times 100$$

$$\text{Storage Overhead} = \text{CandidateIndexBytes} - \text{BaselineIndexBytes}$$

### Multi-Criteria Utility Weighting
$$\text{Net Utility Score} = (w_{\text{read}} \times \text{ReadImprovement}) - (w_{\text{write}} \times \text{WritePenalty}) - (w_{\text{storage}} \times \text{StoragePenalty})$$

| Workload Priority Goal | $w_{\text{read}}$ | $w_{\text{write}}$ | $w_{\text{storage}}$ |
| :--- | :--- | :--- | :--- |
| **Balance reads and writes** | 0.50 | 0.40 | 0.10 |
| **Prioritize reads** | 0.80 | 0.15 | 0.05 |
| **Prioritize writes** | 0.20 | 0.70 | 0.10 |
| **Minimize storage** | 0.30 | 0.20 | 0.50 |

---

## 7. Installation and Local Setup

### Prerequisites
- Python 3.10+
- MySQL Server 8.0+ or 9.x
- MongoDB Community Server 6.0+ or 8.x

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Environment Configuration
Edit `.env` or configure directly through the **Database Connections** UI screen:
```ini
# MySQL Configuration
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=your_root_password
MYSQL_DATABASE=ecommerce_optimizer

# MongoDB Configuration
MONGODB_URI=mongodb://localhost:27017/
MONGODB_DATABASE=ecommerce_optimizer
```

### 3. Launch Application
```bash
streamlit run app.py
```

---

## 8. Running the Complete Test Suite

The test suite validates database drivers, schema integrity, five workloads, ACID transactions, data migration, and benchmark calculations:

```bash
python -m unittest discover tests
```

---

## 9. Performance Limitations & Engineering Considerations

1. **Hardware & Cache Effects**: Measured query latencies depend on server hardware, buffer pool warmness (InnoDB buffer pool, WiredTiger cache), and SSD latency. Always execute warm-up operations prior to timing.
2. **System-Level Utilization**: CPU and memory utilization captured via `psutil` represent system-wide host snapshots, not isolated per-query thread consumption.
3. **No Fabricated Data**: If a candidate compound index causes write amplification or fails to accelerate queries due to optimizer decisions, the optimizer reports that trade-off without bias.
