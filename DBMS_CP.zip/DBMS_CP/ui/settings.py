import streamlit as st
from config.settings import get_env, update_env_file, ENV_FILE
from ui.components import render_page_header

def render_settings():
    render_page_header(
        title="System Configuration",
        subtitle="Manage global simulation defaults, pseudo-random seed values, and environment parameters.",
        badge_text="PREFERENCES",
        badge_type="black"
    )

    col1, col2 = st.columns(2)

    with col1:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #C1121F; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Global Simulation Parameters</div>
                <div style="font-size: 0.82rem; color: #242424; margin-bottom: 14px;">Controls default execution counts, seed values, and trial warm-up loops.</div>
            """,
            unsafe_allow_html=True
        )

        with st.form("settings_form"):
            def_seed = st.number_input("Default Random Seed", value=int(get_env("DEFAULT_RANDOM_SEED", "42")), step=1)
            def_ops = st.number_input("Default Benchmark Operations", value=int(get_env("DEFAULT_OPERATION_COUNT", "50")), step=10)
            def_warmup = st.number_input("Default Warm-up Operations", value=int(get_env("DEFAULT_WARMUP_COUNT", "5")), step=5)
            def_reps = st.number_input("Default Execution Repetitions", value=int(get_env("DEFAULT_REPETITIONS", "3")), step=1)

            st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
            submitted = st.form_submit_button("Save Global Settings", type="primary", use_container_width=True)
            if submitted:
                update_env_file({
                    "DEFAULT_RANDOM_SEED": str(def_seed),
                    "DEFAULT_OPERATION_COUNT": str(def_ops),
                    "DEFAULT_WARMUP_COUNT": str(def_warmup),
                    "DEFAULT_REPETITIONS": str(def_reps)
                })
                st.success("Global parameters saved to environment file.")

        st.markdown("</div>", unsafe_allow_html=True)

    with col2:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #D4AF37; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Data Integrity & Safety Protocols</div>
                <div style="font-size: 0.82rem; color: #242424; margin-bottom: 14px;">Inviolable constraints enforced across all optimizer subsystems:</div>
                <ul style="font-size: 0.85rem; color: #111111; line-height: 1.6; padding-left: 18px; margin: 0;">
                    <li><b>No Mock Data:</b> All benchmarks, query plans, and metrics execute against live MySQL and MongoDB servers.</li>
                    <li><b>Protected Indexes:</b> Primary keys, foreign key constraints, and MongoDB unique identity index (<code>product_id</code>) cannot be dropped by candidate trials.</li>
                    <li><b>ACID Safety:</b> Inventory deductions use <code>SELECT ... FOR UPDATE</code> locks and rollback on stock deficits.</li>
                    <li><b>Destructive Action Confirmation:</b> Any schema alteration or index provisioning requires explicit user confirmation.</li>
                </ul>
            </div>
            """,
            unsafe_allow_html=True
        )

        st.markdown(
            f"""
            <div style="background: #FAFAFA; border: 1px solid #D9D9D9; border-radius: 6px; padding: 12px 16px; font-size: 0.82rem; color: #242424;">
                <b>Active Environment File:</b><br>
                <code>{ENV_FILE}</code>
            </div>
            """,
            unsafe_allow_html=True
        )
