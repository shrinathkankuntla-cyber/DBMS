import streamlit as st
import pandas as pd
import plotly.express as px
from workloads.workload_generator import WorkloadGenerator, WORKLOAD_MIX_PRESETS
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from ui.components import render_page_header, render_metric_card, apply_chart_theme
from utils.helpers import format_duration

def render_workload_simulator():
    mysql_db = MySQLDatabase()
    mongo_db = MongoDBDatabase()

    render_page_header(
        title="Workload Simulator",
        subtitle="Execute repeatable, parameter-controlled e-commerce transaction and query mixes against live database engines.",
        badge_text="WORKLOAD GENERATOR",
        badge_type="gold"
    )

    col_ctrl, col_stats = st.columns([1, 1])

    with col_ctrl:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #C1121F; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Simulation Parameters</div>
                <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Configure execution engine, operation volume, and read/write ratio.</div>
            """,
            unsafe_allow_html=True
        )

        db_target = st.selectbox("Target Database Engine", ["MongoDB", "MySQL"], index=0)

        mix_preset = st.selectbox(
            "Workload Mix Preset",
            list(WORKLOAD_MIX_PRESETS.keys()) + ["Custom Ratio..."],
            index=0
        )

        if mix_preset == "Custom Ratio...":
            read_pct = st.slider("Read Proportion (%)", min_value=0, max_value=100, value=80, step=5)
            read_ratio = read_pct / 100.0
            write_ratio = 1.0 - read_ratio
        else:
            read_ratio, write_ratio = WORKLOAD_MIX_PRESETS[mix_preset]

        st.caption(f"Configured Mix: **{int(read_ratio * 100)}% Reads** | **{int(write_ratio * 100)}% Writes**")

        c1, c2 = st.columns(2)
        with c1:
            op_count = st.number_input("Total Operations", min_value=10, max_value=5000, value=50, step=10)
            seed_val = st.number_input("Random Seed (Reproducibility)", value=42, step=1)
        with c2:
            warmup_count = st.number_input("Warm-up Count", min_value=0, max_value=100, value=5, step=5)

        st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
        btn_run = st.button("Execute Workload Run", type="primary", use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

        # Workload Distribution Chart Preview in Strict Red & Gold
        mix_data = pd.DataFrame([
            {"Type": "Read Queries", "Proportion": read_ratio * 100},
            {"Type": "Write Transactions", "Proportion": write_ratio * 100}
        ])
        fig_dist = px.bar(
            mix_data,
            x="Type",
            y="Proportion",
            color="Type",
            text="Proportion",
            color_discrete_map={"Read Queries": "#C1121F", "Write Transactions": "#D4AF37"}
        )
        apply_chart_theme(fig_dist)
        fig_dist.update_traces(texttemplate='%{text:.0f}%', textposition='outside')
        fig_dist.update_layout(height=200, showlegend=False, yaxis=dict(range=[0, 115]))
        st.plotly_chart(fig_dist, use_container_width=True)

    with col_stats:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #111111; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Execution Observations & Metrics</div>
                <div style="font-size: 0.82rem; color: #242424;">Real-time latency distributions and system metrics captured during execution.</div>
            </div>
            """,
            unsafe_allow_html=True
        )

        if btn_run:
            generator = WorkloadGenerator(mysql_db=mysql_db, mongo_db=mongo_db, seed=seed_val)
            p_bar = st.progress(0.0)
            status_text = st.empty()

            def update_progress_cb(current, total, msg):
                status_text.text(msg)
                if total > 0:
                    p_bar.progress(current / total)

            try:
                with st.spinner(f"Executing {op_count} operations on {db_target}..."):
                    result = generator.execute_workload(
                        database_target=db_target,
                        total_operations=int(op_count),
                        read_ratio=read_ratio,
                        warmup_operations=int(warmup_count),
                        progress_callback=update_progress_cb
                    )
                st.session_state["latest_workload_result"] = result
                st.success(f"Workload completed in {result['total_duration_ms']:.2f} ms!")
            except Exception as e:
                st.error(f"Workload execution failed: {e}")

        if "latest_workload_result" in st.session_state:
            res = st.session_state["latest_workload_result"]

            m1, m2, m3, m4 = st.columns(4)
            with m1:
                render_metric_card("Throughput", f"{res['throughput_qps']:.1f}", subtext="Queries / sec", variant="white_red")
            with m2:
                render_metric_card("Duration", format_duration(res['total_duration_ms']), subtext="Total Run Time", variant="black_gold")
            with m3:
                render_metric_card("Median", f"{res['total_latency_stats']['median_ms']:.2f} ms", subtext="50th Percentile", variant="white_red_gold")
            with m4:
                render_metric_card("P95 Tail", f"{res['total_latency_stats']['p95_ms']:.2f} ms", subtext="95th Percentile", variant="black_gold")

            st.markdown("##### Latency Breakdown (Reads vs. Writes)")
            read_st = res["read_latency_stats"]
            write_st = res["write_latency_stats"]

            df_breakdown = pd.DataFrame([
                {
                    "Type": "Read Operations",
                    "Count": read_st["count"],
                    "Median (ms)": f"{read_st['median_ms']:.2f}",
                    "P95 (ms)": f"{read_st['p95_ms']:.2f}",
                    "Min (ms)": f"{read_st['min_ms']:.2f}",
                    "Max (ms)": f"{read_st['max_ms']:.2f}",
                    "Total (ms)": f"{read_st['total_ms']:.2f}"
                },
                {
                    "Type": "Write Operations",
                    "Count": write_st["count"],
                    "Median (ms)": f"{write_st['median_ms']:.2f}",
                    "P95 (ms)": f"{write_st['p95_ms']:.2f}",
                    "Min (ms)": f"{write_st['min_ms']:.2f}",
                    "Max (ms)": f"{write_st['max_ms']:.2f}",
                    "Total (ms)": f"{write_st['total_ms']:.2f}"
                }
            ])
            st.dataframe(df_breakdown, use_container_width=True)

            st.markdown("##### Host System Resource Snapshot")
            sys_m = res["system_metrics"]
            st.markdown(
                f"""
                <div style="background: #FAFAFA; border: 1px solid #D9D9D9; border-top: 2px solid #D4AF37; border-radius: 6px; padding: 12px 16px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                        <span style="font-weight: 700; color: #111111;">CPU Utilization:</span>
                        <span class="mono-num" style="color: #C1121F; font-weight: 700;">Start {sys_m['cpu_start_pct']}% → End {sys_m['cpu_end_pct']}%</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="font-weight: 700; color: #111111;">Memory Utilization:</span>
                        <span class="mono-num" style="color: #C9A227; font-weight: 700;">Start {sys_m['memory_start_pct']}% → End {sys_m['memory_end_pct']}%</span>
                    </div>
                    <div style="font-size: 0.75rem; color: #242424; margin-top: 8px;">
                        Note: {sys_m['metric_note']}
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )
        else:
            st.info("Configure parameters and click **Execute Workload Run** to measure empirical database performance.")
