import streamlit as st
import pandas as pd
import json
import plotly.express as px
import plotly.graph_objects as go
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from optimizer.benchmark_engine import BenchmarkEngine, LOCAL_EXP_DIR
from ui.components import render_page_header, render_metric_card, render_status_badge, apply_chart_theme
from utils.helpers import format_duration, format_timestamp

def render_overview():
    mysql_db = MySQLDatabase()
    mongo_db = MongoDBDatabase()

    experiments = BenchmarkEngine.list_experiments(mysql_db)
    m_ok, m_msg = mysql_db.test_connection()
    mg_ok, mg_msg = mongo_db.test_connection()

    # Top Section: Header & Experiment Selector
    render_page_header(
        title="Database Performance Overview",
        subtitle="Empirical observability of e-commerce query latency, index cost-benefit trade-offs, and system metrics.",
        badge_text="ENTERPRISE OPTIMIZER",
        badge_type="gold"
    )

    # Top Sub-bar with Experiment Selector & Last Timestamp
    top_c1, top_c2 = st.columns([2, 1])
    selected_exp_data = None

    with top_c1:
        if experiments:
            exp_choices = {f"{e['experiment_id']} ({e['database_type']} - {e['config_type']})": e['experiment_id'] for e in experiments}
            selected_choice = st.selectbox("Active Benchmark Experiment Inspection", list(exp_choices.keys()), index=0)
            chosen_exp_id = exp_choices[selected_choice]
            
            # Load full experiment details if available
            exp_file = LOCAL_EXP_DIR / f"{chosen_exp_id}.json"
            if exp_file.exists():
                try:
                    with open(exp_file, "r", encoding="utf-8") as f:
                        selected_exp_data = json.load(f)
                except Exception:
                    pass
        else:
            st.info("No benchmark experiments logged yet. Execute trials in the **Index Laboratory** to view live performance data.")

    with top_c2:
        last_time = experiments[0].get("created_at") if experiments else None
        formatted_last_time = format_timestamp(last_time)
        st.markdown(
            f"""
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-radius: 6px; padding: 10px 14px; text-align: right;">
                <div style="font-size: 0.72rem; font-weight: 700; color: #242424; text-transform: uppercase;">Last Benchmark Run</div>
                <div style="font-family: 'IBM Plex Mono', monospace; font-size: 0.95rem; font-weight: 700; color: #111111;">{formatted_last_time}</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)

    # Six Compact Metric Cards with ALTERNATING Visual Treatments:
    # 1. White cards with black text and red accents
    # 2. Black cards with white text and gold metrics
    # 3. White cards with red headings and gold indicators
    m1, m2, m3, m4, m5, m6 = st.columns(6)

    # 1. MySQL Status: White card with black text and red accents
    with m1:
        render_metric_card(
            label="MySQL Engine",
            value="ONLINE" if m_ok else "OFFLINE",
            delta="InnoDB" if m_ok else "Auth Req",
            delta_type="gold" if m_ok else "red",
            subtext="Authoritative Core",
            variant="white_red"
        )

    # 2. MongoDB Status: Black card with white text and gold metrics
    with m2:
        render_metric_card(
            label="MongoDB Engine",
            value="ONLINE" if mg_ok else "OFFLINE",
            delta="v8.3" if mg_ok else "Offline",
            delta_type="gold" if mg_ok else "negative",
            subtext="Product Catalog",
            variant="black_gold"
        )

    # 3. Workload Operations: White card with red heading and gold indicator
    tot_ops = selected_exp_data.get("operation_count", 0) if selected_exp_data else (experiments[0].get("operation_count", 0) if experiments else 0)
    with m3:
        render_metric_card(
            label="Workload Ops",
            value=f"{tot_ops:,}",
            delta="Evaluated",
            delta_type="gold",
            subtext="Per Experiment Run",
            variant="white_red_gold"
        )

    # 4. Median Query Latency: Black card with white text and gold metrics
    median_lat = 0.0
    if selected_exp_data:
        median_lat = selected_exp_data.get("candidate", {}).get("total_latency_stats", {}).get("median_ms", 0.0)
    elif experiments:
        median_lat = experiments[0].get("read_improvement_pct", 0.0)

    with m4:
        render_metric_card(
            label="Median Latency",
            value=f"{median_lat:.2f} ms" if median_lat else "N/A",
            delta="Observed",
            delta_type="gold" if median_lat > 0 else "neutral",
            subtext="Sample Distribution",
            variant="black_gold"
        )

    # 5. P95 Query Latency: White card with black text and red accents
    p95_lat = 0.0
    if selected_exp_data:
        p95_lat = selected_exp_data.get("candidate", {}).get("total_latency_stats", {}).get("p95_ms", 0.0)

    with m5:
        render_metric_card(
            label="P95 Latency",
            value=f"{p95_lat:.2f} ms" if p95_lat else "N/A",
            delta="Tail Metric",
            delta_type="red",
            subtext="95th Percentile",
            variant="white_red"
        )

    # 6. Total Experiments: White card with red heading and gold indicator
    with m6:
        render_metric_card(
            label="Total Trials",
            value=str(len(experiments)),
            delta="Archived",
            delta_type="gold",
            subtext="Experiment History",
            variant="white_red_gold"
        )

    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # Analytical Sections
    col_chart1, col_chart2 = st.columns([3, 2])

    with col_chart1:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #C1121F; border-radius: 8px; padding: 16px 20px 8px 20px; box-shadow: 0 1px 3px rgba(17,17,17,0.02);">
                <div style="display: flex; justify-content: space-between; align-items: baseline;">
                    <div style="font-size: 0.95rem; font-weight: 800; color: #111111;">Performance Trends: Baseline vs. Candidate Latency</div>
                    <span class="badge badge-gold">Empirical Delta</span>
                </div>
                <div style="font-size: 0.8rem; color: #242424; margin-bottom: 8px;">Red represents unindexed Baseline; Gold represents evaluated Candidate.</div>
            </div>
            """,
            unsafe_allow_html=True
        )

        if selected_exp_data:
            base_m = selected_exp_data.get("baseline", {}).get("total_latency_stats", {})
            cand_m = selected_exp_data.get("candidate", {}).get("total_latency_stats", {})
            base_w = selected_exp_data.get("baseline", {}).get("write_latency_stats", {})
            cand_w = selected_exp_data.get("candidate", {}).get("write_latency_stats", {})

            trend_df = pd.DataFrame([
                {"Metric": "Median Latency", "Configuration": "Baseline (PK/FK Only)", "Latency (ms)": base_m.get("median_ms", 0.0)},
                {"Metric": "Median Latency", "Configuration": f"Candidate ({selected_exp_data.get('candidate_configuration', 'Indexed')})", "Latency (ms)": cand_m.get("median_ms", 0.0)},
                {"Metric": "P95 Latency", "Configuration": "Baseline (PK/FK Only)", "Latency (ms)": base_m.get("p95_ms", 0.0)},
                {"Metric": "P95 Latency", "Configuration": f"Candidate ({selected_exp_data.get('candidate_configuration', 'Indexed')})", "Latency (ms)": cand_m.get("p95_ms", 0.0)},
                {"Metric": "Write Overhead", "Configuration": "Baseline (PK/FK Only)", "Latency (ms)": base_w.get("median_ms", 0.0)},
                {"Metric": "Write Overhead", "Configuration": f"Candidate ({selected_exp_data.get('candidate_configuration', 'Indexed')})", "Latency (ms)": cand_w.get("median_ms", 0.0)},
            ])

            # Red for baseline (#C1121F), Gold for candidate (#D4AF37)
            fig_trend = px.bar(
                trend_df,
                x="Metric",
                y="Latency (ms)",
                color="Configuration",
                barmode="group",
                color_discrete_sequence=["#C1121F", "#D4AF37"]
            )
            apply_chart_theme(fig_trend)
            st.plotly_chart(fig_trend, use_container_width=True)
        else:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: none; border-radius: 0 0 8px 8px; padding: 40px 20px; text-align: center; color: #242424;">
                    Execute an experiment in the <b>Index Laboratory</b> to observe baseline versus candidate latency trends.
                </div>
                """,
                unsafe_allow_html=True
            )

    with col_chart2:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #111111; border-radius: 8px; padding: 16px 20px 8px 20px; box-shadow: 0 1px 3px rgba(17,17,17,0.02);">
                <div style="display: flex; justify-content: space-between; align-items: baseline;">
                    <div style="font-size: 0.95rem; font-weight: 800; color: #111111;">Workload Operation Mix</div>
                    <span class="badge badge-black">5 Workloads</span>
                </div>
                <div style="font-size: 0.8rem; color: #242424; margin-bottom: 8px;">Breakdown of e-commerce business operations.</div>
            </div>
            """,
            unsafe_allow_html=True
        )

        workload_df = pd.DataFrame([
            {"Workload": "Product Search", "Weight": 40, "Type": "Read"},
            {"Workload": "Sales Reporting", "Weight": 25, "Type": "Read"},
            {"Workload": "Order Placement", "Weight": 15, "Type": "Write (ACID)"},
            {"Workload": "Cart Updates", "Weight": 10, "Type": "Write"},
            {"Workload": "Inventory Checks", "Weight": 10, "Type": "Read/Write"}
        ])

        # Strictly Red, Black, and Gold palette
        fig_mix = px.pie(
            workload_df,
            names="Workload",
            values="Weight",
            hole=0.55,
            color_discrete_sequence=["#C1121F", "#D4AF37", "#111111", "#8F0D18", "#C9A227"]
        )
        apply_chart_theme(fig_mix)
        fig_mix.update_traces(textposition='inside', textinfo='percent+label', marker=dict(line=dict(color='#FFFFFF', width=2)))
        st.plotly_chart(fig_mix, use_container_width=True)

    st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)

    # Recent Experiments Table
    st.markdown(
        """
        <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #D4AF37; border-radius: 8px; padding: 16px 20px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                <div style="font-size: 1rem; font-weight: 800; color: #111111;">Recent Empirical Benchmark Experiments</div>
                <div style="font-size: 0.8rem; color: #C9A227; font-weight: 700;">MySQL & MongoDB Audit Trail</div>
            </div>
        """,
        unsafe_allow_html=True
    )

    if experiments:
        exp_table = []
        for e in experiments[:6]:
            rec_class = e.get("classification") or "Neutral"
            read_change = f"{e.get('read_improvement_pct', 0.0):+.1f}%" if e.get('read_improvement_pct') is not None else "N/A"
            write_penalty = f"{e.get('write_penalty_pct', 0.0):+.1f}%" if e.get('write_penalty_pct') is not None else "N/A"
            
            exp_table.append({
                "Experiment ID": e.get("experiment_id"),
                "Engine": e.get("database_type"),
                "Configuration": e.get("config_type"),
                "Workload Pattern": e.get("workload_name"),
                "Read Delta": read_change,
                "Write Overhead": write_penalty,
                "Duration": format_duration(e.get("total_duration_ms", 0)),
                "Recommendation": rec_class
            })

        st.dataframe(pd.DataFrame(exp_table), use_container_width=True)
    else:
        st.info("No recorded experiments found. Open **Index Laboratory** to benchmark baseline and candidate indexes.")

    st.markdown("</div>", unsafe_allow_html=True)
