import streamlit as st
import pandas as pd
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from database.seed_data import SeedDataGenerator
from ui.components import render_page_header
from utils.helpers import format_bytes

def render_schema_dataset():
    mysql_db = MySQLDatabase()
    mongo_db = MongoDBDatabase()

    render_page_header(
        title="Schema & Dataset Management",
        subtitle="Review database schema topology, inspect entity relationships, and seed reproducible synthetic workloads.",
        badge_text="SCHEMA & VOLUME",
        badge_type="gold"
    )

    tab1, tab2 = st.tabs(["Database Schema & Topology", "Data Generation & Seeding"])

    with tab1:
        col1, col2 = st.columns(2)

        with col1:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #C1121F; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                    <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">MySQL Relational Core</div>
                    <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Normalized tables with InnoDB foreign keys and non-negative constraints.</div>
                """,
                unsafe_allow_html=True
            )

            mysql_ok, _ = mysql_db.test_connection()
            if mysql_ok:
                counts = mysql_db.get_table_counts()
                table_rows = [
                    {"Table": "customers", "Primary Key": "customer_id", "Rows": f"{counts.get('customers', 0):,}", "Role": "Customer profiles"},
                    {"Table": "categories", "Primary Key": "category_id", "Rows": f"{counts.get('categories', 0):,}", "Role": "Taxonomy"},
                    {"Table": "products", "Primary Key": "product_id", "Rows": f"{counts.get('products', 0):,}", "Role": "Master catalog data"},
                    {"Table": "inventory", "Primary Key": "product_id", "Rows": f"{counts.get('inventory', 0):,}", "Role": "Real-time stock quantities"},
                    {"Table": "orders", "Primary Key": "order_id", "Rows": f"{counts.get('orders', 0):,}", "Role": "Order headers"},
                    {"Table": "order_items", "Primary Key": "order_item_id", "Rows": f"{counts.get('order_items', 0):,}", "Role": "Order lines"},
                    {"Table": "cart_items", "Primary Key": "cart_item_id", "Rows": f"{counts.get('cart_items', 0):,}", "Role": "Shopping cart items"},
                    {"Table": "experiments", "Primary Key": "experiment_id", "Rows": f"{counts.get('experiments', 0):,}", "Role": "Optimization audit logs"}
                ]
                st.dataframe(pd.DataFrame(table_rows), use_container_width=True)
            else:
                st.warning("MySQL is offline or unauthenticated. Connect in **Connections** screen.")
            st.markdown("</div>", unsafe_allow_html=True)

        with col2:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #D4AF37; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                    <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">MongoDB Document Catalog</div>
                    <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Nested attributes, variants, and flexible document search collection.</div>
                """,
                unsafe_allow_html=True
            )

            mongo_ok, _ = mongo_db.test_connection()
            if mongo_ok:
                stats = mongo_db.get_collection_stats("product_catalog")
                coll_rows = [
                    {"Metric": "Collection Name", "Value": "product_catalog"},
                    {"Metric": "Total Documents", "Value": f"{stats.get('count', 0):,}"},
                    {"Metric": "Data Storage Size", "Value": format_bytes(stats.get('size_bytes', 0))},
                    {"Metric": "Index Storage Size", "Value": format_bytes(stats.get('total_index_size_bytes', 0))},
                    {"Metric": "Active Indexes", "Value": str(stats.get('index_count', 0))}
                ]
                st.dataframe(pd.DataFrame(coll_rows), use_container_width=True)

                st.markdown("###### Document Indexes")
                indexes = mongo_db.list_indexes("product_catalog")
                idx_display = [{"Index Name": k, "Fields": str(v.get("key"))} for k, v in indexes.items()]
                st.dataframe(pd.DataFrame(idx_display), use_container_width=True)
            else:
                st.warning("MongoDB is offline.")
            st.markdown("</div>", unsafe_allow_html=True)

    with tab2:
        col_s1, col_s2 = st.columns(2)

        with col_s1:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #111111; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                    <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">1. Initialize Schemas</div>
                    <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Provisions MySQL tables with constraints and establishes the MongoDB unique identity index.</div>
                """,
                unsafe_allow_html=True
            )
            if st.button("Initialize Schemas", key="btn_init_schema", type="primary", use_container_width=True):
                with st.spinner("Initializing database schemas..."):
                    m_ok, m_msg = mysql_db.init_schema()
                    mg_ok, mg_msg = mongo_db.init_collection()

                if m_ok:
                    st.success(m_msg)
                else:
                    st.error(f"MySQL Init: {m_msg}")

                if mg_ok:
                    st.success(mg_msg)
                else:
                    st.error(f"MongoDB Init: {mg_msg}")
            st.markdown("</div>", unsafe_allow_html=True)

        with col_s2:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #C9A227; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                    <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">2. Generate Seed Data</div>
                    <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Fast bulk insertion using deterministic pseudo-random seeds.</div>
                """,
                unsafe_allow_html=True
            )

            cust_count = st.number_input("Customers", min_value=100, max_value=50000, value=1000, step=500)
            prod_count = st.number_input("Products", min_value=200, max_value=50000, value=2000, step=500)
            order_count = st.number_input("Orders", min_value=300, max_value=100000, value=3000, step=500)
            seed_val = st.number_input("Random Seed", value=42, step=1)

            st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
            if st.button("Generate Seed Dataset", key="btn_generate_data", type="primary", use_container_width=True):
                p_bar = st.progress(0.0)
                status_lbl = st.empty()

                def update_cb(msg, frac):
                    status_lbl.text(msg)
                    p_bar.progress(frac)

                generator = SeedDataGenerator(seed=seed_val, mysql_db=mysql_db, mongo_db=mongo_db)
                try:
                    res = generator.generate_all(
                        num_customers=int(cust_count),
                        num_products=int(prod_count),
                        num_orders=int(order_count),
                        progress_callback=update_cb
                    )
                    st.success(f"Generation successful: {res}")
                except Exception as e:
                    st.error(f"Data generation failed: {e}")

            st.markdown("</div>", unsafe_allow_html=True)
