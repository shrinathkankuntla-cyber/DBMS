import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase

def render_page_header(title: str, subtitle: str, badge_text: str = None, badge_type: str = "gold"):
    """
    Renders top page header with clean black typography and red/gold accenting.
    """
    badge_html = f"<span class='badge badge-{badge_type}' style='vertical-align: middle; margin-left: 10px;'>{badge_text}</span>" if badge_text else ""
    st.markdown(
        f"""
        <div style="margin-bottom: 24px; padding-bottom: 12px; border-bottom: 1px solid #D9D9D9;">
            <div style="display: flex; align-items: baseline; justify-content: space-between;">
                <h1 style="margin: 0; font-size: 1.85rem; font-weight: 800; color: #111111; letter-spacing: -0.03em;">
                    {title}{badge_html}
                </h1>
                <div style="width: 32px; height: 3px; background-color: #C1121F; border-radius: 2px;"></div>
            </div>
            <p style="margin: 5px 0 0 0; font-size: 0.95rem; color: #242424; font-weight: 400; max-width: 850px; line-height: 1.45;">
                {subtitle}
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

def render_metric_card(
    label: str,
    value: str,
    delta: str = None,
    delta_type: str = "neutral",
    subtext: str = None,
    variant: str = "white_red"
):
    """
    Renders premium metric cards with alternating visual treatments:
    1. 'white_red': White cards with black text and red accents
    2. 'black_gold': Black cards with white text and gold metrics
    3. 'white_red_gold': White cards with red headings and gold indicators
    """
    if variant == "black_gold":
        # Black card, gold metric, white text
        card_bg = "#111111"
        card_border = "border: 1px solid #242424; border-top: 3px solid #D4AF37;"
        label_color = "#D4AF37"
        val_color = "#FFFFFF"
        subtext_color = "#FAFAFA"
        d_color = "#D4AF37" if delta_type in ["positive", "gold"] else ("#C1121F" if delta_type == "negative" else "#FFFFFF")
    elif variant == "white_red_gold":
        # White card, red heading, black text, gold indicator
        card_bg = "#FFFFFF"
        card_border = "border: 1px solid #D9D9D9; border-top: 3px solid #D4AF37;"
        label_color = "#C1121F"
        val_color = "#111111"
        subtext_color = "#242424"
        d_color = "#C9A227" if delta_type in ["positive", "gold"] else ("#C1121F" if delta_type == "negative" else "#242424")
    else:
        # Default 'white_red': White card, black text, red accents
        card_bg = "#FFFFFF"
        card_border = "border: 1px solid #D9D9D9; border-top: 3px solid #C1121F;"
        label_color = "#242424"
        val_color = "#111111"
        subtext_color = "#242424"
        d_color = "#C1121F" if delta_type in ["negative", "red"] else ("#C9A227" if delta_type in ["positive", "gold"] else "#111111")

    delta_html = f"<span style='color: {d_color}; font-weight: 700; font-size: 0.85rem; margin-left: 8px;'>{delta}</span>" if delta else ""
    subtext_html = f"<div style='font-size: 0.78rem; color: {subtext_color}; margin-top: 6px;'>{subtext}</div>" if subtext else ""

    st.markdown(
        f"""
        <div style="background: {card_bg}; {card_border} border-radius: 8px; padding: 14px 18px; box-shadow: 0 1px 3px rgba(17,17,17,0.03);">
            <div style="font-size: 0.78rem; font-weight: 700; color: {label_color}; text-transform: uppercase; letter-spacing: 0.05em;">{label}</div>
            <div style="display: flex; align-items: baseline; margin-top: 4px;">
                <div style="font-family: 'IBM Plex Mono', monospace; font-size: 1.65rem; font-weight: 700; color: {val_color};">{value}</div>
                {delta_html}
            </div>
            {subtext_html}
        </div>
        """,
        unsafe_allow_html=True
    )

def render_status_badge(text: str, classification: str = "Neutral") -> str:
    """Returns HTML for color-coded status badge using strictly Red, Black, and Gold."""
    c = classification.lower()
    if "recommend" in c and "not" not in c:
        b_class = "badge-gold"
    elif "conditional" in c:
        b_class = "badge-black"
    elif "not recommend" in c or "reject" in c or "fail" in c:
        b_class = "badge-red"
    elif "gold" in c:
        b_class = "badge-gold"
    elif "black" in c:
        b_class = "badge-black"
    elif "red" in c:
        b_class = "badge-red"
    else:
        b_class = "badge-neutral"
    return f"<span class='badge {b_class}'>{text}</span>"

def render_sidebar_branding():
    """Renders the top branding for the sidebar with red accent and gold label."""
    st.sidebar.markdown(
        """
        <div style="margin-bottom: 22px; padding: 6px 4px 14px 4px; border-bottom: 1px solid #D9D9D9;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <div style="width: 14px; height: 14px; background-color: #C1121F; border-radius: 2px;"></div>
                <div style="font-family: 'Manrope', sans-serif; font-size: 1.15rem; font-weight: 800; color: #111111; letter-spacing: -0.02em;">
                    INDEX<span style="color: #C1121F;">OPTIMIZER</span>
                </div>
            </div>
            <div style="font-size: 0.75rem; color: #C9A227; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; margin-top: 3px;">
                E-Commerce Workload Lab
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

def render_sidebar_db_status():
    """Renders live database connection status in strict Red, Black & Gold palette."""
    mysql_db = MySQLDatabase()
    mongo_db = MongoDBDatabase()

    m_ok, _ = mysql_db.test_connection()
    mg_ok, _ = mongo_db.test_connection()

    m_bg = "#D4AF37" if m_ok else "#C1121F"
    m_fg = "#111111" if m_ok else "#FFFFFF"
    m_text = "ONLINE" if m_ok else "OFFLINE"

    mg_bg = "#D4AF37" if mg_ok else "#C1121F"
    mg_fg = "#111111" if mg_ok else "#FFFFFF"
    mg_text = "ONLINE" if mg_ok else "OFFLINE"

    st.sidebar.markdown(
        f"""
        <div style="margin-top: 28px; padding: 12px; background: #FAFAFA; border: 1px solid #D9D9D9; border-radius: 8px;">
            <div style="font-size: 0.72rem; font-weight: 700; color: #242424; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px;">
                Live Database Engines
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                <span style="font-size: 0.82rem; font-weight: 700; color: #111111;">MySQL (InnoDB)</span>
                <span style="font-size: 0.72rem; font-weight: 800; background: {m_bg}; color: {m_fg}; padding: 1px 8px; border-radius: 10px;">
                    {m_text}
                </span>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <span style="font-size: 0.82rem; font-weight: 700; color: #111111;">MongoDB</span>
                <span style="font-size: 0.72rem; font-weight: 800; background: {mg_bg}; color: {mg_fg}; padding: 1px 8px; border-radius: 10px;">
                    {mg_text}
                </span>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

def apply_chart_theme(fig):
    """Applies pure white canvas, minimal gridlines, and strict brand palette to Plotly figures."""
    fig.update_layout(
        paper_bgcolor="#FFFFFF",
        plot_bgcolor="#FFFFFF",
        font=dict(family="Inter, sans-serif", color="#111111", size=12),
        margin=dict(l=30, r=20, t=35, b=30),
        xaxis=dict(
            showgrid=True,
            gridcolor="#EBEBEB",
            linecolor="#D9D9D9",
            tickfont=dict(color="#242424", size=11)
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#EBEBEB",
            linecolor="#D9D9D9",
            tickfont=dict(color="#242424", size=11)
        ),
        legend=dict(
            bgcolor="rgba(255,255,255,0.95)",
            bordercolor="#D9D9D9",
            borderwidth=1,
            font=dict(color="#111111", size=11)
        )
    )
    return fig
