import streamlit as st
import pandas as pd
from pathlib import Path
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from data_pipeline.olist_ingestor import OlistIngestor, RAW_DATA_DIR, EXPECTED_FILES
from data_pipeline.sample_generator import OlistSampleDataGenerator
from data_pipeline.benchmark_isolation import BenchmarkDataIsolator
from workloads.cart_workload import CartWorkloadManager
from ui.components import render_page_header, render_metric_card, render_status_badge
from utils.helpers import format_bytes, format_duration

def render_olist_dataset():
    mysql_db = MySQLDatabase()
    mongo_db = MongoDBDatabase()
    ingestor = OlistIngestor(mysql_db=mysql_db, mongo_db=mongo_db)
    isolator = BenchmarkDataIsolator(mysql_db=mysql_db, mongo_db=mongo_db)
    cart_mgr = CartWorkloadManager(mysql_db=mysql_db)

    render_page_header(
        title="Olist E-Commerce Dataset Integration",
        subtitle="Ingestion pipeline, schema mapping, duplicate rejection, and benchmark isolation for the Brazilian E-Commerce dataset.",
        badge_text="OLIST PIPELINE",
        badge_type="gold"
    )

    tab_import, tab_report, tab_isolation, tab_cart = st.tabs([
        "Data Ingestion & Raw Files",
        "Validation & Audit Report",
        "Benchmark Isolation & Reset",
        "Simulated Cart Workload"
    ])

    # =========================================================================
    # TAB 1: DATA INGESTION & RAW FILES
    # =========================================================================
    with tab_import:
        col_up1, col_up2 = st.columns([1, 1])

        with col_up1:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #C1121F; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                    <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Manual Archive Import</div>
                    <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Upload the complete Olist ZIP archive directly into the data/raw repository without requiring Kaggle API credentials.</div>
                """,
                unsafe_allow_html=True
            )

            uploaded_zip = st.file_uploader(
                "Upload Olist Dataset Archive (.zip)",
                type=["zip"],
                help="Accepts the Brazilian E-Commerce archive containing the 9 CSV files."
            )

            if uploaded_zip is not None:
                if st.button("Extract & Replace CSVs in data/raw/", type="primary", use_container_width=True):
                    with st.spinner("Extracting ZIP archive to data/raw/..."):
                        ok, msg, files = ingestor.extract_zip_archive(uploaded_zip)
                    if ok:
                        st.success(f"Extraction successful: {len(files)} files extracted.")
                    else:
                        st.error(f"Extraction failed: {msg}")

            st.markdown("</div>", unsafe_allow_html=True)

            # Sample generator option for quick testing
            st.markdown(
                """
                <div style="background: #FAFAFA; border: 1px solid #D9D9D9; border-top: 3px solid #D4AF37; border-radius: 8px; padding: 16px 20px; margin-bottom: 16px;">
                    <div style="font-size: 0.95rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Generate Sample Olist Dataset</div>
                    <div style="font-size: 0.8rem; color: #242424; margin-bottom: 10px;">Creates high-fidelity, schema-compliant sample CSVs for all 9 files for immediate verification.</div>
                """,
                unsafe_allow_html=True
            )
            col_g1, col_g2 = st.columns(2)
            with col_g1:
                gen_cust = st.number_input("Sample Customers", min_value=50, max_value=2000, value=200, step=50)
            with col_g2:
                gen_orders = st.number_input("Sample Orders", min_value=50, max_value=2000, value=250, step=50)

            if st.button("Generate Sample CSV Files", type="secondary", use_container_width=True):
                sample_gen = OlistSampleDataGenerator()
                with st.spinner("Generating sample Olist CSV files in data/raw/..."):
                    res_counts = sample_gen.generate_all_samples(
                        num_customers=int(gen_cust),
                        num_products=int(gen_cust // 2),
                        num_orders=int(gen_orders)
                    )
                st.success(f"Generated 9 sample CSVs: {sum(res_counts.values())} total rows!")

            st.markdown("</div>", unsafe_allow_html=True)

        with col_up2:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #111111; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                    <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Local Raw Directory Status</div>
                    <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Inspection of all nine required Olist dataset files in <code>data/raw/</code>.</div>
                """,
                unsafe_allow_html=True
            )

            file_status = ingestor.scan_raw_files()
            table_data = []
            all_found = True

            for f_name, info in file_status.items():
                if not info["exists"]:
                    all_found = False
                status_str = "AVAILABLE" if info["exists"] else "MISSING"
                table_data.append({
                    "Dataset File": f_name,
                    "Status": status_str,
                    "Size": format_bytes(info["size_bytes"]) if info["exists"] else "0 B",
                    "Est. Rows": f"{info['rows_estimate']:,}" if info["exists"] else "0"
                })

            st.dataframe(pd.DataFrame(table_data), use_container_width=True)

            st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
            max_limit = st.number_input("Max Rows per File (0 for unlimited)", min_value=0, max_value=200000, value=0, step=1000)
            limit_val = int(max_limit) if max_limit > 0 else None

            if st.button("Execute Full Ingestion Pipeline", type="primary", use_container_width=True, disabled=(not any(f["exists"] for f in file_status.values()))):
                p_bar = st.progress(0.0)
                status_lbl = st.empty()

                def update_ingest_cb(msg, frac):
                    status_lbl.markdown(f"**Status:** {msg}")
                    p_bar.progress(frac)

                with st.spinner("Ingesting Olist dataset into MySQL & MongoDB..."):
                    ingest_report = ingestor.run_ingestion_pipeline(
                        max_rows_per_file=limit_val,
                        progress_callback=update_ingest_cb
                    )

                st.session_state["latest_olist_ingest_report"] = ingest_report
                if ingest_report["success"]:
                    st.success(f"Ingestion completed! Inserted {ingest_report['total_records_inserted']} records in {format_duration(ingest_report['duration_ms'])}.")
                else:
                    st.error(f"Ingestion error: {ingest_report.get('error')}")

            st.markdown("</div>", unsafe_allow_html=True)

    # =========================================================================
    # TAB 2: VALIDATION & AUDIT REPORT
    # =========================================================================
    with tab_report:
        report = st.session_state.get("latest_olist_ingest_report")

        if report:
            m1, m2, m3, m4 = st.columns(4)
            with m1:
                render_metric_card("Records Inserted", f"{report.get('total_records_inserted', 0):,}", delta="Valid Records", delta_type="gold", variant="white_red")
            with m2:
                render_metric_card("Duplicates Skipped", f"{report.get('total_duplicates_skipped', 0):,}", delta="Deduplicated", delta_type="gold", variant="black_gold")
            with m3:
                render_metric_card("Rejected Rows", f"{report.get('total_rejected_rows', 0):,}", delta="Orphans/Invalid", delta_type="red", variant="white_red_gold")
            with m4:
                render_metric_card("Ingestion Time", format_duration(report.get("duration_ms", 0)), delta="Pipeline Duration", delta_type="gold", variant="black_gold")

            st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)
            st.markdown("##### File-by-File Ingestion Breakdown")

            breakdown_rows = []
            for f_name, stats in report.get("files_processed", {}).items():
                breakdown_rows.append({
                    "Dataset File": f_name,
                    "Rows Read": f"{stats.get('read', 0):,}",
                    "Valid Inserted": f"{stats.get('inserted', 0):,}",
                    "Duplicates Skipped": f"{stats.get('duplicates', 0):,}",
                    "Rejected": f"{stats.get('rejected', 0):,}",
                    "Status": "COMPLETED"
                })

            st.dataframe(pd.DataFrame(breakdown_rows), use_container_width=True)

            if report.get("rejection_reasons"):
                st.markdown("##### Rejection & Error Audit Details")
                for r in report["rejection_reasons"]:
                    st.error(r)
        else:
            st.info("No active ingestion report recorded in this session. Run the ingestion pipeline in Tab 1 to view validation reports.")

    # =========================================================================
    # TAB 3: BENCHMARK ISOLATION & RESET
    # =========================================================================
    with tab_isolation:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #111111; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Historical vs. Benchmark Data Separation</div>
                <div style="font-size: 0.82rem; color: #242424; margin-bottom: 14px;">
                    Original Olist records are tagged with <code>data_origin = 'imported'</code>. All simulated cart transactions, order placements, and candidate tests are tagged with <code>data_origin = 'benchmark'</code>.
                    Resetting benchmark mutations restores stock quantities to baseline and cleans test transactions without touching historical data.
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        b_stats = isolator.get_data_breakdown()

        col_iso1, col_iso2 = st.columns(2)

        with col_iso1:
            st.markdown("##### MySQL Data Origin Distribution")
            mysql_iso_rows = []
            for tbl, counts in b_stats.get("mysql", {}).items():
                if tbl == "inventory":
                    mysql_iso_rows.append({
                        "Table": tbl,
                        "Imported Baseline": f"{counts.get('total_tracked', 0):,}",
                        "Benchmark Modifications": f"{counts.get('modified_from_baseline', 0):,}"
                    })
                else:
                    mysql_iso_rows.append({
                        "Table": tbl,
                        "Imported Baseline": f"{counts.get('imported', 0):,}",
                        "Benchmark Modifications": f"{counts.get('benchmark', 0):,}"
                    })
            st.dataframe(pd.DataFrame(mysql_iso_rows), use_container_width=True)

        with col_iso2:
            st.markdown("##### MongoDB Catalogue Origin Distribution")
            mongo_cat = b_stats.get("mongodb", {}).get("product_catalog", {})
            mongo_iso_rows = [
                {"Collection": "product_catalog", "Origin": "Historical Imported", "Document Count": f"{mongo_cat.get('imported', 0):,}"},
                {"Collection": "product_catalog", "Origin": "Benchmark Generated", "Document Count": f"{mongo_cat.get('benchmark', 0):,}"},
                {"Collection": "product_catalog", "Origin": "Total Documents", "Document Count": f"{mongo_cat.get('total', 0):,}"}
            ]
            st.dataframe(pd.DataFrame(mongo_iso_rows), use_container_width=True)

        st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)
        if st.button("Reset Benchmark Mutable Data (Preserve Imported Dataset)", type="primary"):
            with st.spinner("Cleaning benchmark mutations and resetting inventory..."):
                ok, msg, del_counts = isolator.reset_benchmark_data()
            if ok:
                st.success(msg)
                st.json(del_counts)
            else:
                st.error(f"Reset failed: {msg}")

    # =========================================================================
    # TAB 4: SIMULATED CART WORKLOAD
    # =========================================================================
    with tab_cart:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #C1121F; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Simulated Cart Activity Engine</div>
                <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">
                    Because the Olist dataset contains completed historical orders without shopping cart sessions, this module simulates active carts with stock validation, updates, removals, and transactional checkouts.
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        col_c1, col_c2 = st.columns([1, 1])

        with col_c1:
            st.markdown("##### Stochastic Cart Workload Simulation")
            num_ops = st.number_input("Number of Cart Operations", min_value=5, max_value=500, value=25, step=5)

            if st.button("Execute Simulated Cart Workload", type="primary", use_container_width=True):
                with st.spinner(f"Simulating {num_ops} cart interactions..."):
                    c_sim_res = cart_mgr.simulate_random_cart_workload(num_operations=int(num_ops))

                if c_sim_res.get("success"):
                    st.success(f"Executed {c_sim_res['total_operations']} cart operations with avg latency {c_sim_res['average_latency_ms']:.2f} ms!")
                    st.json(c_sim_res["breakdown"])
                else:
                    st.error(f"Cart simulation error: {c_sim_res.get('error')}")

        with col_c2:
            st.markdown("##### Interactive Customer Cart Inspector")
            # Select customer
            try:
                with mysql_db.get_connection() as conn:
                    cursor = conn.cursor(dictionary=True)
                    cursor.execute("SELECT customer_id, full_name FROM customers LIMIT 50")
                    c_rows = cursor.fetchall()
                    cursor.close()
            except Exception:
                c_rows = []

            if c_rows:
                c_map = {f"Customer #{r['customer_id']} ({r['full_name']})": r["customer_id"] for r in c_rows}
                chosen_cust_label = st.selectbox("Select Customer to Inspect Cart", list(c_map.keys()), index=0)
                chosen_cid = c_map[chosen_cust_label]

                cart_items = cart_mgr.get_cart_items(chosen_cid)
                if cart_items:
                    st.dataframe(pd.DataFrame(cart_items), use_container_width=True)
                    if st.button("Checkout Customer Cart (Atomic ACID Transaction)", type="secondary"):
                        with st.spinner("Checking out cart..."):
                            chk_res = cart_mgr.checkout_cart(chosen_cid)
                        if chk_res.get("success"):
                            st.success(f"Order #{chk_res['order_id']} created! Amount: ${chk_res['total_amount']:.2f} in {chk_res['latency_ms']:.2f} ms")
                        else:
                            st.error(f"Checkout failed: {chk_res.get('error')}")
                else:
                    st.info(f"No active cart items for Customer #{chosen_cid}.")
            else:
                st.info("Ingest dataset first to load customer profiles.")
