import streamlit as st
from config.settings import get_env, update_env_file
from config.database_config import MySQLConfig, MongoDBConfig
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from ui.components import render_page_header

def render_connections():
    render_page_header(
        title="Database Connections",
        subtitle="Manage and verify connection parameters for MySQL (relational core) and MongoDB (product catalog).",
        badge_text="DATABASE ACCESS",
        badge_type="black"
    )

    col1, col2 = st.columns(2)

    # --- MySQL Connection Panel (Primary Red Accent) ---
    with col1:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 4px solid #C1121F; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 8px;">
                    <div style="font-size: 1.05rem; font-weight: 800; color: #111111;">MySQL Engine (InnoDB)</div>
                    <span class="badge badge-red">RELATIONAL CORE</span>
                </div>
                <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Authoritative for ACID transactions, inventory constraints, and orders.</div>
            """,
            unsafe_allow_html=True
        )

        with st.form("mysql_conn_form"):
            mysql_host = st.text_input("Host", value=get_env("MYSQL_HOST", "localhost"))
            mysql_port = st.number_input("Port", value=int(get_env("MYSQL_PORT", "3306")), min_value=1, max_value=65535)
            mysql_user = st.text_input("Username", value=get_env("MYSQL_USER", "root"))
            mysql_password = st.text_input("Password", value=get_env("MYSQL_PASSWORD", ""), type="password")
            mysql_db_name = st.text_input("Database Name", value=get_env("MYSQL_DATABASE", "ecommerce_optimizer"))

            btn_save_mysql = st.form_submit_button("Save & Update MySQL Settings", type="primary")
            if btn_save_mysql:
                update_env_file({
                    "MYSQL_HOST": mysql_host,
                    "MYSQL_PORT": str(mysql_port),
                    "MYSQL_USER": mysql_user,
                    "MYSQL_PASSWORD": mysql_password,
                    "MYSQL_DATABASE": mysql_db_name
                })
                st.success("MySQL parameters saved to local environment.")

        st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
        if st.button("Test MySQL Connection", key="btn_test_mysql", use_container_width=True):
            cfg = MySQLConfig(
                host=mysql_host,
                port=int(mysql_port),
                user=mysql_user,
                password=mysql_password,
                database=mysql_db_name
            )
            db = MySQLDatabase(cfg)
            with st.spinner("Connecting to MySQL..."):
                ok, msg = db.test_connection()
            if ok:
                st.success(f"Connected: {msg}")
            else:
                st.error(f"Connection Failed: {msg}")
                st.markdown(
                    """
                    <div style="background: #FFF2F2; border: 1.5px solid #C1121F; border-radius: 6px; padding: 10px 14px; font-size: 0.85rem; color: #C1121F; margin-top: 8px;">
                        <b>Troubleshooting Tips:</b>
                        <ul style="margin: 4px 0 0 16px; padding: 0;">
                            <li>Verify your MySQL <code>root</code> password set during installation.</li>
                            <li>Confirm port 3306 is listening and the Windows service is running.</li>
                        </ul>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

        st.markdown("</div>", unsafe_allow_html=True)

    # --- MongoDB Connection Panel (Metallic Gold Accent) ---
    with col2:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 4px solid #D4AF37; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 8px;">
                    <div style="font-size: 1.05rem; font-weight: 800; color: #111111;">MongoDB Document Engine</div>
                    <span class="badge badge-gold">DOCUMENT CATALOG</span>
                </div>
                <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Houses flexible catalog attributes, nested variants, and document search indexes.</div>
            """,
            unsafe_allow_html=True
        )

        with st.form("mongo_conn_form"):
            mongo_uri = st.text_input("Connection URI", value=get_env("MONGODB_URI", "mongodb://localhost:27017/"))
            mongo_db_name = st.text_input("Database Name", value=get_env("MONGODB_DATABASE", "ecommerce_optimizer"))

            btn_save_mongo = st.form_submit_button("Save & Update MongoDB Settings", type="primary")
            if btn_save_mongo:
                update_env_file({
                    "MONGODB_URI": mongo_uri,
                    "MONGODB_DATABASE": mongo_db_name
                })
                st.success("MongoDB parameters saved to local environment.")

        st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
        if st.button("Test MongoDB Connection", key="btn_test_mongo", use_container_width=True):
            cfg = MongoDBConfig(uri=mongo_uri, database=mongo_db_name)
            db = MongoDBDatabase(cfg)
            with st.spinner("Connecting to MongoDB..."):
                ok, msg = db.test_connection()
            if ok:
                st.success(f"Connected: {msg}")
            else:
                st.error(f"Connection Failed: {msg}")

        st.markdown("</div>", unsafe_allow_html=True)
