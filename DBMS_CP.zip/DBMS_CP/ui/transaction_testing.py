import streamlit as st
import pandas as pd
from database.mysql_connection import MySQLDatabase
from transactions.transaction_tests import TransactionTestSuite
from ui.components import render_page_header

def render_transaction_testing():
    mysql_db = MySQLDatabase()
    tx_suite = TransactionTestSuite(mysql_db)

    render_page_header(
        title="Transaction Testing & Invariants",
        subtitle="Empirically demonstrate MySQL ACID properties, row-level locking (SELECT FOR UPDATE), rollbacks, and business invariants.",
        badge_text="ACID VALIDATION",
        badge_type="red"
    )

    mysql_ok, _ = mysql_db.test_connection()
    if not mysql_ok:
        st.warning("MySQL connection is offline or unauthenticated. Connect in **Connections** screen to run live transaction suites.")
        return

    st.markdown(
        """
        <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #C1121F; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 20px;">
            <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 4px;">Automated ACID & Invariant Test Suite</div>
            <div style="font-size: 0.85rem; color: #242424; margin-bottom: 14px;">Evaluates 6 transaction scenarios under strict concurrency and integrity assertions:</div>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; font-size: 0.82rem;">
                <div style="background: #FAFAFA; padding: 10px 14px; border-radius: 6px; border-left: 3px solid #D4AF37;"><b>1. Order Placement</b><br>Atomicity & Inventory deduction</div>
                <div style="background: #FAFAFA; padding: 10px 14px; border-radius: 6px; border-left: 3px solid #C9A227;"><b>2. Insufficient Stock</b><br>Rollback & stock preservation</div>
                <div style="background: #FAFAFA; padding: 10px 14px; border-radius: 6px; border-left: 3px solid #C1121F;"><b>3. Invalid Product</b><br>Referential constraint rollback</div>
                <div style="background: #FAFAFA; padding: 10px 14px; border-radius: 6px; border-left: 3px solid #8F0D18;"><b>4. Injected Mid-Crash</b><br>Exception isolation rollback</div>
                <div style="background: #FAFAFA; padding: 10px 14px; border-radius: 6px; border-left: 3px solid #D4AF37;"><b>5. Order Cancellation</b><br>Safe inventory restoration</div>
                <div style="background: #FAFAFA; padding: 10px 14px; border-radius: 6px; border-left: 3px solid #111111;"><b>6. Duplicate Cancellation</b><br>Prevention of double restock</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

    if st.button("Run All 6 Transaction Scenarios", type="primary", use_container_width=True):
        with st.spinner("Executing transaction test suite..."):
            results = tx_suite.run_all_scenarios()

        all_passed = all(r["passed"] for r in results)
        if all_passed:
            st.success("ALL 6 TRANSACTION SCENARIOS PASSED WITH STRICT INVARIANT VALIDATION!")
        else:
            st.error("ONE OR MORE TRANSACTION SCENARIOS FAILED.")

        for r in results:
            badge_type = "badge-gold" if r["passed"] else "badge-red"
            badge_text = "PASSED" if r["passed"] else "FAILED"
            with st.expander(f"{r['scenario']} — {badge_text}", expanded=not r["passed"]):
                st.markdown(f"**Assertion Result:** <span class='badge {badge_type}'>{badge_text}</span>", unsafe_allow_html=True)
                st.markdown(f"**Verification:** {r['details']}")
                st.markdown("###### Transaction Execution Audit Log:")
                for s in r.get("steps", []):
                    st.markdown(f"- `{s}`")
                st.json(r["result"])
