import streamlit as st
import pandas as pd
import json
import plotly.express as px
import plotly.graph_objects as go
from optimizer.benchmark_engine import BenchmarkEngine, LOCAL_EXP_DIR
from database.mysql_connection import MySQLDatabase
from ui.components import render_page_header, render_metric_card, render_status_badge, apply_chart_theme
from utils.helpers import format_bytes, format_duration

def render_analytics():
    mysql_db = MySQLDatabase()
    experiments = BenchmarkEngine.list_experiments(mysql_db)

    render_page_header(
        title="Performance Analytics",
        subtitle="In-depth empirical breakdown of query latency distributions, write penalties, and index storage overhead.",
        badge_text="TELEMETRY & CHARTS",
        badge_type="gold"
    )

    if not experiments:
        st.info("No benchmark experiments logged. Execute trials in the **Index Laboratory** to populate analytics.")
        return

    # Select trial to analyze
    col_s1, col_s2 = st.columns([3, 1])
    with col_s1:
        exp_options = [f"{e['experiment_id']} ({e['database_type']} - {e['config_type']} - {e.get('workload_name', '')})" for e in experiments]
        selected_idx = st.selectbox("Select Experiment Trial for Analysis", range(len(exp_options)), format_func=lambda i: exp_options[i])
        selected_exp = experiments[selected_idx]

    with col_s2:
        st.markdown(
            f"""
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #C1121F; border-radius: 6px; padding: 10px 14px; text-align: right;">
                <div style="font-size: 0.7rem; font-weight: 700; color: #242424; text-transform: uppercase;">Engine Target</div>
                <div style="font-size: 0.95rem; font-weight: 800; color: #C1121F;">{selected_exp['database_type']}</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    # Load experiment JSON
    exp_file = LOCAL_EXP_DIR / f"{selected_exp['experiment_id']}.json"
    full_data = None
    if exp_file.exists():
        try:
            with open(exp_file, "r", encoding="utf-8") as f:
                full_data = json.load(f)
        except Exception:
            pass

    if full_data:
        base = full_data.get("baseline", {})
        cand = full_data.get("candidate", {})
        rec = full_data.get("recommendation", {})
        tradeoffs = rec.get("tradeoffs", {})

        # Top Metric Cards with Alternating Visual Treatments
        st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
        c1, c2, c3, c4 = st.columns(4)

        read_imp = tradeoffs.get("read", {}).get("improvement_pct", 0)
        write_pen = tradeoffs.get("write", {}).get("penalty_pct", 0)
        dur_imp = tradeoffs.get("total_duration", {}).get("improvement_pct", 0)
        stor_delta = tradeoffs.get("storage", {}).get("delta_bytes", 0)

        with c1:
            render_metric_card(
                "Read Latency (Median)",
                f"{tradeoffs.get('read', {}).get('candidate_median_ms', 0):.2f} ms",
                delta=f"{read_imp:+.1f}%",
                delta_type="gold" if read_imp >= 0 else "negative",
                subtext=f"Baseline: {tradeoffs.get('read', {}).get('baseline_median_ms', 0):.2f} ms",
                variant="white_red"
            )

        with c2:
            render_metric_card(
                "Write Latency (Median)",
                f"{tradeoffs.get('write', {}).get('candidate_median_ms', 0):.2f} ms",
                delta=f"{write_pen:+.1f}% penalty",
                delta_type="negative" if write_pen > 10 else "gold",
                subtext=f"Baseline: {tradeoffs.get('write', {}).get('baseline_median_ms', 0):.2f} ms",
                variant="black_gold"
            )

        with c3:
            render_metric_card(
                "Total Workload Duration",
                format_duration(cand.get("total_duration_ms", 0)),
                delta=f"{dur_imp:+.1f}%",
                delta_type="gold" if dur_imp >= 0 else "negative",
                subtext=f"Baseline: {format_duration(base.get('total_duration_ms', 0))}",
                variant="white_red_gold"
            )

        with c4:
            render_metric_card(
                "Index Storage Footprint",
                format_bytes(tradeoffs.get("storage", {}).get("candidate_bytes", 0)),
                delta=f"{stor_delta:+,} B",
                delta_type="gold",
                subtext=f"Delta vs. Baseline",
                variant="black_gold"
            )

        st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

        # Charts Row 1: Brand Palette Only (Red for Baseline, Gold for Candidate)
        col_ch1, col_ch2 = st.columns(2)

        with col_ch1:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #C1121F; border-radius: 8px; padding: 16px 20px 8px 20px; box-shadow: 0 1px 3px rgba(17,17,17,0.02);">
                    <div style="font-size: 0.95rem; font-weight: 800; color: #111111;">Median vs. P95 Tail Latency (ms)</div>
                    <div style="font-size: 0.8rem; color: #242424;">Empirical evaluation of typical vs. 95th percentile query execution.</div>
                </div>
                """,
                unsafe_allow_html=True
            )
            latency_df = pd.DataFrame([
                {"Configuration": "Baseline", "Metric": "Median", "Latency (ms)": base.get("total_latency_stats", {}).get("median_ms", 0)},
                {"Configuration": "Baseline", "Metric": "P95 Tail", "Latency (ms)": base.get("total_latency_stats", {}).get("p95_ms", 0)},
                {"Configuration": f"Candidate ({full_data['candidate_configuration']})", "Metric": "Median", "Latency (ms)": cand.get("total_latency_stats", {}).get("median_ms", 0)},
                {"Configuration": f"Candidate ({full_data['candidate_configuration']})", "Metric": "P95 Tail", "Latency (ms)": cand.get("total_latency_stats", {}).get("p95_ms", 0)}
            ])
            fig1 = px.bar(
                latency_df,
                x="Metric",
                y="Latency (ms)",
                color="Configuration",
                barmode="group",
                color_discrete_sequence=["#C1121F", "#D4AF37"]
            )
            apply_chart_theme(fig1)
            st.plotly_chart(fig1, use_container_width=True)

        with col_ch2:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #D4AF37; border-radius: 8px; padding: 16px 20px 8px 20px; box-shadow: 0 1px 3px rgba(17,17,17,0.02);">
                    <div style="font-size: 0.95rem; font-weight: 800; color: #111111;">Read Acceleration vs. Write Penalty</div>
                    <div style="font-size: 0.8rem; color: #242424;">Observed latency change across read searches and write modifications.</div>
                </div>
                """,
                unsafe_allow_html=True
            )
            rw_df = pd.DataFrame([
                {"Configuration": "Baseline", "Operation": "Read Queries", "Latency (ms)": base.get("read_latency_stats", {}).get("median_ms", 0)},
                {"Configuration": "Baseline", "Operation": "Write Transactions", "Latency (ms)": base.get("write_latency_stats", {}).get("median_ms", 0)},
                {"Configuration": f"Candidate ({full_data['candidate_configuration']})", "Operation": "Read Queries", "Latency (ms)": cand.get("read_latency_stats", {}).get("median_ms", 0)},
                {"Configuration": f"Candidate ({full_data['candidate_configuration']})", "Operation": "Write Transactions", "Latency (ms)": cand.get("write_latency_stats", {}).get("median_ms", 0)}
            ])
            fig2 = px.bar(
                rw_df,
                x="Operation",
                y="Latency (ms)",
                color="Configuration",
                barmode="group",
                color_discrete_sequence=["#C1121F", "#D4AF37"]
            )
            apply_chart_theme(fig2)
            st.plotly_chart(fig2, use_container_width=True)

        # Charts Row 2
        col_ch3, col_ch4 = st.columns(2)

        with col_ch3:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #111111; border-radius: 8px; padding: 16px 20px 8px 20px; box-shadow: 0 1px 3px rgba(17,17,17,0.02);">
                    <div style="font-size: 0.95rem; font-weight: 800; color: #111111;">Workload Throughput (QPS)</div>
                    <div style="font-size: 0.8rem; color: #242424;">Queries and transactions processed per second.</div>
                </div>
                """,
                unsafe_allow_html=True
            )
            qps_df = pd.DataFrame([
                {"Configuration": "Baseline", "Throughput (QPS)": base.get("throughput_qps", 0)},
                {"Configuration": f"Candidate ({full_data['candidate_configuration']})", "Throughput (QPS)": cand.get("throughput_qps", 0)}
            ])
            fig3 = px.bar(
                qps_df,
                x="Configuration",
                y="Throughput (QPS)",
                color="Configuration",
                color_discrete_sequence=["#C1121F", "#D4AF37"]
            )
            apply_chart_theme(fig3)
            st.plotly_chart(fig3, use_container_width=True)

        with col_ch4:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #D4AF37; border-radius: 8px; padding: 16px 20px 8px 20px; box-shadow: 0 1px 3px rgba(17,17,17,0.02);">
                    <div style="font-size: 0.95rem; font-weight: 800; color: #111111;">Index Storage Footprint (Bytes)</div>
                    <div style="font-size: 0.8rem; color: #242424;">Disk space consumed by database indexes.</div>
                </div>
                """,
                unsafe_allow_html=True
            )
            stor_df = pd.DataFrame([
                {"Configuration": "Baseline", "Storage": tradeoffs.get("storage", {}).get("baseline_bytes", 0)},
                {"Configuration": f"Candidate ({full_data['candidate_configuration']})", "Storage": tradeoffs.get("storage", {}).get("candidate_bytes", 0)}
            ])
            fig4 = px.bar(
                stor_df,
                x="Configuration",
                y="Storage",
                color="Configuration",
                color_discrete_sequence=["#C1121F", "#D4AF37"]
            )
            apply_chart_theme(fig4)
            st.plotly_chart(fig4, use_container_width=True)

    else:
        st.write("Summary from historical database record:")
        st.json(selected_exp)
