import streamlit as st
import json
import pandas as pd
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from optimizer.explain_analyzer import ExplainAnalyzer
from utils.validators import validate_sql_safety, classify_sql
from utils.helpers import Timer, format_duration
from ui.components import render_page_header

def render_query_workspace():
    mysql_db = MySQLDatabase()
    mongo_db = MongoDBDatabase()
    explain_analyzer = ExplainAnalyzer(mysql_db, mongo_db)

    render_page_header(
        title="Query Workspace",
        subtitle="Side-by-side terminal for executing and comparing equivalent business operations across relational and document engines.",
        badge_text="DUAL TERMINAL",
        badge_type="black"
    )

    col_sql, col_mongo = st.columns(2)

    # --- LEFT PANE: MYSQL WORKBENCH (Black Header with Red Accent) ---
    with col_sql:
        st.markdown(
            """
            <div style="background: #111111; color: #FFFFFF; padding: 12px 18px; border-radius: 8px 8px 0 0; display: flex; justify-content: space-between; align-items: center; border: 1px solid #111111; border-bottom: none;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <div style="width: 12px; height: 12px; background-color: #C1121F; border-radius: 2px;"></div>
                    <span style="font-family: 'Manrope', sans-serif; font-weight: 800; font-size: 0.95rem; letter-spacing: 0.02em;">MYSQL ENGINE (INNODB)</span>
                </div>
                <span class="badge badge-red" style="font-size: 0.7rem;">SQL CORE</span>
            </div>
            """,
            unsafe_allow_html=True
        )

        default_sql = (
            "SELECT p.product_id, p.product_name, c.category_name, p.price, p.status\n"
            "FROM products p\n"
            "JOIN categories c ON p.category_id = c.category_id\n"
            "WHERE p.price BETWEEN 50.00 AND 300.00\n"
            "ORDER BY p.price ASC\n"
            "LIMIT 50;"
        )

        sql_input = st.text_area(
            "SQL Query Editor",
            value=default_sql,
            height=140,
            key="mysql_sql_input",
            label_visibility="collapsed"
        )

        sql_type = classify_sql(sql_input)
        is_write = (sql_type == "WRITE")

        confirm_write = False
        if is_write:
            st.markdown(
                """
                <div style="background: #FFF2F2; border: 1.5px solid #C1121F; border-radius: 6px; padding: 10px 14px; font-size: 0.85rem; color: #C1121F; font-weight: 700; margin-bottom: 8px;">
                    ⚠️ Write statement detected (INSERT / UPDATE / DELETE / DDL). User confirmation required.
                </div>
                """,
                unsafe_allow_html=True
            )
            confirm_write = st.checkbox("Confirm execution of write query", key="confirm_sql_write")

        btn_exec_sql = st.button("Execute MySQL Query", key="btn_exec_sql", type="primary", use_container_width=True)

        if btn_exec_sql:
            safe, err_msg = validate_sql_safety(sql_input)
            if not safe:
                st.error(f"Execution rejected: {err_msg}")
            elif is_write and not confirm_write:
                st.error("Please confirm write operation before execution.")
            else:
                with Timer() as timer:
                    success, rows, err = mysql_db.execute_query(sql_input, fetch=(not is_write))

                if success:
                    st.markdown(
                        f"""
                        <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 2px solid #C1121F; border-radius: 6px; padding: 10px 14px; margin: 10px 0; display: flex; justify-content: space-between;">
                            <span><b>Status:</b> Success</span>
                            <span><b>Latency:</b> <span class="mono-num" style="color:#C1121F; font-weight:700;">{format_duration(timer.elapsed_ms)}</span></span>
                            <span><b>Rows:</b> <span class="mono-num">{len(rows) if rows and not is_write else rows}</span></span>
                        </div>
                        """,
                        unsafe_allow_html=True
                    )

                    if not is_write and rows:
                        st.dataframe(pd.DataFrame(rows), use_container_width=True)

                    if sql_type == "READ":
                        with st.expander("Inspect MySQL Execution Plan"):
                            plan = explain_analyzer.explain_mysql_query(sql_input)
                            if plan.get("success"):
                                s = plan["summary"]
                                st.write(f"- Table Scan (ALL): **{s['is_table_scan']}**")
                                st.write(f"- Indexes Used: **{', '.join(s['indexes_used'])}**")
                                st.dataframe(pd.DataFrame(plan["explain_rows"]), use_container_width=True)
                else:
                    st.error(f"MySQL Error: {err}")

    # --- RIGHT PANE: MONGODB WORKBENCH (Black Header with Gold Accent) ---
    with col_mongo:
        st.markdown(
            """
            <div style="background: #111111; color: #FFFFFF; padding: 12px 18px; border-radius: 8px 8px 0 0; display: flex; justify-content: space-between; align-items: center; border: 1px solid #111111; border-bottom: none;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <div style="width: 12px; height: 12px; background-color: #D4AF37; border-radius: 2px;"></div>
                    <span style="font-family: 'Manrope', sans-serif; font-weight: 800; font-size: 0.95rem; letter-spacing: 0.02em;">MONGODB ENGINE (CATALOG)</span>
                </div>
                <span class="badge badge-gold" style="font-size: 0.7rem;">MQL CATALOG</span>
            </div>
            """,
            unsafe_allow_html=True
        )

        default_filter = '{\n  "price": {"$gte": 50.0, "$lte": 300.0}\n}'
        filter_input = st.text_area(
            "MongoDB Filter (JSON)",
            value=default_filter,
            height=140,
            key="mongo_filter_input",
            label_visibility="collapsed"
        )

        c_sort, c_limit = st.columns(2)
        with c_sort:
            sort_field = st.selectbox("Sort By", ["price", "created_at", "product_id"], index=0)
            sort_dir = st.selectbox("Sort Direction", ["ASC (1)", "DESC (-1)"], index=0)
            sort_val = 1 if "ASC" in sort_dir else -1
        with c_limit:
            mongo_limit = st.number_input("Limit", min_value=1, max_value=500, value=50, step=10)

        btn_exec_mongo = st.button("Execute MongoDB Find", key="btn_exec_mongo", type="primary", use_container_width=True)

        if btn_exec_mongo:
            try:
                filter_doc = json.loads(filter_input) if filter_input.strip() else {}
            except json.JSONDecodeError as je:
                st.error(f"Invalid JSON syntax in filter: {je}")
                filter_doc = None

            if filter_doc is not None:
                coll = mongo_db.get_collection("product_catalog")
                with Timer() as timer:
                    try:
                        cursor = coll.find(filter_doc).sort(sort_field, sort_val).limit(int(mongo_limit))
                        docs = list(cursor)
                        mongo_err = None
                    except Exception as me:
                        docs = []
                        mongo_err = str(me)

                if mongo_err:
                    st.error(f"MongoDB Error: {mongo_err}")
                else:
                    st.markdown(
                        f"""
                        <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 2px solid #D4AF37; border-radius: 6px; padding: 10px 14px; margin: 10px 0; display: flex; justify-content: space-between;">
                            <span><b>Status:</b> Success</span>
                            <span><b>Latency:</b> <span class="mono-num" style="color:#C9A227; font-weight:700;">{format_duration(timer.elapsed_ms)}</span></span>
                            <span><b>Documents:</b> <span class="mono-num">{len(docs)}</span></span>
                        </div>
                        """,
                        unsafe_allow_html=True
                    )

                    for d in docs:
                        if "_id" in d:
                            d["_id"] = str(d["_id"])

                    if docs:
                        preview_rows = [{
                            "product_id": d.get("product_id"),
                            "product_name": d.get("product_name"),
                            "category": d.get("category"),
                            "price": d.get("price"),
                            "brand": d.get("brand"),
                            "status": d.get("status")
                        } for d in docs]
                        st.dataframe(pd.DataFrame(preview_rows), use_container_width=True)

                        with st.expander("View Full Raw Documents (JSON)"):
                            st.json(docs[:5])

                    with st.expander("Inspect MongoDB executionStats"):
                        plan = explain_analyzer.explain_mongo_query(
                            collection_name="product_catalog",
                            filter_doc=filter_doc,
                            sort_doc=[(sort_field, sort_val)],
                            limit=int(mongo_limit)
                        )
                        if plan.get("success"):
                            st.write(f"- Collection Scan: **{plan['is_collection_scan']}**")
                            st.write(f"- Indexes Used: **{', '.join(plan['indexes_used'])}**")
                            st.write(f"- Docs Examined: `{plan['docs_examined']}` | Keys Examined: `{plan['keys_examined']}`")
