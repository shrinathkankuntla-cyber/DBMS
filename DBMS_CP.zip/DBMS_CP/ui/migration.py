import streamlit as st
import pandas as pd
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from migration.mysql_to_mongodb import MySQLToMongoDBMigrator
from migration.mongodb_to_mysql import MongoDBToMySQLMigrator
from migration.validation import MigrationValidator
from ui.components import render_page_header, render_metric_card
from utils.helpers import format_duration

def render_migration():
    mysql_db = MySQLDatabase()
    mongo_db = MongoDBDatabase()
    mysql_to_mongo = MySQLToMongoDBMigrator(mysql_db, mongo_db)
    mongo_to_mysql = MongoDBToMySQLMigrator(mysql_db, mongo_db)
    validator = MigrationValidator(mysql_db, mongo_db)

    render_page_header(
        title="Data Migration & Synchronization",
        subtitle="Bi-directional batch synchronization and reconciliation audit between MySQL relational core and MongoDB document catalog.",
        badge_text="DATA SYNC",
        badge_type="gold"
    )

    tab_sync, tab_audit = st.tabs(["Catalog Migration & Sync", "Reconciliation Audit"])

    with tab_sync:
        col1, col2 = st.columns(2)

        with col1:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 4px solid #C1121F; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                    <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 6px;">
                        <div style="font-size: 1.05rem; font-weight: 800; color: #111111;">MySQL → MongoDB Catalog Sync</div>
                        <span class="badge badge-red">FORWARD SYNC</span>
                    </div>
                    <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Transforms products into MongoDB documents with nested attributes and variants.</div>
                """,
                unsafe_allow_html=True
            )

            batch_size_m2m = st.number_input("Batch Size", min_value=50, max_value=2000, value=500, step=50, key="batch_m2m")

            st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
            if st.button("Execute MySQL → MongoDB Migration", type="primary", use_container_width=True):
                p_bar = st.progress(0.0)
                status_lbl = st.empty()

                def update_cb(curr, tot, msg):
                    status_lbl.text(msg)
                    if tot > 0:
                        p_bar.progress(curr / tot)

                with st.spinner("Migrating products to MongoDB catalog..."):
                    res = mysql_to_mongo.migrate_products(batch_size=int(batch_size_m2m), progress_callback=update_cb)

                if res.get("success"):
                    st.success(f"Migration completed in {format_duration(res['duration_ms'])}!")
                    st.write(f"- Source Records: `{res.get('total_source_records')}`")
                    st.write(f"- Successfully Upserted: `{res.get('processed')}`")
                    st.write(f"- Verified Catalog Count: `{res.get('destination_catalog_count')}`")
                else:
                    st.error(f"Migration encountered issues: {res.get('error')}")

            st.markdown("</div>", unsafe_allow_html=True)

        with col2:
            st.markdown(
                """
                <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 4px solid #D4AF37; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                    <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 6px;">
                        <div style="font-size: 1.05rem; font-weight: 800; color: #111111;">MongoDB → MySQL Catalog Sync</div>
                        <span class="badge badge-gold">REVERSE SYNC</span>
                    </div>
                    <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Extracts catalog documents and updates relational products and taxonomy.</div>
                """,
                unsafe_allow_html=True
            )

            batch_size_m2s = st.number_input("Batch Size", min_value=50, max_value=2000, value=500, step=50, key="batch_m2s")

            st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
            if st.button("Execute MongoDB → MySQL Migration", type="secondary", use_container_width=True):
                p_bar_m = st.progress(0.0)
                status_lbl_m = st.empty()

                def update_cb_m(curr, tot, msg):
                    status_lbl_m.text(msg)
                    if tot > 0:
                        p_bar_m.progress(curr / tot)

                with st.spinner("Syncing catalog into MySQL..."):
                    res_m = mongo_to_mysql.migrate_products(batch_size=int(batch_size_m2s), progress_callback=update_cb_m)

                if res_m.get("success"):
                    st.success(f"Sync completed in {format_duration(res_m['duration_ms'])}!")
                    st.write(f"- Source Documents: `{res_m.get('total_source_docs')}`")
                    st.write(f"- Synced Rows: `{res_m.get('processed')}`")
                else:
                    st.error(f"Sync failed: {res_m.get('error')}")

            st.markdown("</div>", unsafe_allow_html=True)

    with tab_audit:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #111111; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Reconciliation Audit Tool</div>
                <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Audits total document counts and samples attribute fields (prices, statuses) for discrepancies.</div>
            """,
            unsafe_allow_html=True
        )

        sample_audit_size = st.number_input("Audit Sample Size", min_value=20, max_value=1000, value=100, step=20)

        st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
        if st.button("Run Reconciliation Audit", type="primary", use_container_width=True):
            with st.spinner("Auditing consistency across MySQL and MongoDB..."):
                audit_res = validator.reconcile_catalog(sample_size=int(sample_audit_size))

            c1, c2, c3 = st.columns(3)
            with c1:
                render_metric_card("MySQL Products", f"{audit_res['mysql_product_count']:,}", subtext="Relational Count", variant="white_red")
            with c2:
                render_metric_card("MongoDB Documents", f"{audit_res['mongo_catalog_count']:,}", subtext="Document Count", variant="black_gold")
            with c3:
                delta = audit_res['count_delta']
                render_metric_card("Count Delta", f"{delta:,}", delta_type="gold" if delta == 0 else "negative", subtext="Discrepancy", variant="white_red_gold")

            st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)
            if audit_res["is_reconciled"]:
                st.success("STATUS: FULLY RECONCILED. Total volumes and sample fields match across both engines.")
            else:
                st.warning("STATUS: DISCREPANCIES DETECTED.")

            st.write(f"- Audited Sample Size: `{audit_res['sample_size_audited']}`")
            st.write(f"- Verified Matches: `{audit_res['sample_verified_count']}`")

            if audit_res["sample_field_mismatches"]:
                st.markdown("##### Field Discrepancies")
                st.dataframe(pd.DataFrame(audit_res["sample_field_mismatches"]), use_container_width=True)

        st.markdown("</div>", unsafe_allow_html=True)
