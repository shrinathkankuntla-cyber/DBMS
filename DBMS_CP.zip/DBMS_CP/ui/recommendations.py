import streamlit as st
import pandas as pd
import json
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from optimizer.benchmark_engine import BenchmarkEngine, LOCAL_EXP_DIR
from optimizer.recommendation_engine import RecommendationEngine
from optimizer.index_manager import IndexManager
from optimizer.cost_model import CostModel
from ui.components import render_page_header, render_status_badge, render_metric_card
from utils.helpers import format_bytes, format_duration

def render_recommendations():
    mysql_db = MySQLDatabase()
    mongo_db = MongoDBDatabase()
    recommender = RecommendationEngine()
    index_mgr = IndexManager(mysql_db, mongo_db)

    render_page_header(
        title="Index Recommendations",
        subtitle="Algorithmic evaluation of indexing strategies against workload patterns using multi-criteria cost-performance models.",
        badge_text="SYNTHESIS ENGINE",
        badge_type="gold"
    )

    # 1. Optimization Goal Selector
    st.markdown(
        """
        <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #D4AF37; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 20px;">
            <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 4px;">1. Workload Optimization Priority</div>
            <div style="font-size: 0.85rem; color: #242424; margin-bottom: 12px;">Dynamic weighting determines whether the optimizer prioritizes read query speed, write penalty minimization, or storage conservation.</div>
        """,
        unsafe_allow_html=True
    )

    priority = st.selectbox(
        "Current Workload Priority Goal",
        list(CostModel.PRIORITY_WEIGHTS.keys()),
        index=0,
        label_visibility="collapsed"
    )

    weights = CostModel.PRIORITY_WEIGHTS[priority]
    c_w1, c_w2, c_w3 = st.columns(3)
    with c_w1:
        st.caption(f"Read Acceleration Weight: **{int(weights['w_read']*100)}%**")
    with c_w2:
        st.caption(f"Write Penalty Weight: **{int(weights['w_write']*100)}%**")
    with c_w3:
        st.caption(f"Storage Footprint Weight: **{int(weights['w_storage']*100)}%**")
    st.markdown("</div>", unsafe_allow_html=True)

    # 2. Recommendations List
    files = sorted(LOCAL_EXP_DIR.glob("*.json"), reverse=True)
    if not files:
        st.info("No recorded benchmark experiments found. Execute an evaluation in the **Index Laboratory** first to produce indexing recommendations.")
        return

    # Load latest trial
    with open(files[0], "r", encoding="utf-8") as f:
        data = json.load(f)

    # Re-evaluate with active priority
    rec = recommender.generate_recommendation(
        index_name=data["candidate_configuration"],
        database=data["database"],
        workload_name=data["workload_name"],
        baseline_metrics=data["baseline"],
        candidate_metrics=data["candidate"],
        user_priority=priority
    )

    st.markdown("### 2. Evaluated Index Configuration")

    top_border_color = "#D4AF37" if "Recommended" in rec["classification"] else ("#111111" if "Conditional" in rec["classification"] else "#C1121F")

    st.markdown(
        f"""
        <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 4px solid {top_border_color}; border-radius: 8px; padding: 20px 24px; box-shadow: 0 1px 4px rgba(17,17,17,0.03); margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                <div style="font-size: 1.25rem; font-weight: 800; color: #111111;">
                    {rec['index_name'].upper()} ({rec['database']})
                </div>
                <div>
                    {render_status_badge(rec['classification'], rec['classification'])}
                </div>
            </div>
            <div style="font-size: 0.85rem; color: #242424; margin-bottom: 12px;">
                Evaluated against workload: <b>{rec['workload']}</b> | Confidence: <b>{rec['confidence']}</b>
            </div>
            <div style="font-size: 0.95rem; color: #111111; line-height: 1.5; background: #FAFAFA; border-left: 3px solid #111111; padding: 12px 16px; border-radius: 0 6px 6px 0;">
                {rec['explanation']}
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Measured Performance Evidence (Expandable)
    m = rec["measurements"]
    with st.expander("Inspect Measured Empirical Evidence", expanded=True):
        col_m1, col_m2, col_m3, col_m4 = st.columns(4)
        with col_m1:
            render_metric_card(
                "Read Acceleration",
                f"{m['candidate_read_ms']:.2f} ms",
                delta=f"{m['read_change_pct']:+.1f}%",
                delta_type="gold" if m['read_change_pct'] >= 0 else "negative",
                subtext=f"Base: {m['baseline_read_ms']:.2f} ms",
                variant="white_red"
            )
        with col_m2:
            render_metric_card(
                "Write Overhead",
                f"{m['candidate_write_ms']:.2f} ms",
                delta=f"{m['write_change_pct']:+.1f}% pen",
                delta_type="negative" if m['write_change_pct'] > 10 else "gold",
                subtext=f"Base: {m['baseline_write_ms']:.2f} ms",
                variant="black_gold"
            )
        with col_m3:
            render_metric_card(
                "Workload Duration",
                f"{m['candidate_total_ms']:.1f} ms",
                delta=f"{m['total_change_pct']:+.1f}%",
                delta_type="gold" if m['total_change_pct'] >= 0 else "negative",
                subtext=f"Base: {m['baseline_total_ms']:.1f} ms",
                variant="white_red_gold"
            )
        with col_m4:
            render_metric_card(
                "Net Utility Score",
                f"{m['net_utility_score']:+.1f}",
                delta="Utility Index",
                delta_type="gold",
                subtext="Scale: -100 to +100",
                variant="black_gold"
            )

        st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
        tdf = pd.DataFrame([
            {"Metric": "Read Latency (Median)", "Baseline": f"{m['baseline_read_ms']:.2f} ms", "Candidate": f"{m['candidate_read_ms']:.2f} ms", "Delta": f"{m['read_change_pct']:+.1f}%"},
            {"Metric": "Write Latency (Median)", "Baseline": f"{m['baseline_write_ms']:.2f} ms", "Candidate": f"{m['candidate_write_ms']:.2f} ms", "Delta": f"{m['write_change_pct']:+.1f}% penalty"},
            {"Metric": "Total Workload Time", "Baseline": f"{m['baseline_total_ms']:.2f} ms", "Candidate": f"{m['candidate_total_ms']:.2f} ms", "Delta": f"{m['total_change_pct']:+.1f}%"},
            {"Metric": "Index Storage Delta", "Baseline": "N/A", "Candidate": "N/A", "Delta": f"{m['storage_delta_bytes']:+,} Bytes"},
            {"Metric": "Composite Utility Score", "Baseline": "0.0", "Candidate": f"{m['net_utility_score']:+.1f}", "Delta": "Weighted Utility"}
        ])
        st.dataframe(tdf, use_container_width=True)

    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # 3. Apply Index Configuration Panel with Explicit Confirmation
    st.markdown(
        """
        <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #111111; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02);">
            <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">3. Production Provisioning</div>
            <div style="font-size: 0.85rem; color: #242424; margin-bottom: 12px;">Apply recommended index set to live database engine. Destruction/modification requires explicit confirmation.</div>
        """,
        unsafe_allow_html=True
    )

    indexes_to_apply = data.get("indexes_applied", [])
    st.markdown(f"**Target Database:** `{data['database']}` | **Candidate Set:** `{indexes_to_apply}`")

    col_conf1, col_conf2 = st.columns([2, 1])
    with col_conf1:
        confirm_apply = st.checkbox(f"Confirm provisioning {len(indexes_to_apply)} candidate indexes to {data['database']}.")
    with col_conf2:
        if st.button("Apply Recommended Configuration", disabled=(not confirm_apply), type="primary", use_container_width=True):
            with st.spinner(f"Provisioning indexes on {data['database']}..."):
                res = index_mgr.apply_configuration(data["database"], data["candidate_configuration"])
            if res.get("success"):
                st.success(f"Successfully provisioned configuration '{data['candidate_configuration']}' on {data['database']}!")
            else:
                st.error(f"Failed to apply: {res.get('error')}")

    st.markdown("</div>", unsafe_allow_html=True)
