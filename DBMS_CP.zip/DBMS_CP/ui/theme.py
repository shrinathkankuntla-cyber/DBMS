import streamlit as st

THEME_COLORS = {
    "primary_red": "#C1121F",
    "deep_red": "#8F0D18",
    "pure_black": "#111111",
    "soft_black": "#242424",
    "rich_gold": "#C9A227",
    "metallic_gold": "#D4AF37",
    "light_gold": "#F5E7B2",
    "main_bg": "#FFFFFF",
    "sec_bg": "#FAFAFA",
    "border_color": "#D9D9D9"
}

THEME_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600;700&family=Inter:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap');

:root {
    --primary-red: #C1121F;
    --deep-red: #8F0D18;
    --pure-black: #111111;
    --soft-black: #242424;
    --rich-gold: #C9A227;
    --metallic-gold: #D4AF37;
    --light-gold: #F5E7B2;
    --main-bg: #FFFFFF;
    --sec-bg: #FAFAFA;
    --border-color: #D9D9D9;
}

/* Global Application Reset & Background */
.stApp {
    background-color: var(--main-bg) !important;
    color: var(--pure-black) !important;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif !important;
}

/* Typography Overrides */
h1, h2, h3, h4, h5, h6 {
    font-family: 'Manrope', 'Inter', sans-serif !important;
    color: var(--pure-black) !important;
    font-weight: 800 !important;
    letter-spacing: -0.025em !important;
}

p, span, label, div {
    font-family: 'Inter', sans-serif;
}

/* Numeric Mono Classes */
.mono-num {
    font-family: 'IBM Plex Mono', monospace !important;
    font-weight: 600;
}

/* Top App Header / Navigation Bar */
header[data-testid="stHeader"] {
    background-color: rgba(255, 255, 255, 0.95) !important;
    backdrop-filter: blur(8px) !important;
    border-bottom: 1px solid var(--border-color) !important;
}

/* Sidebar Custom Styling - Pure White Background & Black Typography */
section[data-testid="stSidebar"] {
    background-color: var(--main-bg) !important;
    border-right: 1px solid var(--border-color) !important;
    box-shadow: 1px 0 6px rgba(17, 17, 17, 0.04) !important;
    padding-top: 1.2rem !important;
}

section[data-testid="stSidebar"] div.stRadio > div[role="radiogroup"] > label {
    background: transparent !important;
    padding: 8px 14px !important;
    border-radius: 6px !important;
    margin-bottom: 3px !important;
    border-left: 3px solid transparent !important;
    transition: all 0.16s ease-in-out !important;
    color: var(--soft-black) !important;
    font-weight: 500 !important;
    font-size: 0.92rem !important;
}

section[data-testid="stSidebar"] div.stRadio > div[role="radiogroup"] > label:hover {
    background-color: var(--sec-bg) !important;
    color: var(--pure-black) !important;
}

section[data-testid="stSidebar"] div.stRadio > div[role="radiogroup"] > label[data-checked="true"],
section[data-testid="stSidebar"] div.stRadio > div[role="radiogroup"] > label:has(input:checked) {
    background-color: #FFF8F8 !important;
    border-left: 4px solid var(--primary-red) !important;
    border-right: 3px solid var(--metallic-gold) !important;
    color: var(--primary-red) !important;
    font-weight: 700 !important;
}

/* Segmented Database Selectors (Horizontal Radio on Main Canvas) */
div[data-testid="stHorizontalBlock"] div.stRadio > div[role="radiogroup"] {
    background-color: var(--sec-bg);
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 4px;
}

div[data-testid="stHorizontalBlock"] div.stRadio > div[role="radiogroup"] > label {
    border-radius: 6px;
    padding: 6px 16px;
    font-weight: 700;
    font-size: 0.9rem;
    color: var(--soft-black);
    transition: all 0.15s ease;
}

div[data-testid="stHorizontalBlock"] div.stRadio > div[role="radiogroup"] > label:has(input:checked) {
    background-color: var(--primary-red) !important;
    color: #FFFFFF !important;
}

/* Streamlit Standard Metric Containers */
div[data-testid="metric-container"] {
    background-color: var(--main-bg) !important;
    border: 1px solid var(--border-color) !important;
    border-radius: 8px !important;
    padding: 16px 20px !important;
}

div[data-testid="metric-container"] label[data-testid="stMetricLabel"] {
    font-size: 0.8rem !important;
    color: var(--soft-black) !important;
    font-weight: 700 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.05em !important;
}

div[data-testid="metric-container"] div[data-testid="stMetricValue"] {
    font-family: 'IBM Plex Mono', monospace !important;
    font-size: 1.75rem !important;
    font-weight: 700 !important;
    color: var(--pure-black) !important;
}

/* Buttons */
.stButton > button {
    border-radius: 6px !important;
    font-family: 'Inter', sans-serif !important;
    font-weight: 600 !important;
    font-size: 0.9rem !important;
    padding: 0.45rem 1.15rem !important;
    transition: all 0.15s ease-in-out !important;
    border: 1.5px solid var(--pure-black) !important;
    background-color: var(--main-bg) !important;
    color: var(--pure-black) !important;
}

.stButton > button:hover {
    border-color: var(--soft-black) !important;
    background-color: var(--sec-bg) !important;
    color: var(--pure-black) !important;
}

/* Primary Action Buttons: Red Background, White Text */
.stButton > button[kind="primary"],
div.stButton > button[data-testid="baseButton-primary"] {
    background-color: var(--primary-red) !important;
    color: #FFFFFF !important;
    border: 1px solid var(--primary-red) !important;
    box-shadow: 0 2px 4px rgba(193, 18, 31, 0.25) !important;
}

.stButton > button[kind="primary"]:hover,
div.stButton > button[data-testid="baseButton-primary"]:hover {
    background-color: var(--deep-red) !important;
    border-color: var(--deep-red) !important;
    color: #FFFFFF !important;
    box-shadow: 0 4px 8px rgba(143, 13, 24, 0.3) !important;
}

/* Secondary Buttons: Black Background, White Text */
.stButton > button[kind="secondary"],
div.stButton > button[data-testid="baseButton-secondary"] {
    background-color: var(--pure-black) !important;
    color: #FFFFFF !important;
    border: 1px solid var(--pure-black) !important;
}

.stButton > button[kind="secondary"]:hover,
div.stButton > button[data-testid="baseButton-secondary"]:hover {
    background-color: var(--soft-black) !important;
    border-color: var(--soft-black) !important;
    color: #FFFFFF !important;
}

/* Form Submit Buttons */
div[data-testid="stFormSubmitButton"] > button {
    background-color: var(--primary-red) !important;
    color: #FFFFFF !important;
    border: 1px solid var(--primary-red) !important;
}

div[data-testid="stFormSubmitButton"] > button:hover {
    background-color: var(--deep-red) !important;
    border-color: var(--deep-red) !important;
    color: #FFFFFF !important;
}

/* Download Buttons */
div[data-testid="stDownloadButton"] > button {
    background-color: var(--pure-black) !important;
    color: #FFFFFF !important;
    border: 1px solid var(--pure-black) !important;
}

div[data-testid="stDownloadButton"] > button:hover {
    background-color: var(--soft-black) !important;
    border-color: var(--soft-black) !important;
    color: #FFFFFF !important;
}

/* Inputs & Form Controls */
div[data-baseweb="input"],
div[data-baseweb="select"] > div,
div[data-baseweb="textarea"] {
    background-color: var(--main-bg) !important;
    border-color: var(--border-color) !important;
    border-radius: 6px !important;
    color: var(--pure-black) !important;
}

div[data-baseweb="input"]:focus-within,
div[data-baseweb="select"]:focus-within > div,
div[data-baseweb="textarea"]:focus-within {
    border-color: var(--primary-red) !important;
    box-shadow: 0 0 0 1px var(--primary-red) !important;
}

/* Code Editors / Dark Terminal Panel */
.dark-editor-pane {
    background-color: var(--pure-black) !important;
    color: #FFFFFF !important;
    border-radius: 8px;
    padding: 16px;
    font-family: 'IBM Plex Mono', monospace !important;
    border: 1px solid var(--soft-black);
}

.dark-editor-pane textarea {
    background-color: var(--pure-black) !important;
    color: #FFFFFF !important;
    font-family: 'IBM Plex Mono', monospace !important;
    caret-color: var(--metallic-gold) !important;
}

/* Tabs */
div[data-baseweb="tab-list"] {
    background-color: transparent !important;
    border-bottom: 2px solid var(--border-color) !important;
    gap: 8px !important;
}

div[data-baseweb="tab"] {
    font-family: 'Inter', sans-serif !important;
    font-weight: 600 !important;
    font-size: 0.92rem !important;
    color: var(--soft-black) !important;
    padding: 10px 16px !important;
    border-radius: 6px 6px 0 0 !important;
    border: none !important;
}

div[data-baseweb="tab"]:hover {
    color: var(--primary-red) !important;
}

div[data-baseweb="tab"][aria-selected="true"] {
    color: var(--primary-red) !important;
    border-bottom: 3px solid var(--primary-red) !important;
    background-color: transparent !important;
    font-weight: 700 !important;
}

/* Dataframe & Tables */
div[data-testid="stDataFrame"] {
    background-color: var(--main-bg) !important;
    border: 1px solid var(--border-color) !important;
    border-radius: 8px !important;
    overflow: hidden !important;
}

/* Expanders */
div[data-testid="stExpander"] {
    background-color: var(--main-bg) !important;
    border: 1px solid var(--border-color) !important;
    border-radius: 8px !important;
    margin-bottom: 10px !important;
}

div[data-testid="stExpander"] summary {
    font-weight: 700 !important;
    color: var(--pure-black) !important;
    padding: 10px 16px !important;
}

/* Progress Bar */
div[data-testid="stProgress"] > div > div > div > div {
    background-color: var(--primary-red) !important;
}

/* Status Badges - Red, Black, Gold Only */
.badge {
    display: inline-block;
    padding: 3px 10px;
    font-size: 0.78rem;
    font-weight: 700;
    border-radius: 12px;
    letter-spacing: 0.04em;
    text-transform: uppercase;
}

/* Gold / Recommended */
.badge-gold,
.badge-recommended {
    background-color: var(--light-gold);
    color: var(--pure-black);
    border: 1.5px solid var(--metallic-gold);
}

/* Black / Conditional / Neutral */
.badge-black,
.badge-conditional {
    background-color: var(--pure-black);
    color: #FFFFFF;
    border: 1px solid var(--soft-black);
}

/* Red / Rejected / Error */
.badge-red,
.badge-rejected {
    background-color: #FFF2F2;
    color: var(--primary-red);
    border: 1.5px solid var(--primary-red);
}

.badge-neutral {
    background-color: var(--sec-bg);
    color: var(--pure-black);
    border: 1px solid var(--border-color);
}

.badge-outline-red {
    background-color: var(--main-bg);
    color: var(--primary-red);
    border: 1.5px solid var(--primary-red);
}

.badge-outline-gold {
    background-color: var(--main-bg);
    color: var(--rich-gold);
    border: 1.5px solid var(--metallic-gold);
}

.badge-outline-black {
    background-color: var(--main-bg);
    color: var(--pure-black);
    border: 1.5px solid var(--pure-black);
}

/* Subtle Custom Scrollbar */
::-webkit-scrollbar {
    width: 6px;
    height: 6px;
}
::-webkit-scrollbar-track {
    background: var(--main-bg);
}
::-webkit-scrollbar-thumb {
    background: var(--border-color);
    border-radius: 3px;
}
::-webkit-scrollbar-thumb:hover {
    background: #BFBFBF;
}
</style>
"""

def inject_theme():
    """Injects the strict Red, Black & Gold light theme CSS into the Streamlit session."""
    st.markdown(THEME_CSS, unsafe_allow_html=True)
