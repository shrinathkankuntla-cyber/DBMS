import streamlit as st
import pandas as pd
from database.mysql_connection import MySQLDatabase
from optimizer.benchmark_engine import BenchmarkEngine
from ui.components import render_page_header
from utils.helpers import format_duration

def render_experiment_history():
    mysql_db = MySQLDatabase()
    experiments = BenchmarkEngine.list_experiments(mysql_db)

    render_page_header(
        title="Experiment History & Benchmark Archive",
        subtitle="Searchable archive of historical benchmark trials, comparative analysis, and CSV audit reporting.",
        badge_text="AUDIT TRAIL",
        badge_type="black"
    )

    if not experiments:
        st.info("No benchmark experiments logged yet. Execute trials in the **Index Laboratory** to build an audit history.")
        return

    df = pd.DataFrame(experiments)

    # Filter Controls Card
    st.markdown(
        """
        <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #111111; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 20px;">
            <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Filter Historical Runs</div>
            <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Query by target engine or recommendation classification.</div>
        """,
        unsafe_allow_html=True
    )

    col_f1, col_f2 = st.columns(2)
    with col_f1:
        db_filter = st.multiselect(
            "Target Database Engine",
            options=list(df["database_type"].unique()),
            default=list(df["database_type"].unique())
        )
    with col_f2:
        class_options = [c for c in df["classification"].dropna().unique()]
        class_filter = st.multiselect(
            "Recommendation Classification",
            options=class_options,
            default=class_options
        )
    st.markdown("</div>", unsafe_allow_html=True)

    filtered_df = df[df["database_type"].isin(db_filter)]
    if class_filter:
        filtered_df = filtered_df[filtered_df["classification"].isin(class_filter)]

    st.markdown(f"#### Logged Experiments ({len(filtered_df)} matches)")
    st.dataframe(filtered_df, use_container_width=True)

    # CSV Export Button (Primary Red)
    csv_data = filtered_df.to_csv(index=False).encode("utf-8")
    st.download_button(
        label="Download Benchmark History as CSV",
        data=csv_data,
        file_name="benchmark_experiments_report.csv",
        mime="text/csv",
        type="primary"
    )

    st.markdown("<div style='height: 24px;'></div>", unsafe_allow_html=True)

    # Side-by-Side Comparison
    if len(filtered_df) >= 2:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #D4AF37; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 3px rgba(17,17,17,0.02); margin-bottom: 16px;">
                <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 2px;">Side-by-Side Trial Comparison</div>
                <div style="font-size: 0.82rem; color: #242424; margin-bottom: 12px;">Compare performance metrics between two distinct experiment runs.</div>
            </div>
            """,
            unsafe_allow_html=True
        )

        comp_col1, comp_col2 = st.columns(2)
        exp_list = filtered_df["experiment_id"].tolist()

        with comp_col1:
            exp_a_id = st.selectbox("Experiment A", exp_list, index=0)
            exp_a = filtered_df[filtered_df["experiment_id"] == exp_a_id].iloc[0].to_dict()
            st.json(exp_a)

        with comp_col2:
            exp_b_id = st.selectbox("Experiment B", exp_list, index=min(1, len(exp_list)-1))
            exp_b = filtered_df[filtered_df["experiment_id"] == exp_b_id].iloc[0].to_dict()
            st.json(exp_b)
