import streamlit as st
import pandas as pd
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from optimizer.index_candidates import (
    MYSQL_CANDIDATE_INDEXES,
    MONGO_CANDIDATE_INDEXES,
    EXPERIMENT_CONFIGURATIONS
)
from optimizer.index_manager import IndexManager
from optimizer.benchmark_engine import BenchmarkEngine
from optimizer.explain_analyzer import ExplainAnalyzer
from workloads.workload_generator import WORKLOAD_MIX_PRESETS
from ui.components import render_page_header, render_status_badge
from utils.helpers import format_bytes, format_duration

def render_index_laboratory():
    mysql_db = MySQLDatabase()
    mongo_db = MongoDBDatabase()
    index_mgr = IndexManager(mysql_db, mongo_db)
    benchmark_engine = BenchmarkEngine(mysql_db, mongo_db)
    explain_analyzer = ExplainAnalyzer(mysql_db, mongo_db)

    render_page_header(
        title="Index Laboratory",
        subtitle="Evaluate how indexing decisions affect performance, write overhead, and storage consumption.",
        badge_text="SIGNATURE LAB",
        badge_type="red"
    )

    # Section A — Database Selector with Red active state
    st.markdown(
        """
        <div style="font-size: 0.75rem; font-weight: 800; color: #111111; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 6px;">
            Target Database System
        </div>
        """,
        unsafe_allow_html=True
    )
    col_sel1, col_sel2 = st.columns([1, 3])
    with col_sel1:
        target_db = st.radio(
            "Database Engine",
            ["MongoDB", "MySQL"],
            index=0,
            horizontal=True,
            label_visibility="collapsed",
            key="lab_active_db"
        )

    tab_benchmark, tab_builder, tab_existing, tab_plans = st.tabs([
        "Experiment Comparison",
        "Candidate Index Builder",
        "Existing Index Catalog",
        "Execution Plan Inspector"
    ])

    # --- TAB 1: EXPERIMENT COMPARISON ---
    with tab_benchmark:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #C1121F; border-radius: 8px; padding: 18px 22px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(17,17,17,0.02);">
                <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 4px;">Run Baseline vs. Candidate Benchmark</div>
                <div style="font-size: 0.85rem; color: #242424;">Executes identical workload operations against unindexed baseline and candidate configuration, calculating exact performance and write deltas.</div>
            </div>
            """,
            unsafe_allow_html=True
        )

        col_ctrl, col_actions = st.columns([2, 1])
        with col_ctrl:
            avail_configs = [c for c in EXPERIMENT_CONFIGURATIONS.get(target_db, {}).keys() if c != "Baseline"]
            candidate_cfg = st.selectbox("Candidate Configuration to Benchmark", avail_configs, index=0)

            mix_name = st.selectbox("Workload Distribution Mix", list(WORKLOAD_MIX_PRESETS.keys()), index=0)
            read_ratio, write_ratio = WORKLOAD_MIX_PRESETS[mix_name]

            priority = st.selectbox(
                "Workload Optimization Priority Goal",
                ["Balance reads and writes", "Prioritize reads", "Prioritize writes", "Minimize storage"],
                index=0
            )

        with col_actions:
            ops_num = st.number_input("Operations per Run", min_value=10, max_value=2000, value=40, step=10)
            warmup_num = st.number_input("Warm-up Runs", min_value=0, max_value=50, value=5, step=5)
            
            st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
            btn_run_bench = st.button("Run Full Benchmark Comparison", type="primary", use_container_width=True)

        if btn_run_bench:
            p_bar = st.progress(0.0)
            status_text = st.empty()

            def bench_progress_cb(msg, frac):
                status_text.text(msg)
                p_bar.progress(frac)

            try:
                with st.spinner(f"Evaluating '{candidate_cfg}' against Baseline on {target_db}..."):
                    res = benchmark_engine.run_configuration_benchmark(
                        database_type=target_db,
                        workload_mix_name=mix_name,
                        read_ratio=read_ratio,
                        candidate_config_name=candidate_cfg,
                        operation_count=int(ops_num),
                        warmup_count=int(warmup_num),
                        user_priority=priority,
                        progress_callback=bench_progress_cb
                    )
                st.session_state["active_benchmark_result"] = res
                st.success("Benchmark completed! Results recorded.")
            except Exception as e:
                st.error(f"Benchmark run failed: {e}")

        # Section D: Two Visually Distinct Comparison Panels (Baseline vs Candidate)
        if "active_benchmark_result" in st.session_state:
            res = st.session_state["active_benchmark_result"]
            rec = res["recommendation"]
            tradeoffs = rec["tradeoffs"]

            base_st = res["baseline"]
            cand_st = res["candidate"]

            read_imp = tradeoffs["read"]["improvement_pct"]
            write_pen = tradeoffs["write"]["penalty_pct"]
            dur_imp = tradeoffs["total_duration"]["improvement_pct"]
            storage_growth = tradeoffs["storage"]["growth_pct"]
            net_util = tradeoffs["net_utility"]

            st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)
            st.markdown(
                f"""
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                    <div>
                        <span style="font-size: 0.82rem; font-weight: 800; color: #242424; text-transform: uppercase;">Experiment Trial:</span>
                        <span style="font-family: 'IBM Plex Mono', monospace; font-size: 1.05rem; font-weight: 700; color: #111111; margin-left: 6px;">{res['experiment_id']}</span>
                    </div>
                    <div>
                        {render_status_badge(rec['classification'], rec['classification'])}
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

            col_base, col_cand = st.columns(2)

            with col_base:
                st.markdown(
                    """
                    <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 4px solid #111111; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 4px rgba(17,17,17,0.03);">
                        <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 14px;">
                            <div style="font-size: 1.1rem; font-weight: 800; color: #111111;">BASELINE CONFIGURATION</div>
                            <span class="badge badge-black">UNINDEXED / PK ONLY</span>
                        </div>
                    """,
                    unsafe_allow_html=True
                )

                st.markdown(f"<span style='color:#111111; font-weight:700;'>Median Latency:</span> `{tradeoffs['read']['baseline_median_ms']:.2f} ms`", unsafe_allow_html=True)
                st.markdown(f"<span style='color:#111111; font-weight:700;'>P95 Tail Latency:</span> `{base_st.get('total_latency_stats', {}).get('p95_ms', 0):.2f} ms`", unsafe_allow_html=True)
                st.markdown(f"<span style='color:#111111; font-weight:700;'>Write Latency (Median):</span> `{tradeoffs['write']['baseline_median_ms']:.2f} ms`", unsafe_allow_html=True)
                st.markdown(f"<span style='color:#111111; font-weight:700;'>Index Storage Size:</span> `{format_bytes(tradeoffs['storage']['baseline_bytes'])}`", unsafe_allow_html=True)
                st.markdown(f"<span style='color:#111111; font-weight:700;'>Total Workload Duration:</span> `{format_duration(tradeoffs['total_duration']['baseline_ms'])}`", unsafe_allow_html=True)
                st.markdown("</div>", unsafe_allow_html=True)

            with col_cand:
                # Gold for performance improvement, Red for regressions/penalties
                read_color = "#D4AF37" if read_imp >= 0 else "#C1121F"
                write_color = "#C1121F" if write_pen > 10 else ("#D4AF37" if write_pen <= 0 else "#C9A227")
                dur_color = "#D4AF37" if dur_imp >= 0 else "#C1121F"

                st.markdown(
                    f"""
                    <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 4px solid #C1121F; border-radius: 8px; padding: 18px 22px; box-shadow: 0 1px 4px rgba(17,17,17,0.03);">
                        <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 14px;">
                            <div style="font-size: 1.1rem; font-weight: 800; color: #C1121F;">CANDIDATE: {res['candidate_configuration'].upper()}</div>
                            <span class="badge badge-gold">EVALUATED</span>
                        </div>
                    """,
                    unsafe_allow_html=True
                )

                st.markdown(f"<span style='color:#C1121F; font-weight:700;'>Median Latency:</span> `{tradeoffs['read']['candidate_median_ms']:.2f} ms` <span style='color:{read_color}; font-weight:800;'>({read_imp:+.1f}%)</span>", unsafe_allow_html=True)
                st.markdown(f"<span style='color:#C1121F; font-weight:700;'>P95 Tail Latency:</span> `{cand_st.get('total_latency_stats', {}).get('p95_ms', 0):.2f} ms`", unsafe_allow_html=True)
                st.markdown(f"<span style='color:#C1121F; font-weight:700;'>Write Latency (Median):</span> `{tradeoffs['write']['candidate_median_ms']:.2f} ms` <span style='color:{write_color}; font-weight:800;'>({write_pen:+.1f}% penalty)</span>", unsafe_allow_html=True)
                st.markdown(f"<span style='color:#C1121F; font-weight:700;'>Index Storage Size:</span> `{format_bytes(tradeoffs['storage']['candidate_bytes'])}` <span style='color:#242424;'>({storage_growth:+.1f}%)</span>", unsafe_allow_html=True)
                st.markdown(f"<span style='color:#C1121F; font-weight:700;'>Total Workload Duration:</span> `{format_duration(tradeoffs['total_duration']['candidate_ms'])}` <span style='color:{dur_color}; font-weight:800;'>({dur_imp:+.1f}%)</span>", unsafe_allow_html=True)
                st.markdown("</div>", unsafe_allow_html=True)

            # Gold Trade-Off Summary Highlight
            st.markdown(
                f"""
                <div style="background: #F5E7B2; border: 1.5px solid #D4AF37; border-left: 5px solid #C9A227; border-radius: 8px; padding: 14px 18px; margin-top: 16px;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 0.85rem; font-weight: 800; color: #111111; text-transform: uppercase; letter-spacing: 0.05em;">Net Workload Trade-Off Utility: <span style="color:#C1121F; font-family:'IBM Plex Mono', monospace;">{net_util:+.1f}</span></span>
                        <span style="font-size: 0.8rem; font-weight: 700; color: #242424;">Priority: {priority}</span>
                    </div>
                    <div style="font-size: 0.92rem; color: #111111; margin-top: 6px; line-height: 1.45; font-weight: 500;">
                        {rec['explanation']}
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

    # --- TAB 2: CANDIDATE INDEX BUILDER ---
    with tab_builder:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1px solid #D9D9D9; border-top: 3px solid #D4AF37; border-radius: 8px; padding: 18px 22px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(17,17,17,0.02);">
                <div style="font-size: 1.05rem; font-weight: 800; color: #111111; margin-bottom: 4px;">Candidate Index Builder</div>
                <div style="font-size: 0.85rem; color: #242424;">Construct, preview DDL syntax, and provision single-field or compound indexes on the live database.</div>
            </div>
            """,
            unsafe_allow_html=True
        )

        col_b1, col_b2 = st.columns(2)
        if target_db == "MySQL":
            with col_b1:
                idx_choice = st.selectbox("Select Candidate Index Specification", list(MYSQL_CANDIDATE_INDEXES.keys()))
                candidate_obj = MYSQL_CANDIDATE_INDEXES[idx_choice]

                fields_str = ", ".join(f"`{c}`" for c in candidate_obj.fields)
                ddl_preview = f"CREATE INDEX `{candidate_obj.name}` ON `{candidate_obj.target}` ({fields_str});"

                st.markdown("##### DDL Preview")
                st.code(ddl_preview, language="sql")
                st.caption(f"Role: {candidate_obj.description}")

            with col_b2:
                st.markdown("##### Execution Actions")
                if st.button("Apply Candidate Index to MySQL", type="primary", use_container_width=True):
                    with st.spinner(f"Creating {candidate_obj.name}..."):
                        c_res = index_mgr.create_mysql_index(candidate_obj.name)
                    if c_res.get("success"):
                        st.success(f"Index created in {c_res.get('creation_time_ms', 0):.2f} ms")
                    else:
                        st.error(f"Creation failed: {c_res.get('error')}")

                if st.button("Reset MySQL to Baseline (Drop Candidate Indexes)", type="secondary", use_container_width=True):
                    with st.spinner("Dropping candidate indexes..."):
                        r_res = index_mgr.reset_mysql_to_baseline()
                    st.success(f"Candidate indexes dropped. Primary/Foreign Keys preserved.")
        else: # MongoDB
            with col_b1:
                idx_choice = st.selectbox("Select Candidate Index Specification", list(MONGO_CANDIDATE_INDEXES.keys()))
                candidate_obj = MONGO_CANDIDATE_INDEXES[idx_choice]

                mongo_preview = f"db.{candidate_obj.target}.createIndex({dict(candidate_obj.fields)}, {{ name: '{candidate_obj.name}' }})"
                st.markdown("##### MongoDB Command Preview")
                st.code(mongo_preview, language="javascript")
                st.caption(f"Role: {candidate_obj.description}")

            with col_b2:
                st.markdown("##### Execution Actions")
                if st.button("Apply Candidate Index to MongoDB", type="primary", use_container_width=True):
                    with st.spinner(f"Creating {candidate_obj.name}..."):
                        c_res = index_mgr.create_mongo_index(candidate_obj.name)
                    if c_res.get("success"):
                        st.success(f"Index created in {c_res.get('creation_time_ms', 0):.2f} ms")
                    else:
                        st.error(f"Creation failed: {c_res.get('error')}")

                if st.button("Reset MongoDB to Baseline (Drop Candidate Indexes)", type="secondary", use_container_width=True):
                    with st.spinner("Dropping candidate indexes..."):
                        r_res = index_mgr.reset_mongo_to_baseline()
                    st.success(f"Candidate indexes dropped. Mandatory identity index on product_id preserved.")

    # --- TAB 3: EXISTING INDEX CATALOG ---
    with tab_existing:
        st.subheader(f"Existing {target_db} Index Catalog")
        if target_db == "MySQL":
            tbl_choice = st.selectbox("Inspect Table Indexes", ["products", "orders", "order_items", "inventory", "customers", "cart_items"])
            idx_list = index_mgr.list_mysql_indexes(tbl_choice)
            if idx_list:
                st.dataframe(pd.DataFrame(idx_list), use_container_width=True)
            else:
                st.info(f"No custom indexes or MySQL offline for table `{tbl_choice}`.")
        else:
            coll_indexes = index_mgr.list_mongo_indexes("product_catalog")
            idx_rows = []
            for k, v in coll_indexes.items():
                idx_rows.append({
                    "Index Name": k,
                    "Key Pattern": str(v.get("key")),
                    "Unique": v.get("unique", False),
                    "Protected": k in ["_id_", "idx_identity_product_id", "product_id_1"]
                })
            st.dataframe(pd.DataFrame(idx_rows), use_container_width=True)

    # --- TAB 4: EXECUTION PLAN INSPECTOR ---
    with tab_plans:
        st.subheader("Query Optimizer Execution Plan Analysis")
        if target_db == "MySQL":
            query_sql = st.text_area(
                "SQL Query for Execution Plan",
                value="SELECT * FROM products WHERE category_id = 3 AND price BETWEEN 50.00 AND 250.00 ORDER BY price ASC LIMIT 50;",
                height=100
            )
            if st.button("Inspect MySQL Plan (EXPLAIN ANALYZE)", type="primary"):
                with st.spinner("Analyzing plan..."):
                    plan = explain_analyzer.explain_mysql_query(query_sql)
                if plan.get("success"):
                    s = plan["summary"]
                    col_p1, col_p2, col_p3 = st.columns(3)
                    col_p1.metric("Table Scan (ALL)", str(s["is_table_scan"]))
                    col_p2.metric("Index Used", ", ".join(s["indexes_used"]))
                    col_p3.metric("Rows Examined", f"{s['total_rows_examined']:,}")

                    st.markdown("##### Plan Tree Nodes")
                    st.dataframe(pd.DataFrame(plan["explain_rows"]), use_container_width=True)

                    if plan.get("explain_analyze_raw"):
                        st.markdown("##### Raw EXPLAIN ANALYZE Output")
                        st.code(plan["explain_analyze_raw"], language="text")
                else:
                    st.error(f"Plan analysis failed: {plan.get('error')}")
        else:
            cat_filter = st.text_input("MongoDB Filter: category", value="Smartphones & Tablets")
            min_pr = st.number_input("MongoDB Filter: min price", value=100.0)
            max_pr = st.number_input("MongoDB Filter: max price", value=800.0)

            if st.button("Inspect MongoDB executionStats", type="primary"):
                f_doc = {"category": cat_filter, "price": {"$gte": min_pr, "$lte": max_pr}}
                with st.spinner("Retrieving executionStats..."):
                    plan = explain_analyzer.explain_mongo_query("product_catalog", filter_doc=f_doc, sort_doc=[("price", 1)], limit=50)

                if plan.get("success"):
                    col_mp1, col_mp2, col_mp3 = st.columns(3)
                    col_mp1.metric("Collection Scan (COLLSCAN)", str(plan["is_collection_scan"]))
                    col_mp2.metric("Index Utilized", ", ".join(plan["indexes_used"]))
                    col_mp3.metric("Execution Time", f"{plan['execution_time_ms']} ms")

                    st.markdown(f"**Execution Stages:** `{' -> '.join(plan['stages'])}`")
                    st.markdown(f"**Docs Examined:** `{plan['docs_examined']}` | **Keys Examined:** `{plan['keys_examined']}` | **Docs Returned:** `{plan['n_returned']}`")
                else:
                    st.error(f"Plan inspection failed: {plan.get('error')}")
