from typing import Optional, Dict, Any, List
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from utils.logger import get_logger

logger = get_logger("migration_validation")

class MigrationValidator:
    """
    Reconciles product data between MySQL and MongoDB to detect missing records,
    price discrepancies, status mismatches, or orphan records.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None, mongo_db: Optional[MongoDBDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()
        self.mongo = mongo_db or MongoDBDatabase()

    def reconcile_catalog(self, sample_size: int = 200) -> Dict[str, Any]:
        """
        Executes an authoritative reconciliation check between MySQL and MongoDB.
        """
        coll = self.mongo.get_collection("product_catalog")

        # 1. Total Counts
        success, rows, err = self.mysql.execute_query("SELECT COUNT(*) AS total FROM products", fetch=True)
        mysql_count = rows[0]["total"] if success and rows else 0
        mongo_count = coll.estimated_document_count()

        # 2. Check Sample Records for Field Inconsistencies
        sql_sample = """
            SELECT p.product_id, p.product_name, p.price, p.status, c.category_name
            FROM products p
            JOIN categories c ON p.category_id = c.category_id
            ORDER BY p.product_id ASC
            LIMIT %s
        """
        success, sample_rows, _ = self.mysql.execute_query(sql_sample, (sample_size,), fetch=True)

        mismatches = []
        missing_in_mongo = []
        verified_count = 0

        if success and sample_rows:
            p_ids = [r["product_id"] for r in sample_rows]
            docs = list(coll.find({"product_id": {"$in": p_ids}}))
            doc_map = {d["product_id"]: d for d in docs}

            for row in sample_rows:
                p_id = row["product_id"]
                if p_id not in doc_map:
                    missing_in_mongo.append(p_id)
                    continue

                d = doc_map[p_id]
                # Compare price (within 1 cent float tolerance)
                price_diff = abs(float(row["price"]) - float(d.get("price", 0.0)))
                status_match = str(row["status"]).strip() == str(d.get("status", "")).strip()

                if price_diff > 0.01:
                    mismatches.append({
                        "product_id": p_id,
                        "field": "price",
                        "mysql_value": float(row["price"]),
                        "mongo_value": float(d.get("price", 0.0))
                    })
                elif not status_match:
                    mismatches.append({
                        "product_id": p_id,
                        "field": "status",
                        "mysql_value": row["status"],
                        "mongo_value": d.get("status")
                    })
                else:
                    verified_count += 1

        is_reconciled = (mysql_count == mongo_count) and (len(mismatches) == 0) and (len(missing_in_mongo) == 0)

        return {
            "is_reconciled": is_reconciled,
            "mysql_product_count": mysql_count,
            "mongo_catalog_count": mongo_count,
            "count_delta": mysql_count - mongo_count,
            "sample_size_audited": len(sample_rows) if success and sample_rows else 0,
            "sample_verified_count": verified_count,
            "sample_missing_in_mongo": missing_in_mongo,
            "sample_field_mismatches": mismatches
        }
