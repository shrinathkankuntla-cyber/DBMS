from typing import Dict, Any, List
import datetime

def mysql_product_to_mongodb_doc(
    product_row: Dict[str, Any],
    category_name: str,
    attributes: Dict[str, Any] = None,
    variants: List[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Transforms a MySQL product record + category into a MongoDB catalog document.
    """
    price_val = float(product_row.get("price") or 0.0)
    created_at = product_row.get("created_at")
    if isinstance(created_at, datetime.date) and not isinstance(created_at, datetime.datetime):
        created_at = datetime.datetime.combine(created_at, datetime.time.min)

    attrs = attributes or {
        "color": "Standard",
        "material": "General",
        "rating": 4.5,
        "warranty_months": 12
    }

    p_id = int(product_row["product_id"])
    vars_list = variants or [
        {"sku": f"SKU-{p_id}-DEFAULT", "size": "Standard", "color": attrs.get("color", "Standard"), "additional_price": 0.0}
    ]

    return {
        "product_id": p_id,
        "product_name": str(product_row.get("product_name") or ""),
        "category": category_name,
        "price": price_val,
        "brand": "CatalogBrand",
        "attributes": attrs,
        "variants": vars_list,
        "status": str(product_row.get("status") or "active"),
        "created_at": created_at or datetime.datetime.now()
    }

def mongodb_doc_to_mysql_product(doc: Dict[str, Any]) -> Dict[str, Any]:
    """
    Transforms a MongoDB catalog document into a MySQL product row representation.
    """
    return {
        "product_id": int(doc["product_id"]),
        "product_name": str(doc.get("product_name", "")),
        "category_name": str(doc.get("category", "General")),
        "price": float(doc.get("price", 0.0)),
        "status": str(doc.get("status", "active")),
        "created_at": doc.get("created_at")
    }
