from typing import Optional, Dict, Any, Callable
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from migration.field_mapping import mongodb_doc_to_mysql_product
from utils.helpers import Timer
from utils.logger import get_logger

logger = get_logger("mongodb_to_mysql")

class MongoDBToMySQLMigrator:
    """
    Synchronizes catalog products from MongoDB back to MySQL, ensuring category
    normalization and transactional integrity.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None, mongo_db: Optional[MongoDBDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()
        self.mongo = mongo_db or MongoDBDatabase()

    def migrate_products(
        self,
        batch_size: int = 500,
        progress_callback: Optional[Callable[[int, int, str], None]] = None
    ) -> Dict[str, Any]:
        coll = self.mongo.get_collection("product_catalog")
        total_docs = coll.estimated_document_count()

        if total_docs == 0:
            return {"success": True, "processed": 0, "total_source_docs": 0, "duration_ms": 0.0, "message": "No documents in MongoDB catalog."}

        conn = self.mysql.get_raw_connection(include_db=True)
        cursor = conn.cursor(dictionary=True)

        processed = 0
        failed = 0

        with Timer() as timer:
            try:
                # Cache categories
                cursor.execute("SELECT category_id, category_name FROM categories")
                cat_map = {row["category_name"]: row["category_id"] for row in cursor.fetchall()}

                cursor_mongo = coll.find({}).batch_size(batch_size)
                batch = []

                for doc in cursor_mongo:
                    cat_name = doc.get("category", "General")
                    if cat_name not in cat_map:
                        # Insert category
                        cursor.execute("INSERT INTO categories (category_name) VALUES (%s)", (cat_name,))
                        cat_map[cat_name] = cursor.lastrowid

                    cat_id = cat_map[cat_name]
                    batch.append((
                        doc["product_id"],
                        doc.get("product_name", f"Product {doc['product_id']}"),
                        cat_id,
                        float(doc.get("price", 0.0)),
                        doc.get("status", "active")
                    ))

                    if len(batch) >= batch_size:
                        cursor.executemany(
                            """
                            INSERT INTO products (product_id, product_name, category_id, price, status)
                            VALUES (%s, %s, %s, %s, %s)
                            ON DUPLICATE KEY UPDATE
                                product_name = VALUES(product_name),
                                category_id = VALUES(category_id),
                                price = VALUES(price),
                                status = VALUES(status)
                            """,
                            batch
                        )
                        conn.commit()
                        processed += len(batch)
                        batch = []
                        if progress_callback:
                            progress_callback(processed, total_docs, f"Synced {processed}/{total_docs} products to MySQL...")

                if batch:
                    cursor.executemany(
                        """
                        INSERT INTO products (product_id, product_name, category_id, price, status)
                        VALUES (%s, %s, %s, %s, %s)
                        ON DUPLICATE KEY UPDATE
                            product_name = VALUES(product_name),
                            category_id = VALUES(category_id),
                            price = VALUES(price),
                            status = VALUES(status)
                        """,
                        batch
                    )
                    conn.commit()
                    processed += len(batch)

            except Exception as e:
                conn.rollback()
                logger.error(f"MongoDB to MySQL sync failed: {e}")
                failed = total_docs - processed
                return {"success": False, "error": str(e), "processed": processed, "duration_ms": timer.elapsed_ms}
            finally:
                cursor.close()
                conn.close()

        return {
            "success": failed == 0,
            "processed": processed,
            "failed": failed,
            "total_source_docs": total_docs,
            "duration_ms": round(timer.elapsed_ms, 2),
            "error": None
        }
