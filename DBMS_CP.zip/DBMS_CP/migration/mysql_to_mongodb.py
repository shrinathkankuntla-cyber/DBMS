from typing import Optional, Dict, Any, Callable
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from migration.field_mapping import mysql_product_to_mongodb_doc
from pymongo import ReplaceOne
from utils.helpers import Timer
from utils.logger import get_logger

logger = get_logger("mysql_to_mongodb")

class MySQLToMongoDBMigrator:
    """
    Performs robust batch migration of product catalogue data from MySQL to MongoDB
    with duplicate upsert handling, type conversions, and verification.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None, mongo_db: Optional[MongoDBDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()
        self.mongo = mongo_db or MongoDBDatabase()

    def migrate_products(
        self,
        batch_size: int = 500,
        progress_callback: Optional[Callable[[int, int, str], None]] = None
    ) -> Dict[str, Any]:
        """
        Extracts products from MySQL and upserts them into MongoDB product_catalog.
        """
        # Ensure collection and identity index exist
        self.mongo.init_collection()
        coll = self.mongo.get_collection("product_catalog")

        # 1. Fetch total count
        sql_count = "SELECT COUNT(*) AS total FROM products"
        success, rows, err = self.mysql.execute_query(sql_count, fetch=True)
        if not success or not rows:
            return {"success": False, "error": f"Failed to query MySQL: {err}", "migrated_count": 0}

        total_records = rows[0]["total"]
        if total_records == 0:
            return {"success": True, "migrated_count": 0, "total_records": 0, "duration_ms": 0.0, "message": "No products in MySQL to migrate."}

        # 2. Stream and migrate in batches
        processed = 0
        failed = 0
        offset = 0

        with Timer() as timer:
            while offset < total_records:
                sql_batch = """
                    SELECT p.product_id, p.product_name, p.price, p.status, p.created_at,
                           c.category_name
                    FROM products p
                    JOIN categories c ON p.category_id = c.category_id
                    ORDER BY p.product_id ASC
                    LIMIT %s OFFSET %s
                """
                success, batch_rows, err = self.mysql.execute_query(sql_batch, (batch_size, offset), fetch=True)
                if not success:
                    logger.error(f"Error fetching batch at offset {offset}: {err}")
                    failed += (total_records - offset)
                    break

                if not batch_rows:
                    break

                mongo_ops = []
                for row in batch_rows:
                    doc = mysql_product_to_mongodb_doc(row, row["category_name"])
                    mongo_ops.append(
                        ReplaceOne({"product_id": doc["product_id"]}, doc, upsert=True)
                    )

                if mongo_ops:
                    try:
                        coll.bulk_write(mongo_ops, ordered=False)
                        processed += len(mongo_ops)
                    except Exception as e:
                        logger.error(f"MongoDB bulk write error: {e}")
                        failed += len(mongo_ops)

                offset += len(batch_rows)
                if progress_callback:
                    progress_callback(processed, total_records, f"Migrated {processed}/{total_records} products...")

        # 3. Post-migration destination count check
        destination_count = coll.estimated_document_count()

        return {
            "success": failed == 0,
            "processed": processed,
            "failed": failed,
            "total_source_records": total_records,
            "destination_catalog_count": destination_count,
            "duration_ms": round(timer.elapsed_ms, 2),
            "error": None if failed == 0 else f"{failed} records failed during write."
        }
