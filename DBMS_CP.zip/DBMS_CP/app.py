import streamlit as st

# Configure page settings
st.set_page_config(
    page_title="Index Optimizer — E-Commerce Workload Lab",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Inject Centralized Light Theme CSS
from ui.theme import inject_theme
inject_theme()

# Import View Renderers & Components
from ui.components import render_sidebar_branding, render_sidebar_db_status
from ui.overview import render_overview
from ui.connections import render_connections
from ui.schema_dataset import render_schema_dataset
from ui.olist_dataset import render_olist_dataset
from ui.workload_simulator import render_workload_simulator
from ui.index_laboratory import render_index_laboratory
from ui.query_workspace import render_query_workspace
from ui.analytics import render_analytics
from ui.recommendations import render_recommendations
from ui.migration import render_migration
from ui.transaction_testing import render_transaction_testing
from ui.experiment_history import render_experiment_history
from ui.settings import render_settings

# Render Sidebar Branding
render_sidebar_branding()

# Grouped Navigation Definition
PAGES = {
    "Dashboard": ("Dashboard", "OVERVIEW"),
    "Connections": ("Connections", "DATABASE MANAGEMENT"),
    "Schema & Dataset": ("Schema & Dataset", "DATABASE MANAGEMENT"),
    "Olist Dataset": ("Olist Dataset", "DATABASE MANAGEMENT"),
    "Query Workspace": ("Query Workspace", "DATABASE MANAGEMENT"),
    "Workload Simulator": ("Workload Simulator", "PERFORMANCE ENGINEERING"),
    "Index Laboratory": ("Index Laboratory", "PERFORMANCE ENGINEERING"),
    "Performance Analytics": ("Performance Analytics", "PERFORMANCE ENGINEERING"),
    "Recommendations": ("Recommendations", "PERFORMANCE ENGINEERING"),
    "Data Migration": ("Data Migration", "SYSTEM OPERATIONS"),
    "Transaction Testing": ("Transaction Testing", "SYSTEM OPERATIONS"),
    "Experiment History": ("Experiment History", "SYSTEM OPERATIONS"),
    "Configuration": ("Configuration", "SETTINGS"),
}

# Navigation in Sidebar
st.sidebar.markdown(
    "<div style='font-size: 0.72rem; font-weight: 700; color: #242424; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 6px;'>Workspace Navigation</div>",
    unsafe_allow_html=True
)

selected_page = st.sidebar.radio(
    "Navigation",
    list(PAGES.keys()),
    index=0,
    label_visibility="collapsed"
)

# Live Database Status at bottom of sidebar
render_sidebar_db_status()

# Router
if selected_page == "Dashboard":
    render_overview()
elif selected_page == "Connections":
    render_connections()
elif selected_page == "Schema & Dataset":
    render_schema_dataset()
elif selected_page == "Olist Dataset":
    render_olist_dataset()
elif selected_page == "Query Workspace":
    render_query_workspace()
elif selected_page == "Workload Simulator":
    render_workload_simulator()
elif selected_page == "Index Laboratory":
    render_index_laboratory()
elif selected_page == "Performance Analytics":
    render_analytics()
elif selected_page == "Recommendations":
    render_recommendations()
elif selected_page == "Data Migration":
    render_migration()
elif selected_page == "Transaction Testing":
    render_transaction_testing()
elif selected_page == "Experiment History":
    render_experiment_history()
elif selected_page == "Configuration":
    render_settings()
