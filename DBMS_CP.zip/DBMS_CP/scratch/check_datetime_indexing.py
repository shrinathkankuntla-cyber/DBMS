import os
import re

pattern = re.compile(r'\[\s*:\s*\d+\s*\]')

print("Scanning for any bracket slicing on potential datetime variables...")
found = 0
for root, dirs, files in os.walk('.'):
    if any(p in root for p in ['.git', '__pycache__', '.venv', 'venv', 'brain']):
        continue
    for f in files:
        if f.endswith('.py'):
            path = os.path.join(root, f)
            with open(path, 'r', encoding='utf-8', errors='ignore') as fp:
                for idx, line in enumerate(fp, 1):
                    if pattern.search(line):
                        print(f"{path}:{idx} -> {line.strip()}")
                        found += 1

print(f"Total slice patterns found: {found}")
