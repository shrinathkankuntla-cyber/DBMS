import mysql.connector
from mysql.connector import Error, pooling
from contextlib import contextmanager
from typing import Optional, Dict, Any, List, Tuple
from pathlib import Path
from config.database_config import MySQLConfig
from utils.logger import get_logger

logger = get_logger("mysql_connection")

class MySQLDatabase:
    """
    Manages MySQL connections, connection pooling, schema initialization,
    and safe query execution for ecommerce_optimizer.
    """
    def __init__(self, config: Optional[MySQLConfig] = None):
        self.config = config or MySQLConfig.from_env()
        self._pool: Optional[pooling.MySQLConnectionPool] = None

    def get_raw_connection(self, include_db: bool = True):
        """Creates a direct unpooled connection."""
        cfg = self.config.to_dict(include_db=include_db)
        return mysql.connector.connect(**cfg)

    def test_connection(self) -> Tuple[bool, str]:
        """
        Tests the MySQL connection. Returns (True, server_version) or (False, error_message).
        Masks passwords in output.
        """
        try:
            conn = self.get_raw_connection(include_db=False)
            if conn.is_connected():
                version = conn.get_server_info()
                conn.close()
                return True, f"Connected to MySQL {version} at {self.config.host}:{self.config.port}"
            return False, "Failed to connect to MySQL."
        except Error as e:
            logger.error(f"MySQL connection error: {e}")
            return False, str(e)
        except Exception as e:
            logger.error(f"Unexpected error connecting to MySQL: {e}")
            return False, str(e)

    def init_schema(self, schema_file: Optional[Path] = None) -> Tuple[bool, str]:
        """
        Executes the schema SQL script to create the database and tables.
        """
        if schema_file is None:
            schema_file = Path(__file__).resolve().parent / "mysql_schema.sql"

        if not schema_file.exists():
            return False, f"Schema file not found at {schema_file}"

        try:
            with open(schema_file, "r", encoding="utf-8") as f:
                sql_content = f.read()

            # First connect without DB to ensure DB exists
            conn = self.get_raw_connection(include_db=False)
            cursor = conn.cursor()

            # Execute statements
            # Split by semicolon while respecting strings
            statements = [stmt.strip() for stmt in sql_content.split(';') if stmt.strip()]
            for stmt in statements:
                # Skip comments
                lines = [l for l in stmt.split('\n') if not l.strip().startswith('--')]
                clean_stmt = '\n'.join(lines).strip()
                if clean_stmt:
                    cursor.execute(clean_stmt)
            
            conn.commit()
            cursor.close()
            conn.close()
            return True, "MySQL schema initialized successfully."
        except Error as e:
            logger.error(f"Failed to initialize MySQL schema: {e}")
            return False, str(e)

    @contextmanager
    def get_connection(self):
        """Context manager for acquiring and closing a MySQL connection."""
        conn = self.get_raw_connection(include_db=True)
        try:
            yield conn
        finally:
            if conn.is_connected():
                conn.close()

    def execute_query(self, query: str, params: Optional[Tuple] = None, fetch: bool = True) -> Tuple[bool, Any, str]:
        """
        Safely executes a parameterized SQL query.
        Returns (success: bool, result_or_cursor: Any, message_or_error: str).
        """
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor(dictionary=True)
                cursor.execute(query, params or ())
                if fetch:
                    data = cursor.fetchall()
                else:
                    conn.commit()
                    data = cursor.rowcount
                cursor.close()
                return True, data, "Query executed successfully."
        except Error as e:
            return False, None, str(e)

    def get_table_counts(self) -> Dict[str, int]:
        """Returns verified real row counts for all application tables."""
        tables = [
            'customers', 'categories', 'products', 'inventory', 'orders', 'order_items',
            'cart_items', 'sellers', 'order_payments', 'order_reviews', 'geolocation', 'experiments'
        ]
        counts = {}
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                for t in tables:
                    try:
                        cursor.execute(f"SELECT COUNT(*) FROM {t}")
                        row = cursor.fetchone()
                        counts[t] = row[0] if row else 0
                    except Error:
                        counts[t] = 0
                cursor.close()
        except Error as e:
            logger.warning(f"Could not retrieve table counts: {e}")
        return counts

    def get_index_statistics(self, table_name: str) -> List[Dict[str, Any]]:
        """
        Returns index details for a given table from SHOW INDEX.
        """
        indexes = []
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor(dictionary=True)
                cursor.execute(f"SHOW INDEX FROM {table_name}")
                rows = cursor.fetchall()
                cursor.close()
                return rows
        except Error as e:
            logger.warning(f"Could not retrieve index statistics for {table_name}: {e}")
            return []
