import pymongo
from pymongo import MongoClient
from pymongo.errors import PyMongoError, ConnectionFailure
from typing import Optional, Dict, Any, List, Tuple
from config.database_config import MongoDBConfig
from utils.logger import get_logger

logger = get_logger("mongodb_connection")

class MongoDBDatabase:
    """
    Manages MongoDB connections, collection initialization,
    and index querying for product_catalog.
    """
    def __init__(self, config: Optional[MongoDBConfig] = None):
        self.config = config or MongoDBConfig.from_env()
        self._client: Optional[MongoClient] = None

    def get_client(self) -> MongoClient:
        """Returns or creates a MongoClient instance."""
        if self._client is None:
            self._client = MongoClient(
                self.config.uri,
                serverSelectionTimeoutMS=3000,
                connectTimeoutMS=3000
            )
        return self._client

    def get_db(self):
        client = self.get_client()
        return client[self.config.database]

    def get_collection(self, name: str = "product_catalog"):
        return self.get_db()[name]

    def test_connection(self) -> Tuple[bool, str]:
        """
        Tests MongoDB connection and returns server version or error message.
        """
        try:
            client = MongoClient(self.config.uri, serverSelectionTimeoutMS=2500)
            server_info = client.server_info()
            version = server_info.get("version", "unknown")
            client.close()
            return True, f"Connected to MongoDB v{version} at {self.config.safe_summary()}"
        except ConnectionFailure as e:
            logger.error(f"MongoDB connection failure: {e}")
            return False, str(e)
        except PyMongoError as e:
            logger.error(f"MongoDB PyMongoError: {e}")
            return False, str(e)
        except Exception as e:
            logger.error(f"Unexpected MongoDB error: {e}")
            return False, str(e)

    def init_collection(self) -> Tuple[bool, str]:
        """
        Initializes the product_catalog collection and creates the required
        unique identity index on product_id.
        """
        try:
            db = self.get_db()
            colls = db.list_collection_names()
            if "product_catalog" not in colls:
                db.create_collection("product_catalog")

            catalog = db["product_catalog"]
            # Ensure mandatory identity index on product_id
            existing_indexes = catalog.index_information()
            if "idx_identity_product_id" not in existing_indexes and "product_id_1" not in existing_indexes:
                catalog.create_index(
                    [("product_id", pymongo.ASCENDING)],
                    unique=True,
                    name="idx_identity_product_id"
                )
            return True, "MongoDB collection 'product_catalog' initialized with unique identity index."
        except PyMongoError as e:
            logger.error(f"Failed to initialize MongoDB collection: {e}")
            return False, str(e)

    def get_collection_stats(self, collection_name: str = "product_catalog") -> Dict[str, Any]:
        """
        Retrieves real storage and document metrics from MongoDB collstats.
        """
        try:
            db = self.get_db()
            stats = db.command("collstats", collection_name)
            return {
                "count": stats.get("count", 0),
                "size_bytes": stats.get("size", 0),
                "avg_obj_size": stats.get("avgObjSize", 0),
                "storage_size_bytes": stats.get("storageSize", 0),
                "total_index_size_bytes": stats.get("totalIndexSize", 0),
                "index_count": len(stats.get("indexSizes", {})),
                "index_sizes": stats.get("indexSizes", {})
            }
        except PyMongoError as e:
            logger.warning(f"Could not retrieve collstats for {collection_name}: {e}")
            # Fallback to estimated_document_count
            try:
                coll = self.get_collection(collection_name)
                return {
                    "count": coll.estimated_document_count(),
                    "size_bytes": 0,
                    "avg_obj_size": 0,
                    "storage_size_bytes": 0,
                    "total_index_size_bytes": 0,
                    "index_count": len(coll.index_information()),
                    "index_sizes": {}
                }
            except Exception:
                return {"count": 0, "size_bytes": 0, "total_index_size_bytes": 0, "index_count": 0, "index_sizes": {}}

    def list_indexes(self, collection_name: str = "product_catalog") -> Dict[str, Any]:
        """Returns the dictionary of index specifications."""
        try:
            coll = self.get_collection(collection_name)
            return coll.index_information()
        except PyMongoError as e:
            logger.warning(f"Could not list indexes: {e}")
            return {}
