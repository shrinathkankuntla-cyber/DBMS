-- ====================================================================
-- E-COMMERCE WORKLOAD-AWARE DATABASE QUERY AND INDEX COST OPTIMIZER
-- Authoritative Relational Schema (MySQL InnoDB)
-- Enhanced for Olist Brazilian E-Commerce Dataset Integration
-- ====================================================================

CREATE DATABASE IF NOT EXISTS ecommerce_optimizer
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE ecommerce_optimizer;

-- 1. Customers Table
CREATE TABLE IF NOT EXISTS customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    source_id VARCHAR(64) UNIQUE,
    customer_unique_id VARCHAR(64),
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    zip_code_prefix VARCHAR(10),
    city VARCHAR(100),
    state VARCHAR(10),
    data_origin VARCHAR(20) NOT NULL DEFAULT 'imported',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_customers_data_origin (data_origin),
    INDEX idx_customers_source (source_id)
) ENGINE=InnoDB;

-- 2. Categories Table
CREATE TABLE IF NOT EXISTS categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL UNIQUE,
    source_name VARCHAR(100),
    INDEX idx_categories_source (source_name)
) ENGINE=InnoDB;

-- 3. Products Table
CREATE TABLE IF NOT EXISTS products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    source_id VARCHAR(64) UNIQUE,
    product_name VARCHAR(255) NOT NULL,
    category_id INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    weight_g INT,
    length_cm INT,
    height_cm INT,
    width_cm INT,
    photos_qty INT,
    data_origin VARCHAR(20) NOT NULL DEFAULT 'imported',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_products_category
        FOREIGN KEY (category_id) REFERENCES categories(category_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_products_price
        CHECK (price >= 0.00),
    INDEX idx_products_data_origin (data_origin),
    INDEX idx_products_source (source_id)
) ENGINE=InnoDB;

-- 4. Inventory Table
CREATE TABLE IF NOT EXISTS inventory (
    product_id INT PRIMARY KEY,
    stock_quantity INT NOT NULL DEFAULT 0,
    baseline_stock INT NOT NULL DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_inventory_product
        FOREIGN KEY (product_id) REFERENCES products(product_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_inventory_stock
        CHECK (stock_quantity >= 0),
    CONSTRAINT chk_inventory_baseline
        CHECK (baseline_stock >= 0)
) ENGINE=InnoDB;

-- 5. Orders Table
CREATE TABLE IF NOT EXISTS orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    source_id VARCHAR(64) UNIQUE,
    customer_id INT NOT NULL,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    order_status VARCHAR(50) NOT NULL DEFAULT 'pending',
    total_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    data_origin VARCHAR(20) NOT NULL DEFAULT 'imported',
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_orders_total
        CHECK (total_amount >= 0.00),
    INDEX idx_orders_data_origin (data_origin),
    INDEX idx_orders_source (source_id)
) ENGINE=InnoDB;

-- 6. Order Items Table
CREATE TABLE IF NOT EXISTS order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    source_id VARCHAR(64),
    seller_id VARCHAR(64),
    quantity INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10, 2) NOT NULL,
    freight_value DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    subtotal DECIMAL(12, 2) NOT NULL,
    data_origin VARCHAR(20) NOT NULL DEFAULT 'imported',
    CONSTRAINT fk_order_items_order
        FOREIGN KEY (order_id) REFERENCES orders(order_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_order_items_product
        FOREIGN KEY (product_id) REFERENCES products(product_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_order_items_quantity
        CHECK (quantity > 0),
    CONSTRAINT chk_order_items_unit_price
        CHECK (unit_price >= 0.00),
    CONSTRAINT chk_order_items_subtotal
        CHECK (subtotal >= 0.00),
    INDEX idx_order_items_data_origin (data_origin),
    INDEX idx_order_items_source (source_id)
) ENGINE=InnoDB;

-- 7. Cart Items Table (Persistent Cart Operation Support)
CREATE TABLE IF NOT EXISTS cart_items (
    cart_item_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    data_origin VARCHAR(20) NOT NULL DEFAULT 'benchmark',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_cart_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_cart_product
        FOREIGN KEY (product_id) REFERENCES products(product_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT uq_cart_customer_product
        UNIQUE (customer_id, product_id),
    CONSTRAINT chk_cart_quantity
        CHECK (quantity > 0)
) ENGINE=InnoDB;

-- 8. Sellers Table (Olist Relational Support)
CREATE TABLE IF NOT EXISTS sellers (
    seller_id VARCHAR(64) PRIMARY KEY,
    zip_code_prefix VARCHAR(10),
    city VARCHAR(100),
    state VARCHAR(10)
) ENGINE=InnoDB;

-- 9. Order Payments Table (Olist Relational Support)
CREATE TABLE IF NOT EXISTS order_payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    payment_sequential INT NOT NULL DEFAULT 1,
    payment_type VARCHAR(50) NOT NULL,
    payment_installments INT NOT NULL DEFAULT 1,
    payment_value DECIMAL(10, 2) NOT NULL,
    data_origin VARCHAR(20) NOT NULL DEFAULT 'imported',
    CONSTRAINT fk_payments_order
        FOREIGN KEY (order_id) REFERENCES orders(order_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_payments_value
        CHECK (payment_value >= 0.00),
    INDEX idx_payments_data_origin (data_origin)
) ENGINE=InnoDB;

-- 10. Order Reviews Table (Olist Relational Support)
CREATE TABLE IF NOT EXISTS order_reviews (
    review_id VARCHAR(64) PRIMARY KEY,
    order_id INT NOT NULL,
    review_score INT NOT NULL,
    review_comment_title VARCHAR(255),
    review_comment_message TEXT,
    created_at DATETIME,
    data_origin VARCHAR(20) NOT NULL DEFAULT 'imported',
    CONSTRAINT fk_reviews_order
        FOREIGN KEY (order_id) REFERENCES orders(order_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    INDEX idx_reviews_data_origin (data_origin)
) ENGINE=InnoDB;

-- 11. Geolocation Table (Olist Relational Support)
CREATE TABLE IF NOT EXISTS geolocation (
    geolocation_id INT AUTO_INCREMENT PRIMARY KEY,
    zip_code_prefix VARCHAR(10) NOT NULL,
    lat DECIMAL(10, 8),
    lng DECIMAL(11, 8),
    city VARCHAR(100),
    state VARCHAR(10),
    INDEX idx_geo_zip (zip_code_prefix)
) ENGINE=InnoDB;

-- 12. Olist Ingestion Audit Logs
CREATE TABLE IF NOT EXISTS olist_import_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    file_name VARCHAR(100) NOT NULL,
    imported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_rows INT NOT NULL DEFAULT 0,
    valid_rows INT NOT NULL DEFAULT 0,
    duplicate_rows INT NOT NULL DEFAULT 0,
    rejected_rows INT NOT NULL DEFAULT 0,
    status VARCHAR(50) NOT NULL DEFAULT 'COMPLETED',
    details JSON
) ENGINE=InnoDB;

-- 13. Persistent Experiment Metadata & History
CREATE TABLE IF NOT EXISTS experiments (
    experiment_id VARCHAR(64) PRIMARY KEY,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    database_type VARCHAR(20) NOT NULL,
    workload_name VARCHAR(100) NOT NULL,
    config_type VARCHAR(50) NOT NULL,
    read_ratio FLOAT NOT NULL,
    write_ratio FLOAT NOT NULL,
    operation_count INT NOT NULL,
    total_duration_ms FLOAT NOT NULL,
    notes TEXT
) ENGINE=InnoDB;

-- 14. Experiment Metrics
CREATE TABLE IF NOT EXISTS experiment_metrics (
    metric_id INT AUTO_INCREMENT PRIMARY KEY,
    experiment_id VARCHAR(64) NOT NULL,
    metric_name VARCHAR(100) NOT NULL,
    metric_value FLOAT NOT NULL,
    unit VARCHAR(50) NOT NULL,
    CONSTRAINT fk_exp_metrics_experiment
        FOREIGN KEY (experiment_id) REFERENCES experiments(experiment_id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- 15. Experiment Recommendations
CREATE TABLE IF NOT EXISTS experiment_recommendations (
    rec_id INT AUTO_INCREMENT PRIMARY KEY,
    experiment_id VARCHAR(64) NOT NULL,
    index_name VARCHAR(100) NOT NULL,
    classification VARCHAR(50) NOT NULL,
    read_improvement_pct FLOAT,
    write_penalty_pct FLOAT,
    storage_impact_bytes BIGINT,
    reasoning TEXT,
    CONSTRAINT fk_exp_rec_experiment
        FOREIGN KEY (experiment_id) REFERENCES experiments(experiment_id)
        ON DELETE CASCADE
) ENGINE=InnoDB;
