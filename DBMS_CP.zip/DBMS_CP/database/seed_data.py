import random
import datetime
from typing import Dict, Any, Optional, Callable
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from utils.logger import get_logger

logger = get_logger("seed_data")

CATEGORY_NAMES = [
    "Smartphones & Tablets", "Laptops & Computers", "Audio & Headphones",
    "Cameras & Photography", "Wearable Technology", "Television & Video",
    "Home Appliances", "Kitchen & Dining", "Furniture & Decor",
    "Men's Clothing", "Women's Clothing", "Kids' Fashion",
    "Footwear & Shoes", "Sports & Fitness", "Beauty & Personal Care",
    "Health & Wellness", "Books & Stationery", "Toys & Games",
    "Automotive Accessories", "Pet Supplies"
]

BRANDS = [
    "ApexTech", "NexusPro", "Vanguard", "EchoWave", "Lumina",
    "Hyperion", "QuantumCore", "AeroStyle", "TerraNova", "Solstice",
    "PulseGear", "ZenithCraft", "OmniVision", "TitanFit", "PrimeNest"
]

COLORS = ["Black", "White", "Silver", "Space Gray", "Midnight Blue", "Forest Green", "Crimson", "Rose Gold"]
SIZES = ["XS", "S", "M", "L", "XL", "XXL", "Standard", "Pro", "Max"]
STATUSES = ["active", "active", "active", "active", "inactive"] # 80% active

FIRST_NAMES = [
    "Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Ayaan", "Krishna", "Ishaan",
    "Ananya", "Diya", "Saanvi", "Aadhya", "Pari", "Chiara", "Riya", "Myra", "Avani", "Fatima",
    "James", "Emma", "Liam", "Olivia", "Noah", "Sophia", "Lucas", "Mia", "Alexander", "Isabella"
]

LAST_NAMES = [
    "Sharma", "Verma", "Patel", "Reddy", "Rao", "Nair", "Mehta", "Iyer", "Joshi", "Kulkarni",
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"
]

class SeedDataGenerator:
    """
    Generates realistic, configurable e-commerce datasets reproducibly across MySQL and MongoDB.
    """
    def __init__(self, seed: int = 42, mysql_db: Optional[MySQLDatabase] = None, mongo_db: Optional[MongoDBDatabase] = None):
        self.seed = seed
        self.mysql = mysql_db or MySQLDatabase()
        self.mongo = mongo_db or MongoDBDatabase()
        random.seed(self.seed)

    def generate_all(
        self,
        num_customers: int = 1000,
        num_products: int = 2000,
        num_orders: int = 3000,
        progress_callback: Optional[Callable[[str, float], None]] = None
    ) -> Dict[str, int]:
        """
        Executes bulk generation across MySQL and MongoDB.
        """
        random.seed(self.seed)
        results = {}

        if progress_callback:
            progress_callback("Initializing schemas...", 0.05)
        self.mysql.init_schema()
        self.mongo.init_collection()

        # 1. Categories
        if progress_callback:
            progress_callback("Generating Categories...", 0.15)
        cat_ids = self._seed_categories()
        results["categories"] = len(cat_ids)

        # 2. Customers
        if progress_callback:
            progress_callback(f"Generating {num_customers} Customers...", 0.30)
        cust_ids = self._seed_customers(num_customers)
        results["customers"] = len(cust_ids)

        # 3. Products, Inventory & MongoDB Catalog
        if progress_callback:
            progress_callback(f"Generating {num_products} Products & MongoDB Catalog...", 0.55)
        prod_data = self._seed_products_and_catalog(num_products, cat_ids)
        results["products"] = prod_data["count"]
        results["mongodb_catalog"] = prod_data["mongo_count"]

        # 4. Orders & Order Items
        if progress_callback:
            progress_callback(f"Generating {num_orders} Orders & Items...", 0.85)
        order_stats = self._seed_orders(num_orders, cust_ids, prod_data["product_tuples"])
        results["orders"] = order_stats["orders"]
        results["order_items"] = order_stats["items"]

        if progress_callback:
            progress_callback("Dataset generation completed!", 1.0)

        logger.info(f"Seed generation completed: {results}")
        return results

    def _seed_categories(self) -> list:
        conn = self.mysql.get_raw_connection(include_db=True)
        cursor = conn.cursor()
        cat_ids = []
        try:
            for cat_name in CATEGORY_NAMES:
                cursor.execute(
                    "INSERT INTO categories (category_name) VALUES (%s) "
                    "ON DUPLICATE KEY UPDATE category_id=LAST_INSERT_ID(category_id)",
                    (cat_name,)
                )
                cat_ids.append(cursor.lastrowid)
            conn.commit()
        finally:
            cursor.close()
            conn.close()
        return cat_ids

    def _seed_customers(self, count: int) -> list:
        conn = self.mysql.get_raw_connection(include_db=True)
        cursor = conn.cursor()
        cust_ids = []
        batch_size = 1000
        batch = []
        
        # Check existing count
        cursor.execute("SELECT customer_id FROM customers LIMIT %s", (count,))
        existing = cursor.fetchall()
        if len(existing) >= count:
            cursor.close()
            conn.close()
            return [row[0] for row in existing]

        base_time = datetime.datetime.now() - datetime.timedelta(days=365)
        try:
            for i in range(count):
                fn = random.choice(FIRST_NAMES)
                ln = random.choice(LAST_NAMES)
                full_name = f"{fn} {ln}"
                email = f"{fn.lower()}.{ln.lower()}_{i}_{self.seed}@example.com"
                created_at = base_time + datetime.timedelta(minutes=i * 5)
                batch.append((full_name, email, created_at))

                if len(batch) >= batch_size:
                    cursor.executemany(
                        "INSERT IGNORE INTO customers (full_name, email, created_at) VALUES (%s, %s, %s)",
                        batch
                    )
                    conn.commit()
                    batch = []

            if batch:
                cursor.executemany(
                    "INSERT IGNORE INTO customers (full_name, email, created_at) VALUES (%s, %s, %s)",
                    batch
                )
                conn.commit()

            cursor.execute("SELECT customer_id FROM customers")
            cust_ids = [row[0] for row in cursor.fetchall()]
        finally:
            cursor.close()
            conn.close()
        return cust_ids

    def _seed_products_and_catalog(self, count: int, category_ids: list) -> Dict[str, Any]:
        conn = self.mysql.get_raw_connection(include_db=True)
        cursor = conn.cursor()
        mongo_coll = self.mongo.get_collection("product_catalog")

        # Map category_id to name
        cursor.execute("SELECT category_id, category_name FROM categories")
        cat_map = {row[0]: row[1] for row in cursor.fetchall()}

        cursor.execute("SELECT product_id, price FROM products LIMIT %s", (count,))
        existing = cursor.fetchall()
        if len(existing) >= count:
            cursor.close()
            conn.close()
            return {
                "count": len(existing),
                "mongo_count": mongo_coll.estimated_document_count(),
                "product_tuples": existing
            }

        batch_size = 1000
        prod_batch = []
        inv_batch = []
        mongo_docs = []
        base_time = datetime.datetime.now() - datetime.timedelta(days=180)

        try:
            for i in range(1, count + 1):
                cat_id = random.choice(category_ids)
                cat_name = cat_map[cat_id]
                brand = random.choice(BRANDS)
                model_num = random.randint(100, 9999)
                prod_name = f"{brand} {cat_name.split()[0]} {model_num}"
                price = round(random.uniform(9.99, 1999.99), 2)
                status = random.choice(STATUSES)
                created_at = base_time + datetime.timedelta(minutes=i * 10)
                stock_quantity = random.randint(0, 350)

                # MySQL product
                prod_batch.append((i, prod_name, cat_id, price, status, created_at))
                # MySQL inventory
                inv_batch.append((i, stock_quantity, created_at))

                # MongoDB Catalog document
                mongo_doc = {
                    "product_id": i,
                    "product_name": prod_name,
                    "category": cat_name,
                    "price": float(price),
                    "brand": brand,
                    "status": status,
                    "created_at": created_at,
                    "attributes": {
                        "color": random.choice(COLORS),
                        "material": random.choice(["Aluminum", "Carbon Fiber", "Cotton", "Polycarbonate", "Steel"]),
                        "weight_kg": round(random.uniform(0.1, 15.0), 2),
                        "rating": round(random.uniform(3.0, 5.0), 1),
                        "warranty_months": random.choice([6, 12, 24, 36])
                    },
                    "variants": [
                        {
                            "sku": f"SKU-{i}-VAR-1",
                            "size": random.choice(SIZES),
                            "color": random.choice(COLORS),
                            "additional_price": 0.0
                        },
                        {
                            "sku": f"SKU-{i}-VAR-2",
                            "size": random.choice(SIZES),
                            "color": random.choice(COLORS),
                            "additional_price": round(price * 0.1, 2)
                        }
                    ]
                }
                mongo_docs.append(mongo_doc)

                if len(prod_batch) >= batch_size:
                    cursor.executemany(
                        "INSERT IGNORE INTO products (product_id, product_name, category_id, price, status, created_at) "
                        "VALUES (%s, %s, %s, %s, %s, %s)",
                        prod_batch
                    )
                    cursor.executemany(
                        "INSERT IGNORE INTO inventory (product_id, stock_quantity, updated_at) "
                        "VALUES (%s, %s, %s)",
                        inv_batch
                    )
                    conn.commit()
                    prod_batch = []
                    inv_batch = []

                if len(mongo_docs) >= batch_size:
                    # Upsert documents into MongoDB
                    from pymongo import ReplaceOne
                    ops = [
                        ReplaceOne({"product_id": d["product_id"]}, d, upsert=True)
                        for d in mongo_docs
                    ]
                    mongo_coll.bulk_write(ops, ordered=False)
                    mongo_docs = []

            if prod_batch:
                cursor.executemany(
                    "INSERT IGNORE INTO products (product_id, product_name, category_id, price, status, created_at) "
                    "VALUES (%s, %s, %s, %s, %s, %s)",
                    prod_batch
                )
                cursor.executemany(
                    "INSERT IGNORE INTO inventory (product_id, stock_quantity, updated_at) "
                    "VALUES (%s, %s, %s)",
                    inv_batch
                )
                conn.commit()

            if mongo_docs:
                from pymongo import ReplaceOne
                ops = [
                    ReplaceOne({"product_id": d["product_id"]}, d, upsert=True)
                    for d in mongo_docs
                ]
                mongo_coll.bulk_write(ops, ordered=False)

            cursor.execute("SELECT product_id, price FROM products")
            product_tuples = cursor.fetchall()
            return {
                "count": len(product_tuples),
                "mongo_count": mongo_coll.estimated_document_count(),
                "product_tuples": product_tuples
            }
        finally:
            cursor.close()
            conn.close()

    def _seed_orders(self, count: int, customer_ids: list, product_tuples: list) -> Dict[str, int]:
        if not customer_ids or not product_tuples:
            return {"orders": 0, "items": 0}

        conn = self.mysql.get_raw_connection(include_db=True)
        cursor = conn.cursor()

        cursor.execute("SELECT COUNT(*) FROM orders")
        existing_orders = cursor.fetchone()[0]
        if existing_orders >= count:
            cursor.execute("SELECT COUNT(*) FROM order_items")
            existing_items = cursor.fetchone()[0]
            cursor.close()
            conn.close()
            return {"orders": existing_orders, "items": existing_items}

        order_batch = []
        item_batch = []
        base_time = datetime.datetime.now() - datetime.timedelta(days=90)
        statuses = ["completed", "completed", "completed", "shipped", "processing", "cancelled"]

        total_orders_inserted = 0
        total_items_inserted = 0

        try:
            for i in range(1, count + 1):
                cust_id = random.choice(customer_ids)
                order_date = base_time + datetime.timedelta(minutes=i * 20)
                status = random.choice(statuses)

                # Each order has 1 to 4 distinct items
                num_items = random.randint(1, 4)
                chosen_prods = random.sample(product_tuples, min(num_items, len(product_tuples)))
                
                order_total = 0.0
                order_items_temp = []
                for p_id, p_price in chosen_prods:
                    qty = random.randint(1, 3)
                    subtotal = round(float(p_price) * qty, 2)
                    order_total += subtotal
                    order_items_temp.append((p_id, qty, float(p_price), subtotal))

                order_batch.append((i, cust_id, order_date, status, round(order_total, 2)))
                for item in order_items_temp:
                    # (order_id, product_id, quantity, unit_price, subtotal)
                    item_batch.append((i, item[0], item[1], item[2], item[3]))

                if len(order_batch) >= 1000:
                    cursor.executemany(
                        "INSERT IGNORE INTO orders (order_id, customer_id, order_date, order_status, total_amount) "
                        "VALUES (%s, %s, %s, %s, %s)",
                        order_batch
                    )
                    cursor.executemany(
                        "INSERT IGNORE INTO order_items (order_id, product_id, quantity, unit_price, subtotal) "
                        "VALUES (%s, %s, %s, %s, %s)",
                        item_batch
                    )
                    conn.commit()
                    total_orders_inserted += len(order_batch)
                    total_items_inserted += len(item_batch)
                    order_batch = []
                    item_batch = []

            if order_batch:
                cursor.executemany(
                    "INSERT IGNORE INTO orders (order_id, customer_id, order_date, order_status, total_amount) "
                    "VALUES (%s, %s, %s, %s, %s)",
                    order_batch
                )
                cursor.executemany(
                    "INSERT IGNORE INTO order_items (order_id, product_id, quantity, unit_price, subtotal) "
                    "VALUES (%s, %s, %s, %s, %s)",
                    item_batch
                )
                conn.commit()
                total_orders_inserted += len(order_batch)
                total_items_inserted += len(item_batch)

            return {"orders": total_orders_inserted, "items": total_items_inserted}
        finally:
            cursor.close()
            conn.close()
