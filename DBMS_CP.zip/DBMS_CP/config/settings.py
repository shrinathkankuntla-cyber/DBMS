import os
from pathlib import Path
from dotenv import load_dotenv

# Base directory of the project
BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"

# Load environment variables
load_dotenv(ENV_FILE)

def get_env(key: str, default: str = "") -> str:
    return os.getenv(key, default)

def update_env_file(updates: dict):
    """
    Safely updates keys in .env without losing other comments or variables.
    """
    env_lines = []
    existing_keys = set()
    
    if ENV_FILE.exists():
        with open(ENV_FILE, "r", encoding="utf-8") as f:
            env_lines = f.readlines()
            
    new_lines = []
    for line in env_lines:
        line_stripped = line.strip()
        if line_stripped and not line_stripped.startswith("#") and "=" in line_stripped:
            k = line_stripped.split("=", 1)[0].strip()
            if k in updates:
                new_lines.append(f"{k}={updates[k]}\n")
                existing_keys.add(k)
                continue
        new_lines.append(line)
        
    for k, v in updates.items():
        if k not in existing_keys:
            new_lines.append(f"{k}={v}\n")
            
    with open(ENV_FILE, "w", encoding="utf-8") as f:
        f.writelines(new_lines)
        
    # Reload in current process
    load_dotenv(ENV_FILE, override=True)
