import os
from dataclasses import dataclass
from config.settings import get_env

@dataclass
class MySQLConfig:
    host: str = "localhost"
    port: int = 3306
    user: str = "root"
    password: str = ""
    database: str = "ecommerce_optimizer"

    @classmethod
    def from_env(cls) -> "MySQLConfig":
        return cls(
            host=get_env("MYSQL_HOST", "localhost"),
            port=int(get_env("MYSQL_PORT", "3306")),
            user=get_env("MYSQL_USER", "root"),
            password=get_env("MYSQL_PASSWORD", ""),
            database=get_env("MYSQL_DATABASE", "ecommerce_optimizer")
        )

    def to_dict(self, include_db: bool = True) -> dict:
        cfg = {
            "host": self.host,
            "port": self.port,
            "user": self.user,
            "password": self.password,
            "charset": "utf8mb4",
            "autocommit": False
        }
        if include_db and self.database:
            cfg["database"] = self.database
        return cfg

    def safe_summary(self) -> str:
        return f"mysql://{self.user}:***@{self.host}:{self.port}/{self.database}"


@dataclass
class MongoDBConfig:
    uri: str = "mongodb://localhost:27017/"
    database: str = "ecommerce_optimizer"

    @classmethod
    def from_env(cls) -> "MongoDBConfig":
        return cls(
            uri=get_env("MONGODB_URI", "mongodb://localhost:27017/"),
            database=get_env("MONGODB_DATABASE", "ecommerce_optimizer")
        )

    def safe_summary(self) -> str:
        # Mask credentials in URI if any exist
        import re
        masked_uri = re.sub(r'mongodb(\+srv)?://([^:]+):([^@]+)@', r'mongodb\1://\2:***@', self.uri)
        return f"{masked_uri} (db: {self.database})"
