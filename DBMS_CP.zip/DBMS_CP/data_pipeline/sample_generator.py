"""
Sample Olist Dataset Generator
Generates realistic, schema-accurate sample CSVs for all 9 Olist files into data/raw/
for immediate development, demonstration, and automated test suite validation.
"""

import os
import uuid
import random
import csv
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List

RAW_DATA_DIR = Path(__file__).resolve().parent.parent / "data" / "raw"

SAMPLE_CATEGORIES = [
    ("beleza_saude", "health_beauty"),
    ("informatica_acessorios", "computers_accessories"),
    ("cama_mesa_banho", "bed_bath_table"),
    ("esporte_lazer", "sports_leisure"),
    ("moveis_decoracao", "furniture_decor"),
    ("utilidades_domesticas", "housewares"),
    ("relogios_presentes", "watches_gifts"),
    ("telefonia", "telephony"),
    ("automotivo", "auto"),
    ("brinquedos", "toys")
]

BRAZILIAN_CITIES = [
    ("sao paulo", "SP", "01000"),
    ("rio de janeiro", "RJ", "20000"),
    ("belo horizonte", "MG", "30000"),
    ("brasilia", "DF", "70000"),
    ("curitiba", "PR", "80000"),
    ("porto alegre", "RS", "90000"),
    ("salvador", "BA", "40000"),
    ("recife", "PE", "50000"),
    ("fortaleza", "CE", "60000"),
    ("campinas", "SP", "13000")
]

ORDER_STATUSES = ["delivered", "delivered", "delivered", "delivered", "shipped", "canceled", "invoiced", "processing"]
PAYMENT_TYPES = ["credit_card", "credit_card", "boleto", "voucher", "debit_card"]

class OlistSampleDataGenerator:
    """
    Generates synthetic sample data matching the exact 9 Olist CSV formats.
    """
    def __init__(self, raw_dir: Path = RAW_DATA_DIR, seed: int = 42):
        self.raw_dir = raw_dir
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        self.rng = random.Random(seed)

    def generate_all_samples(
        self,
        num_customers: int = 500,
        num_products: int = 250,
        num_sellers: int = 50,
        num_orders: int = 600
    ) -> Dict[str, int]:
        """
        Creates all 9 Olist CSV files with coherent foreign key relationships.
        """
        counts = {}

        # 1. product_category_name_translation.csv
        trans_file = self.raw_dir / "product_category_name_translation.csv"
        with open(trans_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["product_category_name", "product_category_name_english"])
            for pt, en in SAMPLE_CATEGORIES:
                writer.writerow([pt, en])
        counts["product_category_name_translation.csv"] = len(SAMPLE_CATEGORIES)

        # 2. olist_sellers_dataset.csv
        seller_ids = []
        sellers_file = self.raw_dir / "olist_sellers_dataset.csv"
        with open(sellers_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["seller_id", "seller_zip_code_prefix", "seller_city", "seller_state"])
            for _ in range(num_sellers):
                s_id = uuid.UUID(int=self.rng.getrandbits(128)).hex
                seller_ids.append(s_id)
                city, state, zip_p = self.rng.choice(BRAZILIAN_CITIES)
                writer.writerow([s_id, zip_p, city, state])
        counts["olist_sellers_dataset.csv"] = num_sellers

        # 3. olist_products_dataset.csv
        product_ids = []
        products_file = self.raw_dir / "olist_products_dataset.csv"
        with open(products_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "product_id", "product_category_name", "product_name_lenght",
                "product_description_lenght", "product_photos_qty", "product_weight_g",
                "product_length_cm", "product_height_cm", "product_width_cm"
            ])
            for _ in range(num_products):
                p_id = uuid.UUID(int=self.rng.getrandbits(128)).hex
                product_ids.append(p_id)
                cat_pt = self.rng.choice(SAMPLE_CATEGORIES)[0]
                writer.writerow([
                    p_id, cat_pt, self.rng.randint(20, 60),
                    self.rng.randint(100, 1500), self.rng.randint(1, 6),
                    self.rng.randint(100, 5000), self.rng.randint(10, 80),
                    self.rng.randint(5, 50), self.rng.randint(10, 50)
                ])
        counts["olist_products_dataset.csv"] = num_products

        # 4. olist_customers_dataset.csv
        customer_ids = []
        cust_file = self.raw_dir / "olist_customers_dataset.csv"
        with open(cust_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "customer_id", "customer_unique_id", "customer_zip_code_prefix",
                "customer_city", "customer_state"
            ])
            for _ in range(num_customers):
                c_id = uuid.UUID(int=self.rng.getrandbits(128)).hex
                c_uniq = uuid.UUID(int=self.rng.getrandbits(128)).hex
                customer_ids.append(c_id)
                city, state, zip_p = self.rng.choice(BRAZILIAN_CITIES)
                writer.writerow([c_id, c_uniq, zip_p, city, state])
        counts["olist_customers_dataset.csv"] = num_customers

        # 5. olist_orders_dataset.csv
        order_records = []
        orders_file = self.raw_dir / "olist_orders_dataset.csv"
        base_date = datetime(2017, 1, 1)
        with open(orders_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "order_id", "customer_id", "order_status", "order_purchase_timestamp",
                "order_approved_at", "order_delivered_carrier_date",
                "order_delivered_customer_date", "order_estimated_delivery_date"
            ])
            for _ in range(num_orders):
                o_id = uuid.UUID(int=self.rng.getrandbits(128)).hex
                c_id = self.rng.choice(customer_ids)
                status = self.rng.choice(ORDER_STATUSES)
                p_date = base_date + timedelta(days=self.rng.randint(0, 500), hours=self.rng.randint(0, 23))
                app_date = p_date + timedelta(minutes=self.rng.randint(10, 120))
                carrier_date = app_date + timedelta(days=self.rng.randint(1, 3))
                deliv_date = carrier_date + timedelta(days=self.rng.randint(3, 10))
                est_date = p_date + timedelta(days=15)

                p_str = p_date.strftime("%Y-%m-%d %H:%M:%S")
                app_str = app_date.strftime("%Y-%m-%d %H:%M:%S")
                carrier_str = carrier_date.strftime("%Y-%m-%d %H:%M:%S") if status in ["delivered", "shipped"] else ""
                deliv_str = deliv_date.strftime("%Y-%m-%d %H:%M:%S") if status == "delivered" else ""
                est_str = est_date.strftime("%Y-%m-%d %H:%M:%S")

                writer.writerow([o_id, c_id, status, p_str, app_str, carrier_str, deliv_str, est_str])
                order_records.append((o_id, p_date))
        counts["olist_orders_dataset.csv"] = num_orders

        # 6. olist_order_items_dataset.csv
        item_count = 0
        order_totals = {o_id: 0.0 for o_id, _ in order_records}
        items_file = self.raw_dir / "olist_order_items_dataset.csv"
        with open(items_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "order_id", "order_item_id", "product_id", "seller_id",
                "shipping_limit_date", "price", "freight_value"
            ])
            for o_id, p_date in order_records:
                num_items = self.rng.choices([1, 2, 3], weights=[0.8, 0.15, 0.05])[0]
                for seq in range(1, num_items + 1):
                    p_id = self.rng.choice(product_ids)
                    s_id = self.rng.choice(seller_ids)
                    ship_limit = (p_date + timedelta(days=5)).strftime("%Y-%m-%d %H:%M:%S")
                    price = round(self.rng.uniform(15.0, 350.0), 2)
                    freight = round(self.rng.uniform(10.0, 45.0), 2)
                    writer.writerow([o_id, seq, p_id, s_id, ship_limit, price, freight])
                    order_totals[o_id] += price + freight
                    item_count += 1
        counts["olist_order_items_dataset.csv"] = item_count

        # 7. olist_order_payments_dataset.csv
        payment_count = 0
        payments_file = self.raw_dir / "olist_order_payments_dataset.csv"
        with open(payments_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "order_id", "payment_sequential", "payment_type",
                "payment_installments", "payment_value"
            ])
            for o_id, tot in order_totals.items():
                p_type = self.rng.choice(PAYMENT_TYPES)
                inst = self.rng.randint(1, 10) if p_type == "credit_card" else 1
                val = round(tot, 2)
                writer.writerow([o_id, 1, p_type, inst, val])
                payment_count += 1
        counts["olist_order_payments_dataset.csv"] = payment_count

        # 8. olist_order_reviews_dataset.csv
        review_count = 0
        reviews_file = self.raw_dir / "olist_order_reviews_dataset.csv"
        with open(reviews_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "review_id", "order_id", "review_score", "review_comment_title",
                "review_comment_message", "review_creation_date", "review_answer_timestamp"
            ])
            for o_id, p_date in order_records:
                # 85% review rate
                if self.rng.random() < 0.85:
                    r_id = uuid.UUID(int=self.rng.getrandbits(128)).hex
                    score = self.rng.choices([5, 4, 3, 2, 1], weights=[0.6, 0.2, 0.08, 0.05, 0.07])[0]
                    c_date = (p_date + timedelta(days=12)).strftime("%Y-%m-%d %H:%M:%S")
                    ans_date = (p_date + timedelta(days=14)).strftime("%Y-%m-%d %H:%M:%S")
                    title = "Recomendo" if score >= 4 else "Demorou"
                    msg = "Produto excelente, entrega rapida." if score >= 4 else "Produto ok."
                    writer.writerow([r_id, o_id, score, title, msg, c_date, ans_date])
                    review_count += 1
        counts["olist_order_reviews_dataset.csv"] = review_count

        # 9. olist_geolocation_dataset.csv
        geo_count = 0
        geo_file = self.raw_dir / "olist_geolocation_dataset.csv"
        with open(geo_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "geolocation_zip_code_prefix", "geolocation_lat", "geolocation_lng",
                "geolocation_city", "geolocation_state"
            ])
            for city, state, zip_p in BRAZILIAN_CITIES:
                for _ in range(10): # 10 coordinate points per city
                    lat = round(-23.55 + self.rng.uniform(-2.0, 2.0), 6)
                    lng = round(-46.63 + self.rng.uniform(-2.0, 2.0), 6)
                    writer.writerow([zip_p, lat, lng, city, state])
                    geo_count += 1
        counts["olist_geolocation_dataset.csv"] = geo_count

        return counts
