"""
Olist Schema Migration Module
Safely validates and migrates the existing relational schema to support
Olist Brazilian E-Commerce dataset integration while preserving all existing
primary keys, foreign keys, constraints, and architecture.
"""

from typing import Dict, Any, List, Tuple
from database.mysql_connection import MySQLDatabase
from utils.logger import get_logger

logger = get_logger("olist_schema_migration")

# Columns to ensure exist on core tables
EXTENDED_COLUMNS = {
    "customers": [
        ("source_id", "VARCHAR(64) UNIQUE"),
        ("customer_unique_id", "VARCHAR(64)"),
        ("zip_code_prefix", "VARCHAR(10)"),
        ("city", "VARCHAR(100)"),
        ("state", "VARCHAR(10)"),
        ("data_origin", "VARCHAR(20) NOT NULL DEFAULT 'imported'")
    ],
    "categories": [
        ("source_name", "VARCHAR(100)")
    ],
    "products": [
        ("source_id", "VARCHAR(64) UNIQUE"),
        ("weight_g", "INT"),
        ("length_cm", "INT"),
        ("height_cm", "INT"),
        ("width_cm", "INT"),
        ("photos_qty", "INT"),
        ("data_origin", "VARCHAR(20) NOT NULL DEFAULT 'imported'")
    ],
    "inventory": [
        ("baseline_stock", "INT NOT NULL DEFAULT 0")
    ],
    "orders": [
        ("source_id", "VARCHAR(64) UNIQUE"),
        ("data_origin", "VARCHAR(20) NOT NULL DEFAULT 'imported'")
    ],
    "order_items": [
        ("source_id", "VARCHAR(64)"),
        ("seller_id", "VARCHAR(64)"),
        ("freight_value", "DECIMAL(10, 2) NOT NULL DEFAULT 0.00"),
        ("data_origin", "VARCHAR(20) NOT NULL DEFAULT 'imported'")
    ],
    "cart_items": [
        ("data_origin", "VARCHAR(20) NOT NULL DEFAULT 'benchmark'")
    ]
}

AUXILIARY_TABLES_SQL = [
    """
    CREATE TABLE IF NOT EXISTS sellers (
        seller_id VARCHAR(64) PRIMARY KEY,
        zip_code_prefix VARCHAR(10),
        city VARCHAR(100),
        state VARCHAR(10)
    ) ENGINE=InnoDB;
    """,
    """
    CREATE TABLE IF NOT EXISTS order_payments (
        payment_id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        payment_sequential INT NOT NULL DEFAULT 1,
        payment_type VARCHAR(50) NOT NULL,
        payment_installments INT NOT NULL DEFAULT 1,
        payment_value DECIMAL(10, 2) NOT NULL,
        data_origin VARCHAR(20) NOT NULL DEFAULT 'imported',
        CONSTRAINT fk_payments_order
            FOREIGN KEY (order_id) REFERENCES orders(order_id)
            ON UPDATE CASCADE ON DELETE CASCADE,
        CONSTRAINT chk_payments_value
            CHECK (payment_value >= 0.00),
        INDEX idx_payments_data_origin (data_origin)
    ) ENGINE=InnoDB;
    """,
    """
    CREATE TABLE IF NOT EXISTS order_reviews (
        review_id VARCHAR(64) PRIMARY KEY,
        order_id INT NOT NULL,
        review_score INT NOT NULL,
        review_comment_title VARCHAR(255),
        review_comment_message TEXT,
        created_at DATETIME,
        data_origin VARCHAR(20) NOT NULL DEFAULT 'imported',
        CONSTRAINT fk_reviews_order
            FOREIGN KEY (order_id) REFERENCES orders(order_id)
            ON UPDATE CASCADE ON DELETE CASCADE,
        INDEX idx_reviews_data_origin (data_origin)
    ) ENGINE=InnoDB;
    """,
    """
    CREATE TABLE IF NOT EXISTS geolocation (
        geolocation_id INT AUTO_INCREMENT PRIMARY KEY,
        zip_code_prefix VARCHAR(10) NOT NULL,
        lat DECIMAL(10, 8),
        lng DECIMAL(11, 8),
        city VARCHAR(100),
        state VARCHAR(10),
        INDEX idx_geo_zip (zip_code_prefix)
    ) ENGINE=InnoDB;
    """,
    """
    CREATE TABLE IF NOT EXISTS olist_import_logs (
        log_id INT AUTO_INCREMENT PRIMARY KEY,
        file_name VARCHAR(100) NOT NULL,
        imported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        total_rows INT NOT NULL DEFAULT 0,
        valid_rows INT NOT NULL DEFAULT 0,
        duplicate_rows INT NOT NULL DEFAULT 0,
        rejected_rows INT NOT NULL DEFAULT 0,
        status VARCHAR(50) NOT NULL DEFAULT 'COMPLETED',
        details JSON
    ) ENGINE=InnoDB;
    """
]

class OlistSchemaMigrator:
    """
    Manages safe schema migration for Olist integration.
    """
    def __init__(self, mysql_db: MySQLDatabase):
        self.mysql = mysql_db

    def check_migration_status(self) -> Dict[str, Any]:
        """
        Inspects existing database schema and returns status of Olist-extended columns and tables.
        """
        status = {
            "is_migrated": True,
            "missing_columns": {},
            "missing_tables": []
        }

        try:
            with self.mysql.get_connection() as conn:
                cursor = conn.cursor(dictionary=True)

                # Check auxiliary tables
                for tbl in ["sellers", "order_payments", "order_reviews", "geolocation", "olist_import_logs"]:
                    cursor.execute(f"SHOW TABLES LIKE '{tbl}'")
                    if not cursor.fetchone():
                        status["missing_tables"].append(tbl)
                        status["is_migrated"] = False

                # Check columns on existing tables
                for tbl, cols in EXTENDED_COLUMNS.items():
                    cursor.execute(f"SHOW TABLES LIKE '{tbl}'")
                    if not cursor.fetchone():
                        status["missing_tables"].append(tbl)
                        status["is_migrated"] = False
                        continue

                    cursor.execute(f"SHOW COLUMNS FROM {tbl}")
                    existing_cols = {row["Field"].lower() for row in cursor.fetchall()}

                    missing_in_tbl = []
                    for col_name, col_def in cols:
                        if col_name.lower() not in existing_cols:
                            missing_in_tbl.append((col_name, col_def))
                            status["is_migrated"] = False

                    if missing_in_tbl:
                        status["missing_columns"][tbl] = missing_in_tbl

                cursor.close()
        except Exception as e:
            logger.error(f"Error checking migration status: {e}")
            status["is_migrated"] = False
            status["error"] = str(e)

        return status

    def execute_migration(self) -> Tuple[bool, str, List[str]]:
        """
        Executes idempotent migration statements to add any missing columns and tables.
        """
        applied_changes = []
        try:
            with self.mysql.get_connection() as conn:
                cursor = conn.cursor()

                # 1. Create auxiliary tables
                for sql in AUXILIARY_TABLES_SQL:
                    cursor.execute(sql)
                applied_changes.append("Ensured auxiliary tables (sellers, payments, reviews, geo, logs)")

                # 2. Add missing columns safely
                for tbl, cols in EXTENDED_COLUMNS.items():
                    # Get existing columns
                    cursor.execute(f"SHOW COLUMNS FROM {tbl}")
                    existing_cols = {row[0].lower() for row in cursor.fetchall()}

                    for col_name, col_def in cols:
                        if col_name.lower() not in existing_cols:
                            alter_sql = f"ALTER TABLE {tbl} ADD COLUMN {col_name} {col_def};"
                            try:
                                cursor.execute(alter_sql)
                                applied_changes.append(f"Added column {col_name} to {tbl}")
                            except Exception as ce:
                                logger.warning(f"Could not add {col_name} to {tbl}: {ce}")

                conn.commit()
                cursor.close()

            return True, "Schema migration completed successfully.", applied_changes
        except Exception as e:
            logger.error(f"Schema migration error: {e}")
            return False, str(e), applied_changes
