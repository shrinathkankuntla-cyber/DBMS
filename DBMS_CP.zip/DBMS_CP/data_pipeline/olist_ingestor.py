"""
Olist Dataset Ingestion Pipeline
Comprehensive ingestion engine for the Brazilian E-Commerce Public Dataset by Olist.
Supports all 9 CSV files, manual ZIP extraction, duplicate deduplication, relational mapping,
reproducible inventory generation, MongoDB document transformation, and validation audit reporting.
"""

import os
import zipfile
import io
import random
from datetime import datetime
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Callable
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from data_pipeline.olist_schema_migration import OlistSchemaMigrator
from utils.logger import get_logger
from utils.helpers import Timer

logger = get_logger("olist_ingestor")

RAW_DATA_DIR = Path(__file__).resolve().parent.parent / "data" / "raw"

EXPECTED_FILES = [
    "product_category_name_translation.csv",
    "olist_products_dataset.csv",
    "olist_customers_dataset.csv",
    "olist_sellers_dataset.csv",
    "olist_orders_dataset.csv",
    "olist_order_items_dataset.csv",
    "olist_order_payments_dataset.csv",
    "olist_order_reviews_dataset.csv",
    "olist_geolocation_dataset.csv"
]

class OlistIngestor:
    """
    Manages the complete end-to-end ingestion of the 9 Olist CSV files into MySQL and MongoDB.
    """
    def __init__(
        self,
        raw_dir: Path = RAW_DATA_DIR,
        mysql_db: Optional[MySQLDatabase] = None,
        mongo_db: Optional[MongoDBDatabase] = None,
        inventory_seed: int = 42
    ):
        self.raw_dir = raw_dir
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        self.mysql = mysql_db or MySQLDatabase()
        self.mongo = mongo_db or MongoDBDatabase()
        self.inventory_seed = inventory_seed

    def extract_zip_archive(self, zip_source: Any) -> Tuple[bool, str, List[str]]:
        """
        Extracts a manual ZIP archive into data/raw/.
        Accepts a file path string, Path object, or file-like / BytesIO object.
        """
        extracted = []
        try:
            if isinstance(zip_source, (str, Path)):
                with zipfile.ZipFile(zip_source, 'r') as z:
                    for f in z.namelist():
                        # Extract directly into raw_dir flattening any subfolder
                        base_name = os.path.basename(f)
                        if base_name and base_name.endswith('.csv'):
                            target_path = self.raw_dir / base_name
                            with z.open(f) as src, open(target_path, "wb") as dst:
                                dst.write(src.read())
                            extracted.append(base_name)
            else:
                # File-like BytesIO from Streamlit file uploader
                with zipfile.ZipFile(zip_source, 'r') as z:
                    for f in z.namelist():
                        base_name = os.path.basename(f)
                        if base_name and base_name.endswith('.csv'):
                            target_path = self.raw_dir / base_name
                            with z.open(f) as src, open(target_path, "wb") as dst:
                                dst.write(src.read())
                            extracted.append(base_name)

            return True, f"Successfully extracted {len(extracted)} CSV files to {self.raw_dir}", extracted
        except Exception as e:
            logger.error(f"ZIP extraction failed: {e}")
            return False, str(e), extracted

    def scan_raw_files(self) -> Dict[str, Dict[str, Any]]:
        """
        Scans data/raw/ and returns availability, size, and row count for all 9 files.
        """
        status = {}
        for f_name in EXPECTED_FILES:
            f_path = self.raw_dir / f_name
            if f_path.exists():
                size_bytes = f_path.stat().st_size
                # Quick line count estimate
                try:
                    with open(f_path, "r", encoding="utf-8", errors="ignore") as f:
                        lines = sum(1 for _ in f) - 1 # exclude header
                except Exception:
                    lines = -1

                status[f_name] = {
                    "exists": True,
                    "size_bytes": size_bytes,
                    "rows_estimate": max(0, lines),
                    "path": str(f_path)
                }
            else:
                status[f_name] = {
                    "exists": False,
                    "size_bytes": 0,
                    "rows_estimate": 0,
                    "path": str(f_path)
                }
        return status

    def run_ingestion_pipeline(
        self,
        max_rows_per_file: Optional[int] = None,
        progress_callback: Optional[Callable[[str, float], None]] = None
    ) -> Dict[str, Any]:
        """
        Executes the staged ingestion pipeline with validation, duplicate rejection,
        inventory generation, and MongoDB transformation.
        """
        report = {
            "success": True,
            "duration_ms": 0.0,
            "files_processed": {},
            "total_records_inserted": 0,
            "total_duplicates_skipped": 0,
            "total_rejected_rows": 0,
            "rejection_reasons": []
        }

        # Step 0: Ensure Schema is Migrated
        migrator = OlistSchemaMigrator(self.mysql)
        m_stat = migrator.check_migration_status()
        if not m_stat["is_migrated"]:
            if progress_callback:
                progress_callback("Running database schema migration...", 0.02)
            mig_ok, mig_msg, _ = migrator.execute_migration()
            if not mig_ok:
                report["success"] = False
                report["error"] = f"Schema migration failed: {mig_msg}"
                return report

        # Step 0.1: Ensure MongoDB collection & identity index
        self.mongo.init_collection()

        with Timer() as pipeline_timer:
            # In-memory mapping caches for foreign key lookups
            category_id_map: Dict[str, int] = {}
            product_id_map: Dict[str, int] = {}     # source_id (uuid) -> product_id (int)
            customer_id_map: Dict[str, int] = {}    # source_id (uuid) -> customer_id (int)
            order_id_map: Dict[str, int] = {}       # source_id (uuid) -> order_id (int)
            seller_set = set()

            # Helper for progress
            def notify(msg: str, frac: float):
                if progress_callback:
                    progress_callback(msg, frac)
                logger.info(msg)

            # =========================================================
            # STAGE 1: CATEGORIES
            # =========================================================
            notify("Stage 1/9: Ingesting Categories & Translations...", 0.08)
            cat_report = {"read": 0, "inserted": 0, "duplicates": 0, "rejected": 0}
            
            # Load translations if available
            trans_file = self.raw_dir / "product_category_name_translation.csv"
            trans_map = {}
            if trans_file.exists():
                try:
                    df_trans = pd.read_csv(trans_file)
                    for _, row in df_trans.iterrows():
                        pt = str(row.get("product_category_name", "")).strip().lower()
                        en = str(row.get("product_category_name_english", "")).strip().lower()
                        if pt and en:
                            trans_map[pt] = en
                except Exception as e:
                    logger.warning(f"Error reading category translations: {e}")

            # Collect categories from products file as well
            prod_file = self.raw_dir / "olist_products_dataset.csv"
            if prod_file.exists():
                try:
                    df_prod_cats = pd.read_csv(prod_file, usecols=["product_category_name"])
                    for pt_cat in df_prod_cats["product_category_name"].dropna().unique():
                        pt_cat = str(pt_cat).strip().lower()
                        if pt_cat and pt_cat not in trans_map:
                            # Use clean formatted Portuguese if no translation exists
                            trans_map[pt_cat] = pt_cat.replace("_", " ").title()
                except Exception:
                    pass

            # Insert categories into MySQL
            try:
                with self.mysql.get_connection() as conn:
                    cursor = conn.cursor(dictionary=True)
                    for pt_name, en_name in trans_map.items():
                        cat_report["read"] += 1
                        display_name = en_name.replace("_", " ").title()
                        cursor.execute(
                            """
                            INSERT INTO categories (category_name, source_name)
                            VALUES (%s, %s)
                            ON DUPLICATE KEY UPDATE source_name = VALUES(source_name)
                            """,
                            (display_name[:100], pt_name[:100])
                        )
                        cat_report["inserted"] += 1

                    conn.commit()

                    # Cache all category IDs
                    cursor.execute("SELECT category_id, category_name, source_name FROM categories")
                    for row in cursor.fetchall():
                        if row["source_name"]:
                            category_id_map[row["source_name"].lower()] = row["category_id"]
                        category_id_map[row["category_name"].lower()] = row["category_id"]

                    # Default fallback category
                    cursor.execute("INSERT IGNORE INTO categories (category_name) VALUES ('General Merchandise')")
                    conn.commit()
                    cursor.execute("SELECT category_id FROM categories WHERE category_name = 'General Merchandise'")
                    default_cat_id = cursor.fetchone()["category_id"]
                    category_id_map["__default__"] = default_cat_id

                    cursor.close()
            except Exception as e:
                logger.error(f"Failed to ingest categories: {e}")
                report["rejection_reasons"].append(f"Category ingestion error: {e}")

            report["files_processed"]["categories"] = cat_report

            # =========================================================
            # STAGE 2: PRODUCTS & REPRODUCIBLE INVENTORY
            # =========================================================
            notify("Stage 2/9: Ingesting Products & Generating Inventory...", 0.20)
            prod_report = {"read": 0, "inserted": 0, "duplicates": 0, "rejected": 0}
            mongo_catalog_docs = []
            inv_rng = random.Random(self.inventory_seed)

            if prod_file.exists():
                try:
                    df_prod = pd.read_csv(prod_file)
                    if max_rows_per_file:
                        df_prod = df_prod.head(max_rows_per_file)

                    # Deduplicate on product_id
                    init_cnt = len(df_prod)
                    df_prod = df_prod.drop_duplicates(subset=["product_id"])
                    prod_report["duplicates"] = init_cnt - len(df_prod)

                    with self.mysql.get_connection() as conn:
                        cursor = conn.cursor(dictionary=True)

                        for _, row in df_prod.iterrows():
                            prod_report["read"] += 1
                            source_p_id = str(row["product_id"]).strip()
                            pt_cat = str(row.get("product_category_name", "")).strip().lower()
                            c_id = category_id_map.get(pt_cat, category_id_map["__default__"])

                            # Formulate product title
                            cat_title = pt_cat.replace("_", " ").title() if pt_cat else "General Item"
                            p_name = f"{cat_title} #{source_p_id[:8]}"

                            # Default base price (updated later if item prices available)
                            base_price = round(inv_rng.uniform(25.0, 250.0), 2)

                            w_g = int(row["product_weight_g"]) if pd.notnull(row.get("product_weight_g")) else None
                            l_cm = int(row["product_length_cm"]) if pd.notnull(row.get("product_length_cm")) else None
                            h_cm = int(row["product_height_cm"]) if pd.notnull(row.get("product_height_cm")) else None
                            wd_cm = int(row["product_width_cm"]) if pd.notnull(row.get("product_width_cm")) else None
                            photos = int(row["product_photos_qty"]) if pd.notnull(row.get("product_photos_qty")) else None

                            # Insert into products
                            cursor.execute(
                                """
                                INSERT INTO products (source_id, product_name, category_id, price, status,
                                                      weight_g, length_cm, height_cm, width_cm, photos_qty, data_origin)
                                VALUES (%s, %s, %s, %s, 'active', %s, %s, %s, %s, %s, 'imported')
                                ON DUPLICATE KEY UPDATE
                                    product_name = VALUES(product_name),
                                    category_id = VALUES(category_id);
                                """,
                                (source_p_id, p_name, c_id, base_price, w_g, l_cm, h_cm, wd_cm, photos)
                            )

                            # Fetch surrogate key
                            cursor.execute("SELECT product_id FROM products WHERE source_id = %s", (source_p_id,))
                            surrogate_pid = cursor.fetchone()["product_id"]
                            product_id_map[source_p_id] = surrogate_pid

                            # Generate reproducible inventory stock
                            initial_stock = inv_rng.randint(20, 300)
                            cursor.execute(
                                """
                                INSERT INTO inventory (product_id, stock_quantity, baseline_stock)
                                VALUES (%s, %s, %s)
                                ON DUPLICATE KEY UPDATE
                                    baseline_stock = VALUES(baseline_stock);
                                """,
                                (surrogate_pid, initial_stock, initial_stock)
                            )
                            prod_report["inserted"] += 1

                            # Prepare MongoDB Document
                            mongo_doc = {
                                "product_id": surrogate_pid,
                                "source_id": source_p_id,
                                "product_name": p_name,
                                "category": cat_title,
                                "category_portuguese": pt_cat,
                                "price": float(base_price),
                                "brand": "Olist Verified",
                                "status": "active",
                                "data_origin": "imported",
                                "attributes": {
                                    "weight_g": w_g,
                                    "dimensions_cm": {
                                        "length": l_cm,
                                        "height": h_cm,
                                        "width": wd_cm
                                    },
                                    "photos_qty": photos,
                                    "name_length": int(row["product_name_lenght"]) if pd.notnull(row.get("product_name_lenght")) else None,
                                    "description_length": int(row["product_description_lenght"]) if pd.notnull(row.get("product_description_lenght")) else None
                                },
                                "variants": [],
                                "created_at": datetime.utcnow().isoformat()
                            }
                            mongo_catalog_docs.append(mongo_doc)

                        conn.commit()
                        cursor.close()

                    # Bulk upsert into MongoDB
                    if mongo_catalog_docs:
                        coll = self.mongo.get_collection("product_catalog")
                        for doc in mongo_catalog_docs:
                            coll.update_one(
                                {"product_id": doc["product_id"]},
                                {"$set": doc},
                                upsert=True
                            )

                except Exception as e:
                    logger.error(f"Error ingesting products: {e}")
                    report["rejection_reasons"].append(f"Products error: {e}")

            report["files_processed"]["olist_products_dataset.csv"] = prod_report

            # =========================================================
            # STAGE 3: CUSTOMERS
            # =========================================================
            notify("Stage 3/9: Ingesting Customers...", 0.35)
            cust_report = {"read": 0, "inserted": 0, "duplicates": 0, "rejected": 0}
            cust_file = self.raw_dir / "olist_customers_dataset.csv"

            if cust_file.exists():
                try:
                    df_cust = pd.read_csv(cust_file)
                    if max_rows_per_file:
                        df_cust = df_cust.head(max_rows_per_file)

                    init_cnt = len(df_cust)
                    df_cust = df_cust.drop_duplicates(subset=["customer_id"])
                    cust_report["duplicates"] = init_cnt - len(df_cust)

                    with self.mysql.get_connection() as conn:
                        cursor = conn.cursor(dictionary=True)

                        for _, row in df_cust.iterrows():
                            cust_report["read"] += 1
                            s_cid = str(row["customer_id"]).strip()
                            s_uniq = str(row.get("customer_unique_id", s_cid)).strip()
                            city = str(row.get("customer_city", "Unknown")).title()
                            state = str(row.get("customer_state", "BR")).upper()
                            zip_p = str(row.get("customer_zip_code_prefix", ""))[:10]

                            full_name = f"Customer {city} #{s_cid[:6]}"
                            email = f"{s_cid[:16]}@olist-customer.br"

                            cursor.execute(
                                """
                                INSERT INTO customers (source_id, customer_unique_id, full_name, email,
                                                       zip_code_prefix, city, state, data_origin)
                                VALUES (%s, %s, %s, %s, %s, %s, %s, 'imported')
                                ON DUPLICATE KEY UPDATE
                                    customer_unique_id = VALUES(customer_unique_id);
                                """,
                                (s_cid, s_uniq, full_name, email, zip_p, city[:100], state[:10])
                            )

                            cursor.execute("SELECT customer_id FROM customers WHERE source_id = %s", (s_cid,))
                            c_row = cursor.fetchone()
                            if c_row:
                                customer_id_map[s_cid] = c_row["customer_id"]
                                cust_report["inserted"] += 1

                        conn.commit()
                        cursor.close()

                except Exception as e:
                    logger.error(f"Error ingesting customers: {e}")
                    report["rejection_reasons"].append(f"Customers error: {e}")

            report["files_processed"]["olist_customers_dataset.csv"] = cust_report

            # =========================================================
            # STAGE 4: SELLERS
            # =========================================================
            notify("Stage 4/9: Ingesting Sellers...", 0.48)
            seller_report = {"read": 0, "inserted": 0, "duplicates": 0, "rejected": 0}
            sellers_file = self.raw_dir / "olist_sellers_dataset.csv"

            if sellers_file.exists():
                try:
                    df_sellers = pd.read_csv(sellers_file)
                    if max_rows_per_file:
                        df_sellers = df_sellers.head(max_rows_per_file)

                    init_cnt = len(df_sellers)
                    df_sellers = df_sellers.drop_duplicates(subset=["seller_id"])
                    seller_report["duplicates"] = init_cnt - len(df_sellers)

                    with self.mysql.get_connection() as conn:
                        cursor = conn.cursor()
                        for _, row in df_sellers.iterrows():
                            seller_report["read"] += 1
                            s_id = str(row["seller_id"]).strip()
                            city = str(row.get("seller_city", "Unknown")).title()
                            state = str(row.get("seller_state", "BR")).upper()
                            zip_p = str(row.get("seller_zip_code_prefix", ""))[:10]

                            cursor.execute(
                                """
                                INSERT INTO sellers (seller_id, zip_code_prefix, city, state)
                                VALUES (%s, %s, %s, %s)
                                ON DUPLICATE KEY UPDATE city = VALUES(city);
                                """,
                                (s_id, zip_p, city[:100], state[:10])
                            )
                            seller_set.add(s_id)
                            seller_report["inserted"] += 1

                        conn.commit()
                        cursor.close()
                except Exception as e:
                    logger.error(f"Error ingesting sellers: {e}")

            report["files_processed"]["olist_sellers_dataset.csv"] = seller_report

            # =========================================================
            # STAGE 5: ORDERS
            # =========================================================
            notify("Stage 5/9: Ingesting Orders...", 0.60)
            order_report = {"read": 0, "inserted": 0, "duplicates": 0, "rejected": 0}
            orders_file = self.raw_dir / "olist_orders_dataset.csv"

            if orders_file.exists():
                try:
                    df_orders = pd.read_csv(orders_file)
                    if max_rows_per_file:
                        df_orders = df_orders.head(max_rows_per_file)

                    init_cnt = len(df_orders)
                    df_orders = df_orders.drop_duplicates(subset=["order_id"])
                    order_report["duplicates"] = init_cnt - len(df_orders)

                    with self.mysql.get_connection() as conn:
                        cursor = conn.cursor(dictionary=True)

                        for _, row in df_orders.iterrows():
                            order_report["read"] += 1
                            s_oid = str(row["order_id"]).strip()
                            s_cid = str(row["customer_id"]).strip()

                            # Foreign key validation
                            if s_cid not in customer_id_map:
                                order_report["rejected"] += 1
                                continue

                            surr_cid = customer_id_map[s_cid]
                            status = str(row.get("order_status", "delivered")).lower()
                            p_date_str = str(row.get("order_purchase_timestamp", ""))
                            p_date = p_date_str if p_date_str and p_date_str != "nan" else datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

                            cursor.execute(
                                """
                                INSERT INTO orders (source_id, customer_id, order_date, order_status, total_amount, data_origin)
                                VALUES (%s, %s, %s, %s, 0.00, 'imported')
                                ON DUPLICATE KEY UPDATE order_status = VALUES(order_status);
                                """,
                                (s_oid, surr_cid, p_date, status[:50])
                            )

                            cursor.execute("SELECT order_id FROM orders WHERE source_id = %s", (s_oid,))
                            o_row = cursor.fetchone()
                            if o_row:
                                order_id_map[s_oid] = o_row["order_id"]
                                order_report["inserted"] += 1

                        conn.commit()
                        cursor.close()

                except Exception as e:
                    logger.error(f"Error ingesting orders: {e}")
                    report["rejection_reasons"].append(f"Orders error: {e}")

            report["files_processed"]["olist_orders_dataset.csv"] = order_report

            # =========================================================
            # STAGE 6: ORDER ITEMS
            # =========================================================
            notify("Stage 6/9: Ingesting Order Items...", 0.72)
            items_report = {"read": 0, "inserted": 0, "duplicates": 0, "rejected": 0}
            items_file = self.raw_dir / "olist_order_items_dataset.csv"
            order_totals: Dict[int, float] = {}
            product_variants_map: Dict[int, List[Dict[str, Any]]] = {}

            if items_file.exists():
                try:
                    df_items = pd.read_csv(items_file)
                    if max_rows_per_file:
                        df_items = df_items.head(max_rows_per_file * 2)

                    with self.mysql.get_connection() as conn:
                        cursor = conn.cursor()

                        for _, row in df_items.iterrows():
                            items_report["read"] += 1
                            s_oid = str(row["order_id"]).strip()
                            s_pid = str(row["product_id"]).strip()
                            s_id = str(row.get("seller_id", "")).strip()

                            if s_oid not in order_id_map or s_pid not in product_id_map:
                                items_report["rejected"] += 1
                                continue

                            surr_oid = order_id_map[s_oid]
                            surr_pid = product_id_map[s_pid]
                            price = float(row.get("price", 0.0))
                            freight = float(row.get("freight_value", 0.0))
                            subtotal = price # 1 item

                            cursor.execute(
                                """
                                INSERT INTO order_items (order_id, product_id, source_id, seller_id,
                                                         quantity, unit_price, freight_value, subtotal, data_origin)
                                VALUES (%s, %s, %s, %s, 1, %s, %s, %s, 'imported');
                                """,
                                (surr_oid, surr_pid, s_oid, s_id, price, freight, subtotal)
                            )
                            items_report["inserted"] += 1
                            order_totals[surr_oid] = order_totals.get(surr_oid, 0.0) + price + freight

                            # Record variant for MongoDB catalog
                            if surr_pid not in product_variants_map:
                                product_variants_map[surr_pid] = []
                            if len(product_variants_map[surr_pid]) < 5:
                                product_variants_map[surr_pid].append({
                                    "seller_id": s_id,
                                    "price": price,
                                    "freight_value": freight
                                })

                        # Update order total amounts
                        for o_id, tot in order_totals.items():
                            cursor.execute("UPDATE orders SET total_amount = %s WHERE order_id = %s", (tot, o_id))

                        conn.commit()
                        cursor.close()

                    # Push variants to MongoDB catalog
                    if product_variants_map:
                        coll = self.mongo.get_collection("product_catalog")
                        for pid, vars_list in product_variants_map.items():
                            coll.update_one(
                                {"product_id": pid},
                                {"$set": {"variants": vars_list}}
                            )

                except Exception as e:
                    logger.error(f"Error ingesting order items: {e}")
                    report["rejection_reasons"].append(f"Order items error: {e}")

            report["files_processed"]["olist_order_items_dataset.csv"] = items_report

            # =========================================================
            # STAGE 7: PAYMENTS
            # =========================================================
            notify("Stage 7/9: Ingesting Payments...", 0.82)
            pay_report = {"read": 0, "inserted": 0, "duplicates": 0, "rejected": 0}
            pay_file = self.raw_dir / "olist_order_payments_dataset.csv"

            if pay_file.exists():
                try:
                    df_pay = pd.read_csv(pay_file)
                    if max_rows_per_file:
                        df_pay = df_pay.head(max_rows_per_file * 2)

                    with self.mysql.get_connection() as conn:
                        cursor = conn.cursor()
                        for _, row in df_pay.iterrows():
                            pay_report["read"] += 1
                            s_oid = str(row["order_id"]).strip()
                            if s_oid not in order_id_map:
                                pay_report["rejected"] += 1
                                continue

                            surr_oid = order_id_map[s_oid]
                            seq = int(row.get("payment_sequential", 1))
                            p_type = str(row.get("payment_type", "credit_card"))
                            inst = int(row.get("payment_installments", 1))
                            val = float(row.get("payment_value", 0.0))

                            cursor.execute(
                                """
                                INSERT INTO order_payments (order_id, payment_sequential, payment_type,
                                                            payment_installments, payment_value, data_origin)
                                VALUES (%s, %s, %s, %s, %s, 'imported');
                                """,
                                (surr_oid, seq, p_type[:50], inst, val)
                            )
                            pay_report["inserted"] += 1

                        conn.commit()
                        cursor.close()
                except Exception as e:
                    logger.error(f"Error ingesting payments: {e}")

            report["files_processed"]["olist_order_payments_dataset.csv"] = pay_report

            # =========================================================
            # STAGE 8: REVIEWS
            # =========================================================
            notify("Stage 8/9: Ingesting Reviews...", 0.90)
            rev_report = {"read": 0, "inserted": 0, "duplicates": 0, "rejected": 0}
            rev_file = self.raw_dir / "olist_order_reviews_dataset.csv"

            if rev_file.exists():
                try:
                    df_rev = pd.read_csv(rev_file)
                    if max_rows_per_file:
                        df_rev = df_rev.head(max_rows_per_file)

                    init_cnt = len(df_rev)
                    df_rev = df_rev.drop_duplicates(subset=["review_id"])
                    rev_report["duplicates"] = init_cnt - len(df_rev)

                    with self.mysql.get_connection() as conn:
                        cursor = conn.cursor()
                        for _, row in df_rev.iterrows():
                            rev_report["read"] += 1
                            r_id = str(row["review_id"]).strip()
                            s_oid = str(row["order_id"]).strip()

                            if s_oid not in order_id_map:
                                rev_report["rejected"] += 1
                                continue

                            surr_oid = order_id_map[s_oid]
                            score = int(row.get("review_score", 5))
                            title = str(row.get("review_comment_title", ""))[:255] if pd.notnull(row.get("review_comment_title")) else None
                            msg = str(row.get("review_comment_message", "")) if pd.notnull(row.get("review_comment_message")) else None
                            c_date = str(row.get("review_creation_date", ""))
                            c_dt = c_date if c_date and c_date != "nan" else None

                            cursor.execute(
                                """
                                INSERT INTO order_reviews (review_id, order_id, review_score,
                                                           review_comment_title, review_comment_message, created_at, data_origin)
                                VALUES (%s, %s, %s, %s, %s, %s, 'imported')
                                ON DUPLICATE KEY UPDATE review_score = VALUES(review_score);
                                """,
                                (r_id, surr_oid, score, title, msg, c_dt)
                            )
                            rev_report["inserted"] += 1

                        conn.commit()
                        cursor.close()
                except Exception as e:
                    logger.error(f"Error ingesting reviews: {e}")

            report["files_processed"]["olist_order_reviews_dataset.csv"] = rev_report

            # =========================================================
            # STAGE 9: GEOLOCATION
            # =========================================================
            notify("Stage 9/9: Ingesting Geolocation...", 0.96)
            geo_report = {"read": 0, "inserted": 0, "duplicates": 0, "rejected": 0}
            geo_file = self.raw_dir / "olist_geolocation_dataset.csv"

            if geo_file.exists():
                try:
                    df_geo = pd.read_csv(geo_file)
                    # Sample or deduplicate by zip_code_prefix to avoid inserting 1M identical coordinates
                    df_geo = df_geo.drop_duplicates(subset=["geolocation_zip_code_prefix"])
                    if max_rows_per_file:
                        df_geo = df_geo.head(max_rows_per_file)

                    with self.mysql.get_connection() as conn:
                        cursor = conn.cursor()
                        for _, row in df_geo.iterrows():
                            geo_report["read"] += 1
                            zip_p = str(row.get("geolocation_zip_code_prefix", ""))[:10]
                            lat = float(row.get("geolocation_lat", 0.0))
                            lng = float(row.get("geolocation_lng", 0.0))
                            city = str(row.get("geolocation_city", "Unknown")).title()
                            state = str(row.get("geolocation_state", "BR")).upper()

                            cursor.execute(
                                """
                                INSERT INTO geolocation (zip_code_prefix, lat, lng, city, state)
                                VALUES (%s, %s, %s, %s, %s);
                                """,
                                (zip_p, lat, lng, city[:100], state[:10])
                            )
                            geo_report["inserted"] += 1

                        conn.commit()
                        cursor.close()
                except Exception as e:
                    logger.error(f"Error ingesting geolocation: {e}")

            report["files_processed"]["olist_geolocation_dataset.csv"] = geo_report

            # Summarize totals
            tot_ins = sum(f.get("inserted", 0) for f in report["files_processed"].values())
            tot_dup = sum(f.get("duplicates", 0) for f in report["files_processed"].values())
            tot_rej = sum(f.get("rejected", 0) for f in report["files_processed"].values())

            report["total_records_inserted"] = tot_ins
            report["total_duplicates_skipped"] = tot_dup
            report["total_rejected_rows"] = tot_rej
            report["duration_ms"] = pipeline_timer.elapsed_ms

            # Log to MySQL olist_import_logs
            try:
                with self.mysql.get_connection() as conn:
                    cursor = conn.cursor()
                    import json
                    cursor.execute(
                        """
                        INSERT INTO olist_import_logs (file_name, total_rows, valid_rows, duplicate_rows, rejected_rows, status, details)
                        VALUES ('ALL_9_OLIST_DATASETS', %s, %s, %s, %s, 'COMPLETED', %s)
                        """,
                        (tot_ins + tot_dup + tot_rej, tot_ins, tot_dup, tot_rej, json.dumps(report["files_processed"]))
                    )
                    conn.commit()
                    cursor.close()
            except Exception:
                pass

            notify("Ingestion completed successfully!", 1.0)
            return report
