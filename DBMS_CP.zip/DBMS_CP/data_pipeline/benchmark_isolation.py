"""
Benchmark Isolation & Mutable Data Reset Module
Ensures complete isolation between original historical Olist datasets ('imported')
and temporary benchmark experiment mutations ('benchmark').
Allows resetting benchmark data without losing original imported records.
"""

from typing import Dict, Any, Tuple
from database.mysql_connection import MySQLDatabase
from database.mongodb_connection import MongoDBDatabase
from utils.logger import get_logger

logger = get_logger("benchmark_isolation")

class BenchmarkDataIsolator:
    """
    Manages separation and safe cleanup of benchmark mutations.
    """
    def __init__(self, mysql_db: MySQLDatabase, mongo_db: MongoDBDatabase):
        self.mysql = mysql_db
        self.mongo = mongo_db

    def get_data_breakdown(self) -> Dict[str, Any]:
        """
        Returns count of 'imported' vs 'benchmark' rows across relational and document engines.
        """
        stats = {
            "mysql": {},
            "mongodb": {}
        }

        # Check MySQL
        core_tables = ["customers", "products", "orders", "order_items", "cart_items", "inventory"]
        try:
            with self.mysql.get_connection() as conn:
                cursor = conn.cursor(dictionary=True)

                for t in core_tables:
                    try:
                        if t == "cart_items":
                            cursor.execute("SELECT COUNT(*) as cnt FROM cart_items")
                            row = cursor.fetchone()
                            stats["mysql"][t] = {"imported": 0, "benchmark": row["cnt"] if row else 0}
                        elif t == "inventory":
                            cursor.execute("SELECT COUNT(*) as cnt FROM inventory")
                            row = cursor.fetchone()
                            cursor.execute("SELECT COUNT(*) as diff FROM inventory WHERE stock_quantity != baseline_stock")
                            diff_row = cursor.fetchone()
                            stats["mysql"][t] = {
                                "total_tracked": row["cnt"] if row else 0,
                                "modified_from_baseline": diff_row["diff"] if diff_row else 0
                            }
                        else:
                            cursor.execute(f"SELECT data_origin, COUNT(*) as cnt FROM {t} GROUP BY data_origin")
                            rows = cursor.fetchall()
                            t_stats = {"imported": 0, "benchmark": 0}
                            for r in rows:
                                org = r.get("data_origin", "imported")
                                t_stats[org] = r.get("cnt", 0)
                            stats["mysql"][t] = t_stats
                    except Exception as e:
                        logger.warning(f"Could not read origin stats for {t}: {e}")
                        stats["mysql"][t] = {"imported": 0, "benchmark": 0}

                cursor.close()
        except Exception as e:
            logger.error(f"Failed to query MySQL data breakdown: {e}")

        # Check MongoDB
        try:
            coll = self.mongo.get_collection("product_catalog")
            imported_cnt = coll.count_documents({"data_origin": "imported"})
            bench_cnt = coll.count_documents({"data_origin": "benchmark"})
            total_cnt = coll.count_documents({})
            stats["mongodb"]["product_catalog"] = {
                "imported": imported_cnt,
                "benchmark": bench_cnt,
                "total": total_cnt
            }
        except Exception as e:
            logger.error(f"Failed to query MongoDB data breakdown: {e}")
            stats["mongodb"]["product_catalog"] = {"imported": 0, "benchmark": 0, "total": 0}

        return stats

    def reset_benchmark_data(self) -> Tuple[bool, str, Dict[str, int]]:
        """
        Resets only generated mutable experiment transactions and active carts.
        Restores stock levels in inventory to baseline_stock.
        Original imported historical records are strictly preserved.
        """
        deleted_counts = {}
        try:
            with self.mysql.get_connection() as conn:
                cursor = conn.cursor()

                # 1. Clear benchmark cart items
                cursor.execute("DELETE FROM cart_items")
                deleted_counts["cart_items"] = cursor.rowcount

                # 2. Clear benchmark payments
                cursor.execute("DELETE FROM order_payments WHERE data_origin = 'benchmark'")
                deleted_counts["order_payments"] = cursor.rowcount

                # 3. Clear benchmark reviews
                cursor.execute("DELETE FROM order_reviews WHERE data_origin = 'benchmark'")
                deleted_counts["order_reviews"] = cursor.rowcount

                # 4. Clear benchmark order items
                cursor.execute("DELETE FROM order_items WHERE data_origin = 'benchmark'")
                deleted_counts["order_items"] = cursor.rowcount

                # 5. Clear benchmark orders
                cursor.execute("DELETE FROM orders WHERE data_origin = 'benchmark'")
                deleted_counts["orders"] = cursor.rowcount

                # 6. Clear benchmark products
                cursor.execute("DELETE FROM products WHERE data_origin = 'benchmark'")
                deleted_counts["products"] = cursor.rowcount

                # 7. Clear benchmark customers
                cursor.execute("DELETE FROM customers WHERE data_origin = 'benchmark'")
                deleted_counts["customers"] = cursor.rowcount

                # 8. Restore inventory stock to original baseline
                cursor.execute("UPDATE inventory SET stock_quantity = baseline_stock")
                deleted_counts["inventory_restored"] = cursor.rowcount

                conn.commit()
                cursor.close()

            # 9. Clean MongoDB benchmark catalogue documents
            coll = self.mongo.get_collection("product_catalog")
            mg_res = coll.delete_many({"data_origin": "benchmark"})
            deleted_counts["mongo_product_catalog"] = mg_res.deleted_count

            msg = f"Reset complete. Cleaned {sum(deleted_counts.values())} benchmark records; restored inventory to imported baseline."
            logger.info(msg)
            return True, msg, deleted_counts

        except Exception as e:
            logger.error(f"Failed to reset benchmark data: {e}")
            return False, str(e), deleted_counts
