from typing import Optional, Dict, Any, List
from database.mysql_connection import MySQLDatabase
from utils.helpers import Timer
from utils.logger import get_logger

logger = get_logger("order_transactions")

class OrderTransactionManager:
    """
    Encapsulates ACID transaction operations for e-commerce orders:
    order placement, failure injection, order cancellation, and duplicate prevention.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()

    def place_order_transactional(
        self,
        customer_id: int,
        items: List[Dict[str, Any]], # [{"product_id": int, "quantity": int}]
        fail_at_step: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Executes order placement in a single atomic transaction.
        fail_at_step allows injecting intentional failures for ACID validation.
        """
        if not items:
            return {
                "success": False,
                "order_id": None,
                "error": "Order must contain at least one item.",
                "steps": ["Validate items array"],
                "duration_ms": 0.0
            }

        try:
            conn = self.mysql.get_raw_connection(include_db=True)
        except Exception as e:
            return {
                "success": False,
                "order_id": None,
                "error": f"MySQL connection failed: {e}",
                "steps": ["Connect to MySQL"],
                "duration_ms": 0.0
            }

        cursor = conn.cursor(dictionary=True)
        steps_executed = []

        with Timer() as timer:
            try:
                # 1. Customer verification
                steps_executed.append("Verify customer exists")
                cursor.execute("SELECT customer_id, full_name FROM customers WHERE customer_id = %s", (customer_id,))
                cust = cursor.fetchone()
                if not cust:
                    conn.rollback()
                    return {
                        "success": False,
                        "error": f"Customer ID {customer_id} does not exist.",
                        "steps": steps_executed,
                        "duration_ms": timer.elapsed_ms
                    }

                # 2. Inventory check with FOR UPDATE row locking
                steps_executed.append("Acquire row locks and validate stock")
                order_total = 0.0
                order_items_prepared = []
                for itm in items:
                    p_id = itm["product_id"]
                    qty = itm["quantity"]

                    if qty <= 0:
                        conn.rollback()
                        return {
                            "success": False,
                            "error": f"Invalid item quantity {qty} (must be > 0).",
                            "steps": steps_executed,
                            "duration_ms": timer.elapsed_ms
                        }

                    cursor.execute(
                        "SELECT p.product_id, p.product_name, p.price, p.status, i.stock_quantity "
                        "FROM products p JOIN inventory i ON p.product_id = i.product_id "
                        "WHERE p.product_id = %s FOR UPDATE",
                        (p_id,)
                    )
                    prod = cursor.fetchone()
                    if not prod:
                        conn.rollback()
                        return {
                            "success": False,
                            "error": f"Product {p_id} not found in inventory.",
                            "steps": steps_executed,
                            "duration_ms": timer.elapsed_ms
                        }

                    if prod["stock_quantity"] < qty:
                        conn.rollback()
                        return {
                            "success": False,
                            "error": f"Insufficient stock for product {p_id} ('{prod['product_name']}'): available {prod['stock_quantity']}, requested {qty}.",
                            "steps": steps_executed,
                            "duration_ms": timer.elapsed_ms
                        }

                    unit_p = float(prod["price"])
                    subtotal = round(unit_p * qty, 2)
                    order_total += subtotal
                    order_items_prepared.append({
                        "product_id": p_id,
                        "quantity": qty,
                        "unit_price": unit_p,
                        "subtotal": subtotal,
                        "initial_stock": prod["stock_quantity"]
                    })

                if fail_at_step == "before_order_insert":
                    raise RuntimeError("Injected Crash: Simulated failure before order row insertion.")

                # 3. Insert order header
                steps_executed.append("Insert order header record")
                cursor.execute(
                    "INSERT INTO orders (customer_id, order_date, order_status, total_amount) VALUES (%s, NOW(), 'completed', %s)",
                    (customer_id, round(order_total, 2))
                )
                order_id = cursor.lastrowid

                if fail_at_step == "before_items_insert":
                    raise RuntimeError("Injected Crash: Simulated failure after order insert before items insert.")

                # 4. Insert order items & deduct stock
                steps_executed.append("Insert order items and deduct inventory")
                for itm in order_items_prepared:
                    cursor.execute(
                        "INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal) VALUES (%s, %s, %s, %s, %s)",
                        (order_id, itm["product_id"], itm["quantity"], itm["unit_price"], itm["subtotal"])
                    )
                    new_stock = itm["initial_stock"] - itm["quantity"]
                    cursor.execute(
                        "UPDATE inventory SET stock_quantity = %s, updated_at = NOW() WHERE product_id = %s",
                        (new_stock, itm["product_id"])
                    )

                if fail_at_step == "before_commit":
                    raise RuntimeError("Injected Crash: Simulated failure immediately prior to commit.")

                # 5. Commit
                steps_executed.append("Commit transaction")
                conn.commit()

                return {
                    "success": True,
                    "order_id": order_id,
                    "total_amount": round(order_total, 2),
                    "items": order_items_prepared,
                    "steps": steps_executed,
                    "duration_ms": timer.elapsed_ms,
                    "error": None
                }

            except Exception as e:
                conn.rollback()
                steps_executed.append(f"Rolled back due to error: {str(e)}")
                return {
                    "success": False,
                    "order_id": None,
                    "error": str(e),
                    "steps": steps_executed,
                    "duration_ms": timer.elapsed_ms
                }
            finally:
                cursor.close()
                conn.close()

    def cancel_order_transactional(self, order_id: int) -> Dict[str, Any]:
        """
        Cancels an order and restores its inventory.
        STRICT INVARIANT: Checks order status under lock.
        If order is already 'cancelled', REJECTS to prevent duplicate inventory restoration.
        """
        try:
            conn = self.mysql.get_raw_connection(include_db=True)
        except Exception as e:
            return {
                "success": False,
                "error": f"MySQL connection failed: {e}",
                "steps": ["Connect to MySQL"],
                "duration_ms": 0.0
            }

        cursor = conn.cursor(dictionary=True)
        steps_executed = []

        with Timer() as timer:
            try:
                # 1. Lock and check order record
                steps_executed.append("Lock order record and inspect status")
                cursor.execute(
                    "SELECT order_id, order_status, total_amount FROM orders WHERE order_id = %s FOR UPDATE",
                    (order_id,)
                )
                order = cursor.fetchone()
                if not order:
                    conn.rollback()
                    return {"success": False, "error": f"Order ID {order_id} does not exist.", "steps": steps_executed}

                if order["order_status"] == "cancelled":
                    conn.rollback()
                    steps_executed.append("Order already cancelled: aborting to prevent duplicate inventory restoration")
                    return {
                        "success": False,
                        "error": f"Order ID {order_id} is ALREADY cancelled. Cannot restore inventory twice.",
                        "steps": steps_executed,
                        "duration_ms": timer.elapsed_ms,
                        "duplicate_prevented": True
                    }

                # 2. Fetch order items
                steps_executed.append("Retrieve order items to restore")
                cursor.execute(
                    "SELECT product_id, quantity FROM order_items WHERE order_id = %s",
                    (order_id,)
                )
                items = cursor.fetchall()

                # 3. Restore inventory for each item
                steps_executed.append("Restore inventory quantities")
                restored_details = []
                for itm in items:
                    p_id = itm["product_id"]
                    qty = itm["quantity"]
                    cursor.execute(
                        "SELECT stock_quantity FROM inventory WHERE product_id = %s FOR UPDATE",
                        (p_id,)
                    )
                    inv = cursor.fetchone()
                    curr_stock = inv["stock_quantity"] if inv else 0
                    new_stock = curr_stock + qty

                    cursor.execute(
                        "UPDATE inventory SET stock_quantity = %s, updated_at = NOW() WHERE product_id = %s",
                        (new_stock, p_id)
                    )
                    restored_details.append({"product_id": p_id, "restored_qty": qty, "new_stock": new_stock})

                # 4. Update order status to 'cancelled'
                steps_executed.append("Set order status to 'cancelled'")
                cursor.execute(
                    "UPDATE orders SET order_status = 'cancelled' WHERE order_id = %s",
                    (order_id,)
                )

                # 5. Commit
                steps_executed.append("Commit cancellation transaction")
                conn.commit()

                return {
                    "success": True,
                    "order_id": order_id,
                    "restored_items": restored_details,
                    "steps": steps_executed,
                    "duration_ms": timer.elapsed_ms,
                    "error": None
                }

            except Exception as e:
                conn.rollback()
                steps_executed.append(f"Rolled back: {str(e)}")
                return {"success": False, "error": str(e), "steps": steps_executed, "duration_ms": timer.elapsed_ms}
            finally:
                cursor.close()
                conn.close()
