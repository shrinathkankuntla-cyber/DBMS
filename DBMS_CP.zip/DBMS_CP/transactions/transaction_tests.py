from typing import Optional, Dict, Any, List
from database.mysql_connection import MySQLDatabase
from transactions.order_transactions import OrderTransactionManager
from utils.logger import get_logger

logger = get_logger("transaction_tests")

class TransactionTestSuite:
    """
    Automated test executor for validating ACID properties, failure handling,
    and business invariants in MySQL transactions.
    """
    def __init__(self, mysql_db: Optional[MySQLDatabase] = None):
        self.mysql = mysql_db or MySQLDatabase()
        self.tx_mgr = OrderTransactionManager(self.mysql)

    def run_all_scenarios(self) -> List[Dict[str, Any]]:
        """Executes all 6 transaction scenarios and returns detailed reports."""
        return [
            self.test_successful_order(),
            self.test_insufficient_stock(),
            self.test_invalid_product(),
            self.test_injected_crash_rollback(),
            self.test_order_cancellation_and_restoration(),
            self.test_duplicate_cancellation_prevention()
        ]

    def test_successful_order(self) -> Dict[str, Any]:
        """Scenario 1: Happy path - verify order is created and stock decremented."""
        # Setup: Ensure product 1 has stock >= 5
        self.mysql.execute_query("UPDATE inventory SET stock_quantity = 50 WHERE product_id = 1", fetch=False)
        stock_before = self._get_stock(1)

        res = self.tx_mgr.place_order_transactional(
            customer_id=1,
            items=[{"product_id": 1, "quantity": 3}]
        )
        stock_after = self._get_stock(1)

        passed = res["success"] and (stock_before - stock_after == 3)
        return {
            "scenario": "1. Successful Order Placement",
            "passed": passed,
            "details": f"Ordered 3 units of product 1. Stock before: {stock_before}, after: {stock_after}.",
            "steps": res.get("steps", []),
            "result": res
        }

    def test_insufficient_stock(self) -> Dict[str, Any]:
        """Scenario 2: Insufficient stock - verify rollback and unaltered stock."""
        self.mysql.execute_query("UPDATE inventory SET stock_quantity = 2 WHERE product_id = 1", fetch=False)
        stock_before = self._get_stock(1)

        res = self.tx_mgr.place_order_transactional(
            customer_id=1,
            items=[{"product_id": 1, "quantity": 10}]
        )
        stock_after = self._get_stock(1)

        passed = (not res["success"]) and (stock_before == stock_after) and ("Insufficient stock" in str(res.get("error")))
        return {
            "scenario": "2. Insufficient Stock Rollback",
            "passed": passed,
            "details": f"Attempted to order 10 with stock 2. Transaction rejected. Stock remained {stock_after}.",
            "steps": res.get("steps", []),
            "result": res
        }

    def test_invalid_product(self) -> Dict[str, Any]:
        """Scenario 3: Non-existent product ID."""
        res = self.tx_mgr.place_order_transactional(
            customer_id=1,
            items=[{"product_id": 9999999, "quantity": 1}]
        )
        passed = (not res["success"]) and ("not found" in str(res.get("error")).lower())
        return {
            "scenario": "3. Invalid Product Rollback",
            "passed": passed,
            "details": "Order with non-existent product was rolled back safely.",
            "steps": res.get("steps", []),
            "result": res
        }

    def test_injected_crash_rollback(self) -> Dict[str, Any]:
        """Scenario 4: Simulated crash before inventory update."""
        self.mysql.execute_query("UPDATE inventory SET stock_quantity = 25 WHERE product_id = 1", fetch=False)
        stock_before = self._get_stock(1)

        res = self.tx_mgr.place_order_transactional(
            customer_id=1,
            items=[{"product_id": 1, "quantity": 4}],
            fail_at_step="before_inventory"
        )
        stock_after = self._get_stock(1)

        passed = (not res["success"]) and (stock_before == stock_after) and ("Injected Crash" in str(res.get("error")))
        return {
            "scenario": "4. Injected Mid-Transaction Crash",
            "passed": passed,
            "details": f"Exception raised before inventory deduction. Transaction rolled back atomically. Stock remained {stock_after}.",
            "steps": res.get("steps", []),
            "result": res
        }

    def test_order_cancellation_and_restoration(self) -> Dict[str, Any]:
        """Scenario 5: Cancel order and verify inventory is accurately restored."""
        # First place order
        self.mysql.execute_query("UPDATE inventory SET stock_quantity = 20 WHERE product_id = 1", fetch=False)
        place_res = self.tx_mgr.place_order_transactional(
            customer_id=1,
            items=[{"product_id": 1, "quantity": 5}]
        )
        order_id = place_res.get("order_id")
        stock_after_order = self._get_stock(1)

        # Now cancel order
        cancel_res = self.tx_mgr.cancel_order_transactional(order_id)
        stock_after_cancel = self._get_stock(1)

        passed = cancel_res["success"] and (stock_after_cancel == stock_after_order + 5)
        return {
            "scenario": "5. Order Cancellation & Inventory Restoration",
            "passed": passed,
            "details": f"Order #{order_id} cancelled. Stock restored from {stock_after_order} to {stock_after_cancel}.",
            "steps": cancel_res.get("steps", []),
            "result": cancel_res
        }

    def test_duplicate_cancellation_prevention(self) -> Dict[str, Any]:
        """Scenario 6: Invariant - Cancelling twice must NOT restore inventory twice."""
        # First place order and cancel once
        self.mysql.execute_query("UPDATE inventory SET stock_quantity = 20 WHERE product_id = 1", fetch=False)
        place_res = self.tx_mgr.place_order_transactional(
            customer_id=1,
            items=[{"product_id": 1, "quantity": 5}]
        )
        order_id = place_res.get("order_id")
        self.tx_mgr.cancel_order_transactional(order_id)
        stock_after_first_cancel = self._get_stock(1)

        # Attempt to cancel AGAIN
        second_cancel_res = self.tx_mgr.cancel_order_transactional(order_id)
        stock_after_second_cancel = self._get_stock(1)

        passed = (not second_cancel_res["success"]) and (stock_after_first_cancel == stock_after_second_cancel) and (second_cancel_res.get("duplicate_prevented") is True)
        return {
            "scenario": "6. Duplicate Order Cancellation Prevention",
            "passed": passed,
            "details": f"Attempted 2nd cancellation on Order #{order_id}. System detected status='cancelled' and rejected operation. Stock remained {stock_after_second_cancel} (invariant preserved).",
            "steps": second_cancel_res.get("steps", []),
            "result": second_cancel_res
        }

    def _get_stock(self, product_id: int) -> int:
        success, rows, _ = self.mysql.execute_query(
            "SELECT stock_quantity FROM inventory WHERE product_id = %s",
            (product_id,), fetch=True
        )
        return rows[0]["stock_quantity"] if success and rows else 0
